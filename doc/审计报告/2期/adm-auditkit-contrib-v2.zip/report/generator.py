"""统一报告生成器：Markdown + JSON。"""
from __future__ import annotations

import json
from datetime import datetime


def _table(rows):
    if not rows:
        return "_（无）_"
    out = ["| 级别 | 维度 | 位置 | 符号 | 说明 |", "|---|---|---|---|---|"]
    for f in rows:
        out.append(f"| {f['severity']} | {f['dimension']} | "
                   f"`{f['file']}:{f['line']}` | `{f['symbol']}` | {f['message']} |")
    return "\n".join(out)


def render_markdown(result: dict) -> str:
    s = result.get("summary", {})
    meta = result.get("meta", {})
    L = ["# ADM AuditKit 审计报告", "",
         f"- 项目：**{meta.get('project', '-')}**",
         f"- 源码根：`{meta.get('root', '-')}`",
         f"- 生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}",
         f"- 已实现维度：{meta.get('dimensions_implemented', '-')} / "
         f"规划 {meta.get('dimensions_planned', '-')}", "",
         "## 汇总", "",
         f"- 缺陷总数：**{s.get('total', 0)}**",
         f"- critical {s.get('by_severity', {}).get('critical', 0)} · "
         f"high {s.get('by_severity', {}).get('high', 0)} · "
         f"medium {s.get('by_severity', {}).get('medium', 0)} · "
         f"low {s.get('by_severity', {}).get('low', 0)}", ""]
    if result.get("skipped"):
        L.append("> ⚠️ 语法错误被跳过的文件："
                 + ", ".join(result["skipped"][:5])
                 + ("…" if len(result["skipped"]) > 5 else ""))
        L.append("")
    L.append("## 缺陷清单")
    L.append("")
    L.append(_table(result.get("findings", [])))
    L.append("")
    L.append("> 说明：以上为**候选**，按 ADM 严格档须人工分诊 + 实测 PoC 后方可升级为确认缺陷。")
    return "\n".join(L) + "\n"


def render_json(result: dict) -> str:
    return json.dumps(result, ensure_ascii=False, indent=2)


def write(result: dict, path: str, fmt: str = "markdown") -> str:
    text = render_json(result) if fmt == "json" else render_markdown(result)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)
    return path
