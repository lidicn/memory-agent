"""统一运行器：加载源码 → 跑维度 → 聚合 → 输出。

lesson 38 / SC-02：解析失败**必须被看见**（auditkit 的 selftest 曾全红，
根因是样本带 BOM 抛 SyntaxError 被 20 个分析器静默吞掉）。
故 load_files 返回 (files, skipped)，本 runner 把 skipped 显式报出。
"""
from __future__ import annotations
import json, pathlib
from . import dimensions
from .helpers import CallGraph, load_files
from .aggregate import aggregate, summarize


def run_project(root, dims=None, cfg=None, min_severity="low", verbose=False):
    files, skipped = load_files(pathlib.Path(root))
    if skipped and verbose:
        for p, why in skipped:
            print(f"[warn] 跳过不可解析: {p} — {why}")
    cg = CallGraph(files)
    findings = []
    for d in dimensions.build(dims):
        try:
            findings += d.run(files, str(root), cfg=cfg, cg=cg)
        except Exception as exc:  # 维度自身崩溃不得静默（SC-02 同族）
            print(f"[error] 维度 {d.name} 崩溃: {type(exc).__name__}: {exc}")
    return {
        "root": str(root),
        "files": len(files),
        "skipped": [{"path": str(p), "why": w} for p, w in skipped],
        "dimensions": [d.name for d in dimensions.build(dims)],
        "summary": summarize(findings),
        "findings": aggregate(findings, min_severity),
    }


def selftest(base="selftest/cases", expect_map=None):
    """clean 必须 0 命中；dirty 必须命中（按维度对照）。"""
    res = {}
    for case in ("clean", "dirty"):
        root = pathlib.Path(base) / case
        r = run_project(root, verbose=True)
        res[case] = r
        res[case]["ok"] = (len(r["findings"]) == 0) if case == "clean" \
            else (len(r["findings"]) > 0)
    return res


def resolve_root(project: str):
    """按 adapters/*.yml 解析源码根（相对仓库根）。"""
    import pathlib as _p
    here = _p.Path(__file__).resolve().parent.parent
    y = here / "adapters" / f"{project}.yml"
    if not y.exists():
        return None
    txt = y.read_text(encoding="utf-8")
    roots, base = [], None
    for line in txt.splitlines():
        ls = line.strip()
        if ls.startswith("source_roots:"):
            roots = [x.strip().strip('"') for x in ls.split(":", 1)[1].strip().strip("[]").split(",")]
        elif ls.startswith("repo_root:"):
            base = ls.split(":", 1)[1].strip().strip('"')
    cand = []
    for r in roots:
        if base:
            cand.append(_p.Path(base) / r)
        cand += [_p.Path(r), here.parent / r]
    for c in cand:
        if c.exists():
            return c
    return None
