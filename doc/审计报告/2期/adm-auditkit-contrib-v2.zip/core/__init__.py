"""ADM AuditKit · core —— 通用检测引擎。

20 个维度中 **12 个已实现**（均有真实项目确证缺陷背书），
8 个为占位（接口已定义，检测逻辑待补）——见 docs/维度矩阵.md。
"""
from . import dimensions  # noqa: F401
