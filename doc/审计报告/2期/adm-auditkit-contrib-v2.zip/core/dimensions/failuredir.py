"""失败方向：except 后的返回值/降级值，是 fail-open 还是 fail-closed。

判据（lesson 55/56/92）：
  · **全量枚举**所有 except 分支，不能只审安全模块
  · 判方向要看**降级值在调用点被读成什么**（`True`=放行 / `{}`=没有 / `None`=良好），
    不能只看"有没有 return"
  · 假阳性来源：**降级被显式暴露**（unverified 档、状态标志、注释说明），判前先排除
真实命中：MA-14（坏时间窗 → return True ⇒ 约束失效）
          MA-15（预检失败 → None = 覆盖良好）
          AF-R13-01（device_acl 损坏 → return None ⇒ Tier-0 保护消失，fail-open）
"""
from __future__ import annotations
import ast, re
from ..helpers import Dimension, Finding, iter_funcs, rel_path, has_trace, own_walk

#: 降级值 → 语义方向（在调用点通常被读成的含义）
FAIL_OPEN_VALUES = {
    "True": "放行 / 命中 / 通过",
    "1": "成功",
    "{}": "没有 / 空集",
    "[]": "没有 / 空集",
    "None": "无（视调用点而定，多数等于'没有'）",
}
TRACE_OK = re.compile(r"unverified|unknown|missing|degraded|unmodeled|poisoned")


class FailureDir(Dimension):
    name = "failuredir"
    lessons = "55,56,92,45,145"
    confirmed_by = "MA-14, MA-15, MA-16, AF-R13-01"
    noise = "medium"   # lesson 172：需人工按"降级值语义方向"复核

    def run(self, files, root, cfg=None, cg=None):
        out = []
        for path, fn, body in iter_funcs(files):
            for h in own_walk(fn):
                if not isinstance(h, ast.ExceptHandler):
                    continue
                try:
                    hb = ast.unparse(h)
                except Exception:
                    continue
                traced, _ = has_trace(h)
                if traced:
                    continue  # 降级但留痕 ⇒ 可观测，非"静默"（lesson 56/161）
                # 方向：找 except 体内的 return 值
                for node in ast.walk(h):
                    if isinstance(node, ast.Return) and node.value is not None:
                        try:
                            v = ast.unparse(node.value)
                        except Exception:
                            continue
                        if v in FAIL_OPEN_VALUES and not TRACE_OK.search(hb):
                            out.append(Finding(
                                self.name, rel_path(path, root),
                                getattr(node, "lineno", h.lineno), fn.name, "medium",
                                f"except 后返回 `{v}`（语义：{FAIL_OPEN_VALUES[v]}）——"
                                f"{'有留痕' if traced else '**无留痕**'}",
                                evidence=hb[:90],
                                lessons=self.lessons, confirmed_by=self.confirmed_by))
        return out
