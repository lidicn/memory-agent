"""无界状态增长：容器键来自外部输入且无淘汰/无上限。

判据（lesson 112/115）：**要查是"哪一个容器"有上限**——同族容器常只有一个漏掉。
对照法：列出同模块内所有模块级/实例级 dict，比较谁有 prune/上限。
真实命中：MA-20（_CONV_LOCKS 懒创建永不清除；同模块 _RUNS/_CONV 都有 200 上限）
          MA-21（_login_fails 键永不移除；同文件 _revoked_jtis 有 _prune_revoked）
          MA-22（XFF 可伪造 ⇒ 限流键无限增长）
"""
from __future__ import annotations
import ast, re
from ..helpers import Dimension, Finding, iter_funcs, rel_path, code_unparse, all_walk

EVICT = re.compile(r"(pop|del\s|clear\(|_prune|_evict|_trim|maxlen|deque|\.discard)")
BOUND = re.compile(r"(MAX|LIMIT|CAP|_max|上限)")


class Unbounded(Dimension):
    name = "unbounded"
    lessons = "23,112,115,166"
    confirmed_by = "MA-20, MA-21, MA-22"
    noise = "medium"

    def run(self, files, root, cfg=None, cg=None):
        out = []
        for path, tree in files:
            # 模块级容器赋值
            assigned = {}
            for n in all_walk(tree):
                val = tgt = None
                if isinstance(n, ast.Assign) and isinstance(n.value, (ast.Dict, ast.Call)):
                    val, tgt = n.value, n.targets
                elif isinstance(n, ast.AnnAssign) and isinstance(n.value, (ast.Dict, ast.Call)):
                    val, tgt = n.value, [n.target]
                if val is not None:
                    try:
                        v = ast.unparse(val)
                    except Exception:
                        continue
                    if re.match(r"(\{\}|dict\(\)|defaultdict)", v):
                        for t in tgt:
                            if isinstance(t, ast.Name):
                                assigned[t.id] = n.lineno
            if not assigned:
                continue
            # 该模块内是否有任何淘汰动作
            body_all = "\n".join(
                code_unparse(f) for f in all_walk(tree)
                if isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef)))
            for name, line in assigned.items():
                # 该容器是否被淘汰过
                evicted = re.search(rf"{name}\.(pop|clear|popitem)|\b{name}\s*=\s*\{{|del\s+{name}\[", body_all)
                if evicted or EVICT.search(body_all) and BOUND.search(body_all):
                    continue
                out.append(Finding(
                    self.name, rel_path(path, root), line, name, "medium",
                    f"模块级容器 `{name}` 无淘汰路径，且同模块未见上限常量",
                    evidence="需人工确认键空间是否有界（常量键 / 外部输入）",
                    lessons=self.lessons, confirmed_by=self.confirmed_by))
        return out
