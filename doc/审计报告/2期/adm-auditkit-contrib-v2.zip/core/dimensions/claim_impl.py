"""声明-实现对照：把 docstring/注释里**可验证的承诺**逐条拿去对照实现。

这是二十轮里命中最多的一类判据（贡献 MA-26/27/28/29/30/32/33/35 共 8 条）。
判据（lesson 126/127/128/131/136/137/152/153/164）：
  · 提取可验证声明：只校验 / 不写入 / 自增 / 幂等 / 周期 / 真源 / 全量 / 只读 / fail-closed
  · **dry_run 是独立的一类契约**——声明"只校验不写入"必须真的校验
  · "自增"类声明要测**连续两次调用**，只测一次看不出来
  · docstring 里**两条声明互相打架**时，实现一定只满足了一条
  · TODO/FIXME 桩的危险不在"没做"，在"返回 ok=True"
真实命中：MA-28（dry_run 直接 return ok=True，校验一行都没跑）
          MA-29/30（规则引擎 5 个动作全是桩却返回 ok，且落库 dry_run=0）
          MA-33（内置技能"真源/最新版本"声明，实际只判文件存在 ⇒ 升级后永不更新）
          MA-35（docstring 声称周期任务，实际只在 startup 跑一次）
"""
from __future__ import annotations
import ast, re
from ..helpers import Dimension, Finding, iter_funcs, rel_path, code_unparse

CLAIMS = {
    "dry_run/只校验": re.compile(r"(只校验|不写入|dry[_ ]?run=true)"),
    "自增": re.compile(r"(自增|version\s*\+\s*1|递增)"),
    "幂等": re.compile(r"(幂等|idempoten)"),
    "周期/定时": re.compile(r"(周期任务|定时|定期|每日|periodically)"),
    "真源/最新版本": re.compile(r"(唯一真源|真源|最新版本|single source)"),
    "只读/不落库": re.compile(r"(只读|不落库|只算不落库|不写入)"),
    "fail-closed": re.compile(r"(fail[- ]?closed|失败即拒|缺省即拒)"),
    "全量": re.compile(r"(全量|所有成?员|all members)"),
}


class ClaimVsImpl(Dimension):
    name = "claim_impl"
    lessons = "18,126,127,128,131,136,137,138,139,147,148,152,153,164"
    confirmed_by = "MA-26, MA-27, MA-28, MA-29, MA-30, MA-32, MA-33, MA-35, AF-R17-01"
    noise = "medium"

    def run(self, files, root, cfg=None, cg=None):
        out = []
        for path, fn, _b in iter_funcs(files):
            doc = ast.get_docstring(fn) or ""
            if not doc:
                continue
            try:
                code = code_unparse(fn)
            except Exception:
                continue
            hits = [k for k, pat in CLAIMS.items() if pat.search(doc)]
            if not hits:
                continue
            for claim in hits:
                bad = self._violation(claim, fn, code, doc)
                if bad:
                    out.append(Finding(
                        self.name, rel_path(path, root), fn.lineno, fn.name, "medium",
                        f"声明「{claim}」与实现不符：{bad}",
                        evidence=doc.strip().split("\n")[0][:80],
                        lessons=self.lessons, confirmed_by=self.confirmed_by))
        return out

    @staticmethod
    def _violation(claim, fn, code, doc):
        if claim == "dry_run/只校验":
            # dry_run 分支内是否有任何"校验"动作（raise / return error / validate）
            for n in ast.walk(fn):
                if isinstance(n, ast.If):
                    try:
                        cond = ast.unparse(n.test)
                    except Exception:
                        continue
                    if "dry_run" in cond:
                        # 校验若在 dry_run 分支**之前**已完成，则契约成立（clean 对照）
                        pre = "\n".join(ast.unparse(x) for x in fn.body[:fn.body.index(n)])
                        if re.search(r"(raise|return\s*\{[^}]*ok\s*:\s*False|error)", pre):
                            continue
                        body = "\n".join(ast.unparse(x) for x in n.body)
                        if re.search(r"return\s*\{", body) and not re.search(
                                r"(raise|validate|_check|assert|error|ok\s*=\s*False|len\(|not\s)", body):
                            return "dry_run 分支直接返回 ok，未做任何校验"
        if claim == "只读/不落库" and re.search(
                r"(insert_|upsert_|write_text|\.save\(\)|commit\(\)|delete_)", code):
            if not re.search(r"persist\s*=\s*False|if\s+persist|persist\s+is\s+False", code):
                return "声明只读但实现含写操作，且未见 persist 类开关"
        if claim == "周期/定时" and not any(
                isinstance(n, ast.While) for n in ast.walk(fn)):
            return "声明周期/定时，但函数内无循环（需人工确认调用点是否周期）"
        if claim == "fail-closed" and re.search(r"except[^\n]*:\s*\n\s*return\s*(True|1|\{\}|\[\])", code):
            return "声明 fail-closed，但 except 返回放行/空值"
        return None
