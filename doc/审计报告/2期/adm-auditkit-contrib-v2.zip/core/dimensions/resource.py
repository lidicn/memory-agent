"""资源生命周期：**重建后旧实例是否回收**。

判据（lesson 121/122/124/125）：
  ① 找 `self.X = New(...)` 且 `New` 类定义了 close/aclose/shutdown 的赋值点
  ② 查同函数内是否有"关旧实例"的动作
  ③ **全局 shutdown 正确 ≠ 热更新路径正确**——shutdown 只在进程退出跑一次，
     而 reconfigure 是运行期反复执行
真实命中：MA-25（llm_client.reconfigure 整表重建 providers，旧 AsyncClient 从不 close；
          实测 50 次配置保存 → 150 个未关闭连接；同函数 ha_db 那支却正确关了旧连接）
          AutoForge R4-01（os.fdopen 后又 os.close ⇒ 并发下关掉别人的 fd）
"""
from __future__ import annotations
import ast, re
from ..helpers import Dimension, Finding, iter_funcs, rel_path, code_unparse, all_walk

CLOSE = re.compile(r"(\.close\(\)|\.aclose\(\)|\.shutdown\(\)|\.stop\(\)|\.release\(\))")


class ResourceLifecycle(Dimension):
    name = "resource"
    lessons = "11,121,122,123,124,125"
    confirmed_by = "MA-25, AF-R4-01"
    noise = "medium"

    def run(self, files, root, cfg=None, cg=None):
        # 收集定义了 close 的类名
        closable = set()
        for path, tree in files:
            for cls in all_walk(tree):
                if isinstance(cls, ast.ClassDef):
                    for f in ast.walk(cls):
                        if isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef)) \
                                and re.match(r"(a?close|shutdown|stop)", f.name):
                            closable.add(cls.name)
        if not closable:
            return []
        out = []
        for path, fn, _b in iter_funcs(files):
            try:
                code = code_unparse(fn)
            except Exception:
                continue
            # self.X = New(...)  且 New 可关闭
            res_names = sorted(closable) + ["clients", "providers", "pool", "pools",
                                            "sessions", "conns", "handlers"]
            pat = rf"self\.(\w+)\s*=\s*(?:{ '|'.join(res_names) })\s*\(|self\.(clients|providers|pool|conns|handlers|sessions)\s*=\s*[^\n]"
            for m in re.finditer(pat, code):
                attr, cls = m.group(1), m.group(2)
                if not CLOSE.search(code):
                    out.append(Finding(
                        self.name, rel_path(path, root), fn.lineno, fn.name, "medium",
                        f"重建 `self.{attr}`（{cls} 定义了 close）但**同函数内未见关闭旧实例**",
                        evidence=m.group(0)[:70],
                        lessons=self.lessons, confirmed_by=self.confirmed_by))
        return out
