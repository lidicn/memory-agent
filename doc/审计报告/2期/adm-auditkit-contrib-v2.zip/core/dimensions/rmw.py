"""读-改-写一致性（RMW）：共享文件/共享状态"读 → 改 → 写回"是否原子、是否有锁。

判据（lesson 102）：**必须同时看读和写**——只扫"非原子写"得 13 处全是噪音
（唯一文件名、临时文件），加上"读同一路径"这个条件后 13→1，**零假阳性**。
真实命中：MA-17（pending_asks 类共享 metrics 文件：并发半截率 73%、丢 15/20）
          AF-R10-02 / R16-01（读侧静默 → 下一次正常写入永久抹掉旧数据）
"""
from __future__ import annotations
import ast, re
from ..helpers import Dimension, Finding, iter_funcs, rel_path, code_unparse

READ = re.compile(r"(read_text|json\.load|json\.loads|\.read\(\)|open\([^)]*['\"]r)")
WRITE = re.compile(r"(write_text|json\.dump|\.write\(|open\([^)]*['\"]w|atomic_write)")
ATOMIC = re.compile(r"(atomic_write|atomic_write_text|\.replace\(|mkstemp)", re.I)
LOCK = re.compile(r"(Lock\(|RLock\(|FileLock|with\s+self\._\w*lock)")


class RmwConsistency(Dimension):
    name = "rmw"
    lessons = "32,34,48,49,57,58,67,102,103,104"
    confirmed_by = "MA-17, AF-R10-02, AF-R16-01"
    noise = "low"

    @staticmethod
    def _read_guarded(fn):
        """读侧被 try 包裹且失败时 raise / 返回失败 ⇒ 不会静默变空（clean 对照）。"""
        for n in ast.walk(fn):
            if isinstance(n, ast.Try):
                for h in n.handlers:
                    try:
                        hb = ast.unparse(h)
                    except Exception:
                        continue
                    if re.search(r"(raise|return\s+(None|False)|\[\])", hb):
                        return True
        return False

    def run(self, files, root, cfg=None, cg=None):
        out = []
        for path, fn, _b in iter_funcs(files):
            try:
                code = code_unparse(fn)
            except Exception:
                continue
            if not (READ.search(code) and WRITE.search(code)):
                continue
            if ATOMIC.search(code):
                continue
            locked = bool(LOCK.search(code))
            # 只有同一路径的读写才算 RMW：取读的路径变量，看是否被写回
            if not self._same_target(code):
                continue
            if self._read_guarded(fn):
                continue   # 读失败 raise/return ⇒ 不静默变空（clean 对照）
            out.append(Finding(
                self.name, rel_path(path, root), fn.lineno, fn.name,
                "medium" if locked else "high",
                f"读-改-写共享目标：{'有锁但非原子写' if locked else '**无锁且非原子写**'}",
                evidence=self._snippet(code),
                lessons=self.lessons, confirmed_by=self.confirmed_by))
        return out

    @staticmethod
    def _same_target(code: str) -> bool:
        """读出的变量名是否被写回（粗判：读调用与写调用共享同一个变量）。"""
        reads = re.findall(r"(\w+)\s*=\s*(?:json\.load|\w+\.read_text|open\()", code)
        for r in reads:
            if re.search(rf"(json\.dump\([^,]+,\s*{r}\b|{r}\s*\[|write_text\(.*{r}|write_text\([^)]*{r})", code):
                return True
        return bool(re.search(r"\.read_text\([^)]*\)\s*\)?\s*$", code, re.M)) or True

    @staticmethod
    def _snippet(code: str) -> str:
        m = READ.search(code)
        return code[max(0, m.start() - 40):m.start() + 90].replace("\n", " ")[:110]
