"""可观测性：异常/失败被吞掉后是否留下可观测痕迹。

判据（lesson 40/47/90/159/160/161）：
  · **留痕必须认四叉**：log / raise / 计数 / **状态标志置位或记账列表 append**
    ——只认 log 会误判（毒化标志、记账列表都比 log 强）
  · 门禁的"空体检测"规则漏掉 `except: return None` 这类**体非空但无留痕**
  · 周期任务的日志**没提副作用**（如落库条数）⇒ 副作用不可见
真实命中：AF-R6-02（撤销快照抓不到仍下发，且 warning 文本写"不下发"而实际已下发）
          AF-R10-01（同一函数两档：校验和档有 warning、解析档无）
          MA-15（预检失败返回 None = 覆盖良好，与真"覆盖良好"逐字节相同）
"""
from __future__ import annotations
import ast, re
from ..helpers import Dimension, Finding, iter_funcs, rel_path, has_trace, own_walk


class Observability(Dimension):
    name = "observability"
    lessons = "40,47,90,159,160,161"
    confirmed_by = "AF-R6-02, AF-R10-01, MA-15"
    noise = "high"   # lesson 172：噪音最高的一档，务必人工复核"降级是否被显式暴露"

    def run(self, files, root, cfg=None, cg=None):
        out = []
        for path, fn, body in iter_funcs(files):
            for h in own_walk(fn):
                if not isinstance(h, ast.ExceptHandler):
                    continue
                try:
                    hb = ast.unparse(h)
                except Exception:
                    continue
                if len(hb.strip()) < 8:
                    continue  # 空体由 deadcode/noise 处理
                if h.type is not None and "CancelledError" in ast.unparse(h.type):
                    continue  # 关停语义 ≠ 容错语义（lesson 141）
                traced, how = has_trace(h)
                if traced:
                    continue
                out.append(Finding(
                    self.name, rel_path(path, root), h.lineno, fn.name, "low",
                    "except 分支吞掉失败且**未见留痕**（log/raise/计数/状态标志四叉均无）",
                    evidence=hb[:90],
                    lessons=self.lessons, confirmed_by=self.confirmed_by))
        return out
