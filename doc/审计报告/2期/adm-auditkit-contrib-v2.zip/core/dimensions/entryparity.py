"""入口对等性：同一能力有多个入口时，护栏是否覆盖**全部**入口。

判据（lesson 63）：不比"约束以什么形式出现"，比**最终汇聚到哪个函数**。
真实命中：
  · AutoForge R15-01  CLI `store save` 绕过静态扫描闸
  · AutoForge R18-01  CLI enable 绕过爆炸半径护栏
  · AutoForge R20-01  导入通道绕过 owner 隔离
  · memory-agent MA-34 persist 默认 True，MCP 传 False 而 API/周期任务不传
"""
from __future__ import annotations
import ast, re
from ..helpers import Dimension, Finding, iter_funcs, full_unparse, rel_path, code_unparse

#: 护栏调用名（末段）。命中即视为"过闸"。
GATE_CALLS = {
    "scan", "validate", "check_blast", "_check_blast", "check_owner",
    "require_user", "require_admin", "assert_write_tools_complete",
    "save_graph", "enable_by_tag", "svc_save", "svc_enable",
}
#: 危险海点：能改变持久态/对外副作用的调用
SINK_CALLS = {"save", "enable", "disable", "delete", "write_text", "commit",
              "upsert_candidate_rule", "import_bundle", "persist"}


class EntryParity(Dimension):
    name = "entryparity"
    lessons = "51,52,63,65,66,83,107,157,158,174"
    confirmed_by = "AF-R15-01, AF-R18-01, AF-R20-01, MA-34"
    noise = "low"

    def run(self, files, root, cfg=None, cg=None):
        # 1) 收集每个 sink 的调用点，及其所在函数的"上游函数链"
        calls = {}
        for path, fn, body in iter_funcs(files):
            for n in ast.walk(fn):
                if isinstance(n, ast.Call) and n.func.__class__.__name__ in ("Attribute", "Name"):
                    nm = getattr(n.func, "attr", None) or getattr(n.func, "id", None)
                    if nm in SINK_CALLS:
                        calls.setdefault(nm, []).append((path, fn, n, body))
        out = []
        for sink, sites in calls.items():
            if len(sites) < 2:
                continue  # 单入口无从谈对等
            gated = [(p, f) for p, f, n, b in sites if self._gated(f, b, cg)]
            ungated = [(p, f) for p, f, n, b in sites if not self._gated(f, b, cg)]
            if gated and ungated:
                for p, f in ungated:
                    out.append(Finding(
                        self.name, rel_path(p, root), f.lineno, f.name, "high",
                        f"入口不对等：`{sink}()` 共 {len(sites)} 个调用点，"
                        f"{len(gated)} 个过护栏、{len(ungated)} 个未过",
                        evidence=f"护栏调用 {sorted({c for g in gated for c in self._gates(g[1])})[:3]}",
                        lessons=self.lessons, confirmed_by=self.confirmed_by))
        return out

    @staticmethod
    def _gates(fn, body, cg):
        gates = set()
        for n in ast.walk(fn):
            if isinstance(n, ast.Call):
                nm = getattr(n.func, "attr", None) or getattr(n.func, "id", None)
                if nm in GATE_CALLS:
                    gates.add(nm)
        if gates:
            return gates
        # 传递闭包：闸可能在被调用方（lesson 65）
        if cg is not None:
            for n in ast.walk(fn):
                if isinstance(n, ast.Call) and cg.body_contains(
                        n, lambda s: any(g in s for g in GATE_CALLS), depth=2):
                    gates.add("<transitive>")
        return gates

    def _gated(self, fn, body, cg=None):
        return bool(self._gates(fn))

    @staticmethod
    def _gates(fn):
        return {getattr(n.func, "attr", None) or getattr(n.func, "id", None)
                for n in ast.walk(fn) if isinstance(n, ast.Call)
                and (getattr(n.func, "attr", None) or getattr(n.func, "id", None)) in GATE_CALLS}
