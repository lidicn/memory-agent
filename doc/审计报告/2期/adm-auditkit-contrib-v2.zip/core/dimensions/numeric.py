"""数值 / 时间边界：外部数值进 SQL LIMIT、timedelta、切片前是否钳制。

判据（lesson 81/82/86/87/88/98）：
  · SQLite `LIMIT -1` = **无上限**（不是 0 条也不是报错）
  · `timedelta` 极值抛 **OverflowError**，且它**不是** ValueError
     ⇒ 路由的 `except (TypeError, ValueError)` 兜不住
  · 只有下界（`max(1, x)`、`if x<0: x=0`）**不构成钳制**
  · 极值不崩 ≠ 安全（1e9 分钟 → 窗口回溯到公元 124 年）
  · 判"全表风险"必须追到 store 方法内部（下游钳制与否不一致）
真实命中：MA-07/09（?limit=-1 → 300/150 条全表；abc → 500）
          MA-11/12/13（minutes=2e9 → OverflowError 500）
"""
from __future__ import annotations
import ast, re
from ..helpers import Dimension, Finding, iter_funcs, rel_path, code_unparse

LIMIT_SQL = re.compile(r"(LIMIT\s*\?|limit\s*=\s*\w+|\"LIMIT|'LIMIT)")
TIMEDELTA = re.compile(r"timedelta\(")
CLAMP = re.compile(r"(max\(|min\(|clamp|_num\(|hi=|lo=)")


class NumericBoundary(Dimension):
    name = "numeric"
    lessons = "81,82,84,86,87,88,98,108"
    confirmed_by = "MA-07, MA-08, MA-09, MA-10, MA-11, MA-12, MA-13"
    noise = "medium"

    def run(self, files, root, cfg=None, cg=None):
        out = []
        for path, fn, _b in iter_funcs(files):
            try:
                code = code_unparse(fn)
            except Exception:
                continue
            # 形参里的 limit/offset/days/minutes 等，是否在下推前被钳制
            params = [a.arg for a in fn.args.args + fn.args.kwonlyargs]
            ext = [p for p in params if re.match(r"(limit|offset|days|minutes|hours|seconds|top_k|count|max_)", p)]
            if not ext:
                continue
            for p in ext:
                used = re.search(rf"\b{p}\b", code)
                if not used:
                    continue
                # 该参数是否被钳制
                clamped = re.search(rf"(max\(|min\(|clamp|_num\()[^\n]*\b{p}\b|\b{p}\b[^\n]*(max\(|min\()", code)
                if clamped or CLAMP.search(code):
                    continue
                kind = "SQL LIMIT" if LIMIT_SQL.search(code) else (
                    "timedelta" if TIMEDELTA.search(code) else "外部数值")
                out.append(Finding(
                    self.name, rel_path(path, root), fn.lineno, fn.name, "medium",
                    f"外部数值参数 `{p}` 未见钳制即下推（{kind}）",
                    evidence=f"形参: {', '.join(ext)[:60]}",
                    lessons=self.lessons, confirmed_by=self.confirmed_by))
        return out
