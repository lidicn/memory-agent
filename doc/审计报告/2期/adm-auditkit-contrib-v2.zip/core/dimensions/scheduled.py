"""周期/清理路径：**先看有没有周期触发者**，再看实现。

判据（lesson 162/163/164）：
  实现正确 ≠ 策略生效。清理函数写得再好，没有周期调用者就等于没做。
  ① 扫出 prune/purge/expire/cleanup 类函数
  ② 列**全部调用点**，判断是否在 `while True` 内
  ③ docstring 里写"周期任务/定时跑"是最直接的声明来源，与实现不符即缺陷
真实命中：MA-35（purge_old / purge_idempotency / purge_mcp_audit 只在 startup 跑一次，
          声明 90 天保留期实际 456 天 = 5.1×）
"""
from __future__ import annotations
import ast, re, pathlib
from ..helpers import Dimension, Finding, iter_funcs, rel_path, all_walk

CLEAN = re.compile(r"(prune|purge|retention|cleanup|clean_|gc|vacuum|trim|expire|evict)", re.I)
CLAIM = re.compile(r"(周期任务|定时|定期|每日|periodically|scheduled)")


class Scheduled(Dimension):
    name = "scheduled"
    lessons = "77,142,144,162,163,164,165,161"
    confirmed_by = "MA-35"
    noise = "low"

    @staticmethod
    def _is_host(fn):
        """自身是周期宿主：含 while True 且含 sleep（clean 对照 periodic_cleanup）。"""
        try:
            code = ast.unparse(fn)
        except Exception:
            return False
        return bool(re.search(r"while\s+True", code)) and bool(
            re.search(r"(asyncio\.sleep|time\.sleep|await\s+\w+\.sleep)", code))

    def run(self, files, root, cfg=None, cg=None):
        # 1) 找出所有清理函数
        cleaners = {}
        for path, tree in files:
            for fn in all_walk(tree):
                if isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)) and CLEAN.search(fn.name):
                    cleaners.setdefault(fn.name, []).append((path, fn))
        if not cleaners:
            return []
        # 2) 预扫描：哪些函数体位于 while True 内（周期任务的宿主）
        periodic_hosts = set()
        for path, tree in files:
            for fn in all_walk(tree):
                if isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    if any(isinstance(w, ast.While) for w in ast.walk(fn)):
                        periodic_hosts.add(fn.name)
        # 2.5) 自身即周期宿主的清理函数不算缺陷（clean 对照 periodic_cleanup）
        for name, sites in list(cleaners.items()):
            cleaners[name] = [(p, f) for p, f in sites if not self._is_host(f)]
        for name, sites in list(cleaners.items()):
            sites = [(p, f) for p, f in sites
                     if "pop(" not in (ast.unparse(f) if hasattr(f, "body") else "")
                     and " del " not in (ast.unparse(f) if hasattr(f, "body") else "")]
            cleaners[name] = sites
        cleaners = {k: v for k, v in cleaners.items() if v}
        if not cleaners:
            return []
        # 3) 每个清理函数的调用点，是否落在周期宿主内
        callers = {}
        for path, tree in files:
            src = pathlib.Path(path).read_text(errors="ignore")
            for cname in cleaners:
                for m in re.finditer(rf"\b{cname}\b", src):
                    if re.match(rf"def\s+{cname}\b", src[m.start():m.start() + len(cname) + 5]):
                        continue
                    callers.setdefault(cname, set()).add(rel_path(path, root))
        out = []
        for cname, defs in cleaners.items():
            (path, fn), = defs[:1]
            sites = callers.get(cname, set())
            if not sites:
                out.append(Finding(
                    self.name, rel_path(path, root), fn.lineno, cname, "medium",
                    f"清理函数 `{cname}` **无任何调用点**（死代码或无触发者）",
                    lessons=self.lessons, confirmed_by=self.confirmed_by))
                continue
            # 是否任一调用点位于 while True 宿主内
            if not any(s in periodic_hosts for s in sites):
                doc = ast.get_docstring(fn) or ""
                sev = "high" if CLAIM.search(doc) else "medium"
                out.append(Finding(
                    self.name, rel_path(path, root), fn.lineno, cname, sev,
                    f"清理函数 `{cname}` 的调用点均**不在周期循环内**"
                    + ("，且 docstring 声称是周期任务 ⇒ 声明与实现不符" if CLAIM.search(doc) else ""),
                    evidence="; ".join(sorted(sites))[:80],
                    lessons=self.lessons, confirmed_by=self.confirmed_by))
        return out
