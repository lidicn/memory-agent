"""配置面健壮性：环境变量 / HTTP 可写配置 → 系统行为。

核心认识（lesson 28）：**配置是"运维面的不可信输入"**，与 HTTP 请求同属边界。
判据（lesson 29/30/31/110）：
  · 裸 `int(os.getenv(...))` / `float(...)` 无 try 无边界 ⇒ 配错即崩或静默失效
  · **类型收敛 ≠ 校验**（这是最容易漏的一类）
  · "0 = 不限"类开关必须校验负数与极大值
  · 最快入口：grep `P\d+-\d+ 修复` 注释找已修范式，再看铺开度
真实命中：AF-R9-02（AUTOFORGE_BLAST_RADIUS 负数 ⇒ 护栏静默失效，fail-open）
          MA-18（24 个数值键无范围校验，tz_offset_hours 极值 → ValueError 崩）
          MA-19（两个写入端点口径不一致：/api/config 接受 0，/api/collect/config 钳 900）
"""
from __future__ import annotations
import ast, re
from ..helpers import Dimension, Finding, iter_funcs, rel_path, code_unparse

ENV_GET = re.compile(r"(os\.getenv|os\.environ\.get|getenv)")
NUM_CAST = re.compile(r"\b(int|float)\s*\(")
GUARD = re.compile(r"(try:|except|clamp|_num|_env_number|max\(|min\(|lo=|hi=)")


class ConfigSurface(Dimension):
    name = "config"
    lessons = "28,29,30,31,87,106,107,108,109,110,146"
    confirmed_by = "AF-R9-02, MA-18, MA-19, MA-11/12/13"
    noise = "low"

    def run(self, files, root, cfg=None, cg=None):
        out = []
        # 模块级裸数值转换（AF-R9-01：配错即模块导入崩溃）
        for path, tree in files:
            for n in ast.walk(tree):
                val = tgt = None
                if isinstance(n, ast.Assign):
                    val, tgt = n.value, n.targets
                elif isinstance(n, ast.AnnAssign) and n.value is not None:
                    val, tgt = n.value, [n.target]
                if val is None:
                    continue
                try:
                    expr, names = ast.unparse(val), [ast.unparse(t) for t in tgt]
                except Exception:
                    continue
                if NUM_CAST.search(expr) and ENV_GET.search(expr) and not GUARD.search(expr):
                    out.append(Finding(
                        self.name, rel_path(path, root), n.lineno, ", ".join(names), "medium",
                        "模块级裸数值转换环境变量：配错即导入崩溃",
                        evidence=expr[:70], lessons=self.lessons, confirmed_by=self.confirmed_by))
        for path, fn, _b in iter_funcs(files):
            try:
                code = code_unparse(fn)
            except Exception:
                continue
            for m in NUM_CAST.finditer(code):
                seg = code[max(0, m.start() - 120):m.start() + 160]
                if not ENV_GET.search(seg):
                    continue
                if GUARD.search(seg):
                    continue
                out.append(Finding(
                    self.name, rel_path(path, root), fn.lineno, fn.name, "medium",
                    "环境变量裸数值转换：无 try、无上下界 ⇒ 配错即崩或静默失效",
                    evidence=seg.split("\n")[0][:90],
                    lessons=self.lessons, confirmed_by=self.confirmed_by))
        return out
