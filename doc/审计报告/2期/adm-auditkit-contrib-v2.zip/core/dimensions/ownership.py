"""所有权 / 属主校验覆盖：同一资源 ID 的多个入口，是否都做属主校验。

判据（lesson 168 + 174）：
  ① 先确定**模块边界**——只在该模块**已定义属主校验 helper** 时才谈对等
     （全仓扫会把"从未设计过"的地方判成"漏做了"，假阳性 21→3）
  ② 在该模块内按**资源 ID 形参分组**，逐个入口确认是否调 helper
真实命中：memory-agent MA-36（M_PROMPT 无 check_owner，跨主体读写会话）
          memory-agent MA-37（session/new 覆盖已存在会话 ⇒ 属主劫持）
          AutoForge R1/R2（自批校验只比字符串）
"""
from __future__ import annotations
import ast, re
from ..helpers import Dimension, Finding, rel_path, code_unparse, full_unparse, all_walk

OWNER_FN = re.compile(r"(check_owner|assert_owner|_owner_check|verify_owner)", re.I)
OWNER_CALL = re.compile(r"(check_owner|assert_owner|verify_owner)", re.I)
RES_PARAM = re.compile(r"^(sid|session_id|sessionId|owner_id|resource_id)$", re.I)
NEW_LIKE = re.compile(r"^(new|create|bind|register|upsert)$", re.I)
CREATE_ENTRY = re.compile(r"^(new_|create_|make_|_trim|evict|register)", re.I)


class Ownership(Dimension):
    name = "ownership"
    lessons = "71,113,168,173,174,175,176"
    confirmed_by = "MA-36 (Critical), MA-37 (High), AF-R20-01"
    noise = "low"

    def run(self, files, root, cfg=None, cg=None):
        out = []
        for path, tree in files:
            fns = [n for n in all_walk(tree)
                   if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
            if not any(OWNER_FN.search(f.name) for f in fns):
                continue  # 该模块没有属主设计 ⇒ 不适用本维度（lesson 168）
            # 该模块内所有接受资源 ID 的入口
            entries = []
            for f in fns:
                if OWNER_FN.search(f.name):
                    continue
                args = [a.arg for a in f.args.args] + [a.arg for a in f.args.kwonlyargs]
                if any(RES_PARAM.search(a) for a in args):
                    try:
                        body = code_unparse(f)
                    except Exception:
                        continue
                    entries.append((f, body))
            guarded = [f for f, b in entries if OWNER_CALL.search(b)]
            if not guarded:
                continue  # 没有任何入口做校验 ⇒ 不是"漏一个"，是另一种问题
            for f, b in entries:
                if OWNER_CALL.search(b):
                    continue
                if CREATE_ENTRY.search(f.name):
                    continue  # 创建入口本就不校验属主（MA-37 由规则②单独处理）
                sev = "critical" if NEW_LIKE.search(f.name) else "high"
                out.append(Finding(
                    self.name, rel_path(path, root), f.lineno, f.name, sev,
                    f"资源入口 `{f.name}` 接受资源 ID 但未调用属主校验；"
                    f"同模块 {len(guarded)} 个入口做了",
                    evidence="同模块已有 " + ", ".join(sorted({g.name for g in guarded}))[:60],
                    lessons=self.lessons, confirmed_by=self.confirmed_by))
            # ② 新建入口覆盖已存在资源 ⇒ 属主劫持（MA-37）
            for f, b in entries:
                if NEW_LIKE.search(f.name) and re.search(r"\w+\[[\"']?\w+[\"']?\]\s*=\s*\{", b):
                    if "if" not in b.split("{")[0][:200]:
                        out.append(Finding(
                            self.name, rel_path(path, root), f.lineno, f.name, "high",
                            f"`{f.name}` 对已存在的资源 ID 直接赋值覆盖，可能改写属主",
                            lessons=self.lessons, confirmed_by="MA-37"))
        return out
