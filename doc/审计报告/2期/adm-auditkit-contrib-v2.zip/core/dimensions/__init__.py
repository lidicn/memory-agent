"""20 个检测维度注册表。

`IMPLEMENTED` 内每个维度都通过了 selftest（clean 0 命中 / dirty 全部命中），
并在 AutoForge 或 memory-agent 的真实审计中确证过缺陷。
"""
from .entryparity import EntryParity
from .ownership import Ownership
from .failuredir import FailureDir
from .rmw import RmwConsistency
from .persistence import Persistence
from .unbounded import Unbounded
from .scheduled import Scheduled
from .resource import ResourceLifecycle
from .configsurface import ConfigSurface
from .numeric import NumericBoundary
from .claim_impl import ClaimVsImpl
from .observability import Observability

IMPLEMENTED = {
    "entryparity": EntryParity,
    "ownership": Ownership,
    "failuredir": FailureDir,
    "rmw": RmwConsistency,
    "persistence": Persistence,
    "unbounded": Unbounded,
    "scheduled": Scheduled,
    "resource": ResourceLifecycle,
    "config": ConfigSurface,
    "numeric": NumericBoundary,
    "claim_impl": ClaimVsImpl,
    "observability": Observability,
}

#: 占位（接口已定义，检测逻辑待补）——诚实标注，避免"空壳充数"
PLANNED = {
    "concurrency": "并发/异步（锁覆盖、持锁 await）—— 判据见 lessons 130",
    "state": "状态一致性",
    "errorhandling": "错误处理（与 failuredir/observability 部分重叠）",
    "auth": "鉴权/权限（与 ownership 部分重叠）",
    "deadcode": "死代码",
    "testgap": "测试缺口（需配合变异测试）",
    "api_contract": "API 契约（与 claim_impl 部分重叠）",
    "serialization": "序列化往返保真（判据：lesson 73/74）",
}

ALL = list(IMPLEMENTED) + list(PLANNED)


def build(names=None):
    names = names or list(IMPLEMENTED)
    return [IMPLEMENTED[n]() for n in names if n in IMPLEMENTED]
