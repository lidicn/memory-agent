"""持久化留痕：磁盘数据回到内存时，解析失败是否留痕。

核心认识（AutoForge 二十轮、memory-agent 二十轮反复出现）：
  **磁盘数据是"上一进程留下的不可信输入"**，与 HTTP 请求同属边界。
判据（lesson 32/33/42/43）：
  · 找所有"读盘 → 解析"点（JSON / JSONL / 逐行）
  · **在同一函数内做不对称对比**：一档留痕一档不留 ⇒ 后者是缺陷
  · 循环内裸解析 ⇒ 不是"跳过一条"，是**炸掉整批**（lesson 42）
真实命中：MA-01/02/03（for line: json.loads 无 try ⇒ 整批失效）
          AF-R10-01（同一函数两档：校验和档有 warning、解析档无）
"""
from __future__ import annotations
import ast, re
from ..helpers import Dimension, Finding, iter_funcs, rel_path, has_trace, own_walk

PARSE = re.compile(r"(json\.loads|json\.load|safe_json_loads|yaml\.safe_load)")


class Persistence(Dimension):
    name = "persistence"
    lessons = "32,33,42,43,48,159"
    confirmed_by = "MA-01, MA-02, MA-03, AF-R10-01"
    noise = "low"

    def run(self, files, root, cfg=None, cg=None):
        out = []
        for path, fn, body in iter_funcs(files):
            # 收集该函数内的解析调用
            parses = [n for n in own_walk(fn)
                      if isinstance(n, ast.Call) and PARSE.search(ast.unparse(n.func) or "")]
            if not parses:
                continue
            guarded = [p for p in parses if self._in_try(fn, p)]
            unguarded = [p for p in parses if not self._in_try(fn, p)]
            if not unguarded:
                continue
            # 循环内裸解析 = 炸穿整批（最严重）
            in_loop = any(self._in_loop(fn, p) for p in unguarded)
            sev = "high" if in_loop else "medium"
            # 不对称对比：同函数里既有留痕档又有无痕档 ⇒ 更强证据（lesson 33）
            asym = bool(guarded)
            for p in unguarded:
                out.append(Finding(
                    self.name, rel_path(path, root), p.lineno, fn.name, sev,
                    (f"解析未受保护{'（**在循环内 ⇒ 一条坏数据炸掉整批**）' if in_loop else ''}"
                     + ("；同函数内另有解析点有保护 ⇒ 不对称" if asym else "")),
                    evidence=(ast.unparse(p) or "")[:80],
                    lessons=self.lessons, confirmed_by=self.confirmed_by))
        return out

    @staticmethod
    def _in_try(fn, target):
        for t in own_walk(fn):
            if isinstance(t, ast.Try):
                if any(n is target for n in ast.walk(t)):
                    return True
        return False

    @staticmethod
    def _in_loop(fn, target):
        for t in own_walk(fn):
            if isinstance(t, (ast.For, ast.While)):
                if any(n is target for n in ast.walk(t)):
                    return True
        return False
