"""结果聚合 + 噪音分档 + 排序。"""
from __future__ import annotations



try:
    from core.helpers import SEV_ORDER
except ImportError:  # 允许直接 python core/aggregate.py 运行
    from helpers import SEV_ORDER


def aggregate(findings: list[dict], min_severity: str = "low") -> list[dict]:
    thr = SEV_ORDER.get(min_severity, 3)
    kept = [f for f in findings if SEV_ORDER.get(f["severity"], 9) <= thr]
    kept.sort(key=lambda f: (SEV_ORDER.get(f["severity"], 9), f["file"], f["line"]))
    return kept


def summarize(findings: list[dict]) -> dict:
    by_sev, by_dim = {}, {}
    for f in findings:
        by_sev[f["severity"]] = by_sev.get(f["severity"], 0) + 1
        by_dim[f["dimension"]] = by_dim.get(f["dimension"], 0) + 1
    return {"total": len(findings), "by_severity": by_sev, "by_dimension": by_dim}
