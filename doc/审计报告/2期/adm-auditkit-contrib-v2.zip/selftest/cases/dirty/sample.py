"""脏样本：12 种**已确证缺陷**形态的最小复现。

每条都标注来源（AF-Rxx = AutoForge 轮次缺陷，MA-xx = memory-agent 缺陷），
selftest 期望：每个形态**至少被一个维度命中**。

注意：本文件是**故意写错**的，仅用于验证检测引擎，不得作为实现参考。
"""
from __future__ import annotations
import asyncio, json, os, time
from pathlib import Path


# ── 1. 循环内裸 json.loads，坏数据炸掉整个循环 ───────────── MA-01/02/03
def list_rules(rows):
    out = []
    for r in rows:
        out.append(json.loads(r["tags_json"]))
    return out


# ── 2. 坏时间窗 return True（放行）────────────────────────── MA-04/14
def _in_time_window(spec, hour):
    """坏 condition 不能退化成放行。"""
    try:
        lo, hi = spec.split("-")
        return int(lo) <= hour <= int(hi)
    except Exception:
        return True


# ── 3. LIMIT ? 下推未钳制（SQLite 中 -1 = 无上限）────────── MA-07/09
def query_events(conn, limit):
    return conn.execute("SELECT * FROM events LIMIT ?", (limit,))


# ── 4. timedelta 有下界无上界（溢出 / 静默回溯）───────────── MA-11/12/13
def collect(minutes):
    if minutes < 0:
        minutes = 0
    return time.time() - minutes * 60


# ── 5. RMW：读失败静默变空 ⇒ 下次正常写入抹掉历史 ───────── AF-R10-02 / AF-R16-01
def set_alias(path, alias, target):
    try:
        data = json.loads(Path(path).read_text())
    except Exception:
        data = {}
    data[alias] = target
    Path(path).write_text(json.dumps(data))


# ── 6. 共享文件 RMW 非原子、无锁 ──────────────────────────── MA-17
def metrics_ingest(path, payload):
    store = json.loads(Path(path).read_text())
    store.update(payload)
    Path(path).write_text(json.dumps(store))


# ── 7. 无界容器（无淘汰/无上限）───────────────────────────── MA-20/21
_FAILS: dict = {}
_SEEN: dict = {}


def note_fail(ip):
    _FAILS.setdefault(ip, []).append(time.time())


# ── 8. 清理函数无周期触发（只在启动时跑一次）───────────────── MA-35
def purge_old(conn, days):
    """按保留期清理（周期任务，定时跑）。"""
    conn.execute("DELETE FROM events WHERE day < ?", (days,))


# ── 9. 重建旧实例不 close ─────────────────────────────────── MA-25
class Router:
    def __init__(self):
        self.clients = {}

    def reconfigure(self, cfg):
        self.clients = {k: _mk(cfg, k) for k in ("a", "b")}


def _mk(cfg, k):
    return Client()


class Client:
    def close(self):
        pass


# ── 10. 配置面裸数值转换，配错即崩 / 护栏静默失效 ──────────── AF-R9-01 / AF-R9-02
SESSION_TTL_S = int(os.getenv("SESSION_TTL_S", "1800"))
BLAST_RADIUS = int(os.getenv("BLAST_RADIUS", "8"))


def check_blast(count, limit=BLAST_RADIUS):
    if limit > 0 and count > limit:
        raise ValueError("too many")
    return True


# ── 11. 入口对等：同一资源 ID，一个入口校验一个不校验 ───────── MA-36 / AF-R15-01
OWNERS: dict = {}


def check_owner(sid, owner_token):
    if not owner_token:
        return False
    return OWNERS.get(sid) == owner_token


def session_history(sid, caller):
    if not check_owner(sid, caller):
        return {"ok": False, "error": "denied"}
    return {"ok": True, "messages": []}


def do_prompt(sid, caller):
    """能力最强的入口，却**不做属主校验** —— 与 session_history 不对称。"""
    return {"ok": True, "session_id": sid}


# ── 12. dry_run 假绿：声明只校验，实际校验一行都没跑 ────────── MA-28 / MA-29
def teach_signal(dry_run, entity_id, kind, text):
    """dry_run=true：只校验参数，不写入。"""
    if dry_run:
        return {"ok": True, "dry_run": True, "message": "参数校验通过，未写入"}
    if not entity_id:
        return {"ok": False, "error": "entity_id 不能为空"}
    return {"ok": True}
