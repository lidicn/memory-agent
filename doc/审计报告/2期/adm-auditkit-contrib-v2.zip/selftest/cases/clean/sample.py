"""干净样本：所有确证缺陷形态的**正确实现**对照。

selftest 期望：本文件**全部维度 0 命中**。
若某个维度在本文件命中，说明该维度有假阳性，必须先修维度再提交。
"""
from __future__ import annotations
import asyncio, json, logging, os, threading
from pathlib import Path

_log = logging.getLogger(__name__)


def clamp_limit(v, default=50, lo=1, hi=500):
    """外部数值参数：解析兜底 + 上下界钳制 + 警告（对照 MA-18/19）。"""
    try:
        n = int(v)
    except (TypeError, ValueError):
        _log.warning("limit 非法，回落默认 %s", default)
        return default
    return max(lo, min(n, hi))


def load_records(path):
    """JSONL 逐行解析：坏行保留 + 留痕（对照 MA-01/02/03、AF-R12-01）。"""
    kept = []
    try:
        with open(path, encoding="utf-8") as fh:
            for no, line in enumerate(fh, 1):
                try:
                    kept.append(json.loads(line))
                except ValueError:
                    _log.warning("第 %d 行坏数据，保留原文（不静默丢数据）", no)
                    kept.append({"_raw": line, "_bad": True})
    except OSError as exc:
        _log.error("无法读取 %s: %s", path, exc)
        raise
    return kept


def save_tags(path, tag, who):
    """RMW：读失败必须 raise，不能用空集写回（对照 AF-R10-02、AF-R16-01）。"""
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise RuntimeError(f"tags 损坏，拒绝写入以免覆盖: {exc}") from exc
    data.setdefault("tags", {})[tag] = [who]
    Path(path).write_text(json.dumps(data), encoding="utf-8")
    return data


def check_owner(sid, owner_token):
    """属主校验 fail-closed（对照 MA-36/37）。"""
    if not owner_token:
        return False
    return OWNERS.get(sid) == owner_token


def handle(session_id, caller):
    """入口：接受资源 ID 就校验属主（对照 MA-36）。"""
    if not check_owner(session_id, caller):
        return {"ok": False, "error": "无权访问"}
    return {"ok": True}


def new_session(session_id, owner_token):
    """已存在资源不得改写属主（对照 MA-37）。"""
    if session_id in OWNERS and OWNERS[session_id] != owner_token:
        raise ValueError("sessionId 已被占用")
    OWNERS[session_id] = owner_token
    return session_id


def dry_run_check(params):
    """dry_run：先校验再返回（对照 MA-28）。

    dry_run=true：只校验参数，不写入。
    """
    if not params.get("entity_id"):
        return {"ok": False, "error": "entity_id 不能为空"}
    if not params.get("text"):
        return {"ok": False, "error": "text 必须提供"}
    if params.get("dry_run"):
        return {"ok": True, "dry_run": True, "dispatched": False}
    return {"ok": True, "dry_run": False, "dispatched": True}


def reload_credentials(path):
    """重载失败保留旧值，绝不把已知值清零（对照 AF-R19-01）。"""
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        _log.warning("凭据重载失败，保留旧值: %s", exc)
        return _CURRENT


def in_time_window(spec, hour):
    """坏时间窗返回 None 而非 True（对照 MA-04/14）。"""
    try:
        lo, hi = spec.split("-")
        return int(lo) <= hour <= int(hi)
    except (ValueError, AttributeError):
        _log.warning("坏时间窗 %r（不命中）", spec)
        return None


async def periodic_cleanup(store, interval=86400):
    """周期清理：while True 宿主 + 失败留痕（对照 MA-35）。"""
    while True:
        try:
            await asyncio.sleep(interval)
            n = await asyncio.to_thread(store.purge_old, 90)
            print(f"[cleanup] 清理 {n} 行")
        except asyncio.CancelledError:
            return
        except Exception as exc:
            print(f"[cleanup] 清理失败: {exc}")


class ClientPool:
    """重建前关闭旧实例（对照 MA-25）。"""

    def __init__(self):
        self._lock = threading.RLock()
        self._clients = {}

    def reconfigure(self, cfg):
        new = build_clients(cfg)
        with self._lock:
            for old in self._clients.values():
                try:
                    old.close()
                except Exception as exc:
                    _log.warning("关闭旧 client 失败: %s", exc)
            self._clients = new


def build_clients(cfg):
    return {}


OWNERS: dict = {}
_CURRENT: dict = {}
MAX_OWNERS = 200


def _trim_owners():
    """有界容器：超限淘汰最旧（对照 MA-20/21）。"""
    while len(OWNERS) > MAX_OWNERS:
        OWNERS.pop(next(iter(OWNERS)))
