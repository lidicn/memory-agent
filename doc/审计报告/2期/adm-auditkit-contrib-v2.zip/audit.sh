#!/usr/bin/env bash
# ADM AuditKit 统一入口。
#   ./audit.sh --selftest
#   ./audit.sh --project ma --dimensions ownership,rmw
#   ./audit.sh --project db --all --output report.md
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

PROJECT=""; DIMS=""; OUTPUT=""; FMT="markdown"; ROOT=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --project) PROJECT="$2"; shift 2 ;;
    --dimensions) DIMS="$2"; shift 2 ;;
    --all) DIMS="all"; shift ;;
    --output) OUTPUT="$2"; shift 2 ;;
    --json) FMT="json"; shift ;;
    --root) ROOT="$2"; shift 2 ;;
    --selftest)
      exec python3 -c "
import sys, pathlib; sys.path.insert(0, '.')
from core.runner import selftest
sys.exit(0 if selftest(pathlib.Path('selftest/cases')) else 1)"
      ;;
    --list)
      exec python3 -c "
import sys; sys.path.insert(0,'.')
from core.dimensions import IMPLEMENTED, PLANNED
print('已实现:', ', '.join(IMPLEMENTED)); print('待补  :', ', '.join(PLANNED))"
      ;;
    *) echo "未知参数: $1"; exit 2 ;;
  esac
done

if [[ -z "$PROJECT" && -z "$ROOT" ]]; then
  echo "用法: $0 --project {db|af|ma|dp} [--all|--dimensions a,b] [--output f] [--json]"
  echo "      $0 --selftest | --list | --root /path/to/src"
  exit 2
fi

exec python3 - "$PROJECT" "$DIMS" "$OUTPUT" "$FMT" "$ROOT" <<'PY'
import sys, pathlib
sys.path.insert(0, ".")
from core.runner import run_project, resolve_root
from report.generator import write
project, dims, output, fmt, root = sys.argv[1:6]
src = pathlib.Path(root) if root else resolve_root(project)
if src is None or not src.exists():
    print(f"[audit] 源码根不存在: {src}"); sys.exit(2)
d = [x.strip() for x in dims.split(",") if x.strip()] if dims else None
res = run_project(src, dims=d)
res["meta"] = {"project": project or src.name, "root": str(src),
               "dimensions_implemented": len(__import__("core.dimensions", fromlist=["x"]).IMPLEMENTED),
               "dimensions_planned": len(__import__("core.dimensions", fromlist=["x"]).PLANNED)}
out = output or f"report-{project or src.name}.md"
write(res, out, fmt)
s = res["summary"]
print(f"[audit] {src} → {s['total']} 条 "
      f"(critical {s['by_severity'].get('critical',0)} / high {s['by_severity'].get('high',0)})")
print(f"[audit] 报告: {out}")
if res.get("skipped"):
    print(f"[audit] ⚠️ 跳过(语法错误) {len(res['skipped'])} 个文件")
sys.exit(0)
PY
