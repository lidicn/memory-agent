#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""`timedelta(days=...)` 窗口的极值/负值防护分诊量具（审计第八轮 P3-2）。

为什么要分诊而不是"所有 days 都 clamp 一遍"：
全仓 99 处 `timedelta(days=...)` 里，绝大多数是 `days=1`、`days=7`、`now.weekday()`
这类**根本不受外部输入影响**的字面量或日期算式；把上界加到它们身上只是噪音，
而把上界一刀切加到保留期（`data_retention_days`）上会把合法的多年保留裁掉。
真正要防的是**值来自外部**的那些：MCP 工具形参、HTTP 查询参数，以及
"从问句里正则出来的天数"（`最近 999999 天`）——最后这类最容易漏，
因为它的变量名不叫 `days`。

归属（每个站点必须落到一类，否则 `unclassified` 判红）：
  external   —— 表达式的值可追溯到某个函数形参（含"形参→局部变量→days"的传递）
  config     —— 来自 `config.*` / `self.config.*` / `rt.config.*`（运维侧配置，另册登记）
  literal    —— 整数字面量（含负字面量）
  date_math  —— 由 `.weekday()` 一类日期算式导出（构造上有界 0..6）
  local      —— 其它局部派生值（读代码定档后写 `# day-ok:` 或改成上面几类）

防护（guard）：
  bounded    —— 表达式里有 `min(...)`，或调用了 clamp 类助手（`clamp_days(...)`）
  lo_only    —— 只有 `max(...)`，防负值不防极值
  unguarded  —— 两者皆无
`external` 必须 `bounded`，或在同行/上一行有 `# day-ok: 理由`。其余归属允许 unguarded。

用法：
    python scripts/scan_day_bounds.py [根目录 ...]      # 默认 src/memory_agent
    python scripts/scan_day_bounds.py --self-test
退出码：0 干净 / 1 有违规或冲突 / 2 量具自检失败
"""
import argparse
import ast
import os
import sys

MARKER = "day-ok"
CLAMPS = ("clamp_days", "safe_days", "bounded_days")
CONFIG_ROOTS = ("config", "cfg")
LABELS = ("external", "config", "literal", "date_math", "local")
GUARDS = ("bounded", "lo_only", "unguarded")

_SRC_CACHE = {}


def _lines_of(path):
    if path not in _SRC_CACHE:
        try:
            with open(path, encoding="utf-8") as fh:
                _SRC_CACHE[path] = fh.read().splitlines()
        except Exception:  # noqa: BLE001
            _SRC_CACHE[path] = []
    return _SRC_CACHE[path]


def _is_timedelta(node):
    if not isinstance(node, ast.Call):
        return False
    f = node.func
    return (isinstance(f, ast.Name) and f.id == "timedelta") or \
           (isinstance(f, ast.Attribute) and f.attr == "timedelta")


def _names(node):
    """表达式里出现的自由名字（Attribute 只取根名，如 config.window_days → config）。"""
    out = set()
    for sub in ast.walk(node):
        if isinstance(sub, ast.Name):
            out.add(sub.id)
        elif isinstance(sub, ast.Attribute):
            root = sub
            while isinstance(root, ast.Attribute):
                root = root.value
            if isinstance(root, ast.Name):
                out.add(root.id)
    return out


def _has_call_named(node, names):
    for sub in ast.walk(node):
        if isinstance(sub, ast.Call):
            f = sub.func
            if isinstance(f, ast.Name) and f.id in names:
                return True
            if isinstance(f, ast.Attribute) and f.attr in names:
                return True
    return False


def _has_weekday(node):
    for sub in ast.walk(node):
        if isinstance(sub, ast.Call):
            f = sub.func
            if isinstance(f, ast.Attribute) and f.attr == "weekday":
                return True
    return False


def _has_bound(expr_node):
    """表达式自己就带上界：有 min(...) 或 clamp 助手。"""
    return _has_call_named(expr_node, {"min"} | set(CLAMPS))


def _assignments(func_node):
    """name → [(lineno, value_has_bound)]，覆盖 Name/Tuple/List 目标与增广赋值。"""
    out = {}
    for sub in ast.walk(func_node):
        if not isinstance(sub, (ast.Assign, ast.AugAssign, ast.AnnAssign)):
            continue
        if getattr(sub, "value", None) is None:
            continue
        bounded = _has_bound(sub.value)
        for name in _target_names(sub):
            out.setdefault(name, []).append((sub.lineno, bounded))
    return out


def _bounded_at(func_node, site_lineno):
    """站点行之前"最后一次赋值是带上界赋值"的名字才算有界。

    不看行号就会误判：`voice_util.resolve_window` 里 `n` 先在字面量元组循环中用、
    之后才在问句正则分支里 `clamp_days` 过——按集合算会认为这一行也有界，
    于是把"标记 + 有界"判成冲突，反而藏住真正裸奔的站点。

    也避免逼人重复 clamp：`cd = clamp_days(days)` 之后 `timedelta(days=cd)` 视为有界。
    """
    assigns = _assignments(func_node)
    for _ in range(8):
        cur = {n for n, hist in assigns.items() for (ln, b) in hist if b and ln < site_lineno}
        grew = False
        for sub in ast.walk(func_node):
            if not isinstance(sub, (ast.Assign, ast.AugAssign, ast.AnnAssign)):
                continue
            if getattr(sub, "value", None) is None or sub.lineno >= site_lineno:
                continue
            refs = _names(sub.value)
            if not refs or not refs <= cur:
                continue
            for name in _target_names(sub):
                entry = (sub.lineno, True)
                if entry not in assigns.setdefault(name, []):
                    assigns[name].append(entry)
                    grew = True
        if not grew:
            break
    out = set()
    for name, hist in assigns.items():
        before = [(ln, b) for ln, b in hist if ln < site_lineno]
        if not before:
            continue
        last = max(ln for ln, _ in before)
        if any(b for ln, b in before if ln == last):
            out.add(name)
    return out


def _guard_of(expr_node, bounded_vars=frozenset()):
    if _has_bound(expr_node):
        return "bounded"
    refs = _names(expr_node)
    if refs and refs <= set(bounded_vars):
        return "bounded"
    if _has_call_named(expr_node, {"max"}):
        return "lo_only"
    return "unguarded"


def _config_shaped(node):
    """表达式里是否出现配置链：根名 config/cfg，或属性段 .config/.cfg（self.config.x / rt.config.x）。"""
    for sub in ast.walk(node):
        if isinstance(sub, ast.Attribute) and sub.attr in CONFIG_ROOTS:
            return True
        if isinstance(sub, ast.Name) and sub.id in CONFIG_ROOTS:
            return True
    return False


def _target_names(node):
    """赋值语句里"能被再引用"的名字目标：跳过 self.x / d["k"] 这类非 Name 目标，
    并展开 a, b = ... 的元组目标。"""
    out = set()
    targets = list(getattr(node, "targets", None) or [])
    if not targets and getattr(node, "target", None) is not None:
        targets = [node.target]
    for t in targets:
        if isinstance(t, ast.Name):
            out.add(t.id)
        elif isinstance(t, (ast.Tuple, ast.List)):
            for e in t.elts:
                if isinstance(e, ast.Name):
                    out.add(e.id)
    return out


def _propagate(func_node, seeds):
    """从种子名出发做污染闭包：种子，以及被"引用了已污染名字"的赋值目标。"""
    tainted = set(seeds)
    for _ in range(8):
        before = len(tainted)
        for sub in ast.walk(func_node):
            if isinstance(sub, (ast.Assign, ast.AugAssign, ast.AnnAssign)):
                if sub.value is None or not _names(sub.value) & tainted:
                    continue
                tainted |= _target_names(sub)
        if len(tainted) == before:
            break
    return tainted


def _param_names(func_node):
    out = set()
    for a in list(func_node.args.posonlyargs) + list(func_node.args.args) + \
            list(func_node.args.kwonlyargs):
        out.add(a.arg)
    if func_node.args.vararg:
        out.add(func_node.args.vararg.arg)
    if func_node.args.kwarg:
        out.add(func_node.args.kwarg.arg)
    return out


def _taint_sets(func_node):
    """返回 (形参污染集, 配置污染集)。配置优先于形参：cfg.window_days 是运维口径，
    不是 LLM 能填的入参——两者的处置不同，不能混成一格。"""
    params = _param_names(func_node)
    cfg_seeds = {n for n in params if n in CONFIG_ROOTS}
    cfg_tainted = set(cfg_seeds)
    for sub in ast.walk(func_node):
        if isinstance(sub, (ast.Assign, ast.AnnAssign)) and sub.value is not None \
                and _config_shaped(sub.value):
            cfg_tainted |= _target_names(sub)
    cfg_tainted = _propagate(func_node, cfg_tainted)
    param_tainted = _propagate(func_node, params) - cfg_tainted
    return param_tainted, cfg_tainted


def _enclosing_func(tree, lineno):
    best = None
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            end = getattr(node, "end_lineno", node.lineno)
            if node.lineno <= lineno <= end:
                if best is None or node.lineno > best.lineno:
                    best = node
    return best


def _markers_in_range(lines, lo, hi):
    """同一行或上一行的 `# day-ok:` 说明。"""
    found = []
    for i in range(max(0, lo - 2), min(len(lines), hi)):
        ln = lines[i]
        pos = ln.find(MARKER)
        if pos >= 0:
            found.append(ln[pos + len(MARKER):].lstrip(": ").strip())
    return found


def classify(func_node, expr_node):
    """返回 (归属标签, 依据)。配置链优先于形参污染，字面量与日期算式最先。"""
    if isinstance(expr_node, ast.Constant) and isinstance(expr_node.value, int):
        return "literal", "int literal"
    if isinstance(expr_node, ast.UnaryOp) and isinstance(expr_node.operand, ast.Constant) \
            and isinstance(expr_node.operand.value, int):
        return "literal", "int literal"
    if _has_weekday(expr_node):
        return "date_math", "weekday()"
    names = _names(expr_node)
    tainted, cfg_tainted = _taint_sets(func_node) if func_node else (set(), set())
    if _config_shaped(expr_node) or (names & cfg_tainted):
        return "config", "attr:" + ",".join(sorted(names & (cfg_tainted | set(CONFIG_ROOTS))))
    hit = names & tainted
    if hit:
        return "external", "param-tainted:" + ",".join(sorted(hit))
    return "local", "no param taint"


def scan_file(path):
    src_lines = _lines_of(path)
    try:
        tree = ast.parse("".join(l + "\n" for l in src_lines))
    except Exception as exc:  # noqa: BLE001
        return [{"file": path, "line": 0, "label": "parse_fail", "guard": "-",
                 "marker": "", "detail": repr(exc)[:80], "expr": ""}]
    rows = []
    for node in ast.walk(tree):
        if not _is_timedelta(node):
            continue
        func = _enclosing_func(tree, node.lineno)
        bvars = _bounded_at(func, node.lineno) if func else frozenset()
        for kw in node.keywords:
            if kw.arg != "days":
                continue
            expr = kw.value
            label, why = classify(func, expr)
            guard = _guard_of(expr, bvars)
            markers = _markers_in_range(src_lines, node.lineno, node.lineno)
            rows.append({
                "file": path.replace("\\", "/"), "line": node.lineno,
                "label": label, "guard": guard, "marker": markers[0] if markers else "",
                "detail": why, "expr": ast.unparse(expr)[:70],
            })
    return rows


def problems_of(rows):
    """判红：external 无防护、无归属、标记打在不需要防护的站点上、以及窗口上界缺失。"""
    probs = []
    for r in rows:
        if r["label"] == "parse_fail":
            probs.append(f"CONFLICT:parse_fail {r['file']}:{r['line']} {r['detail']}")
            continue
        if r["label"] not in LABELS:
            probs.append(f"unclassified {r['file']}:{r['line']} days={r['expr']}")
            continue
        if r["label"] == "external" and r["guard"] != "bounded" and not r["marker"]:
            probs.append(f"UNGUARDED-EXTERNAL {r['file']}:{r['line']} "
                         f"guard={r['guard']} days={r['expr']} ({r['detail']})")
        if r["marker"] and r["label"] != "external":
            probs.append(f"CONFLICT:marker_on_{r['label']} {r['file']}:{r['line']} "
                         f"'{r['marker']}'")
        if r["marker"] and r["guard"] == "bounded":
            probs.append(f"CONFLICT:marked+bounded {r['file']}:{r['line']} '{r['marker']}'")
    return probs


def counts_of(rows):
    c = {f"label_{k}": sum(1 for r in rows if r["label"] == k) for k in LABELS}
    c.update({f"guard_{k}": sum(1 for r in rows if r["guard"] == k) for k in GUARDS})
    c["marked"] = sum(1 for r in rows if r["marker"])
    c["total_timedelta_days"] = len(rows)
    return c


def scan_root(root):
    rows = []
    for dirpath, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for fn in sorted(files):
            if fn.endswith(".py"):
                rows.extend(scan_file(os.path.join(dirpath, fn)))
    return rows


# ── 量具自证：正样本必须被抓，负样本不许误报 ─────────────────────────────────
POSITIVE = {
    # 形参直传，无上下界（第八轮报的那一格）
    "p1_param_unguarded.py": "def f(days):\n    from datetime import timedelta\n    return timedelta(days=days)\n",
    # 形参→局部变量→days（名字不叫 days 也须判红）
    "p2_param_renamed.py": "def f(days):\n    from datetime import timedelta\n    span = days * 1\n    return timedelta(days=span)\n",
    # 从问句里正则出来的天数（本批新发现的那一格）
    "p3_regex_from_question.py": ("import re\nfrom datetime import timedelta\n\n\n"
                                  "def f(q):\n    m = re.search(r'(\\d+)', q)\n"
                                  "    n = int(m.group(1))\n    return timedelta(days=n)\n"),
    # 只有 max（防负不防极）也要红
    "p4_lo_only.py": "from datetime import timedelta\n\n\ndef f(days):\n    return timedelta(days=max(1, days))\n",
    # 打了标记但仍无防护，且标记打在 external 上是合法的——这条测的是"标记+bounded 冲突"
    "p5_marked_and_bounded.py": ("from datetime import timedelta\n\n\ndef f(days):\n"
                                 "    # day-ok: 说明\n    return timedelta(days=max(1, min(days, 3650)))\n"),
    # 元组解包目标（a, b = days, 1）也必须带上污染——这条是量具自己踩过的坑
    "p6_tuple_target.py": ("from datetime import timedelta\n\n\ndef f(days):\n"
                           "    a, b = days, 1\n    return timedelta(days=a)\n"),
    # 上一行 clamp 过的变量混在未防护变量里 → 仍然要红（防"半有界"蒙混过关）
    "p7_half_bounded.py": ("from datetime import timedelta\n\n\ndef f(days, other):\n"
                           "    cd = max(1, min(days, 365))\n    return timedelta(days=cd + other)\n"),
    # clamp 发生在站点**之后**（同名变量先在裸分支里用）：站点处并没有界，必须红
    "p8_bounded_only_after_site.py": ("from datetime import timedelta\n\n\ndef f(n):\n"
                                      "    first = timedelta(days=n)\n"
                                      "    n = clamp_days(n)\n    return first, timedelta(days=n)\n"),
}
NEGATIVE = {
    "n1_literal.py": "from datetime import timedelta\n\n\ndef f(now):\n    return timedelta(days=1)\n",
    "n2_bounded.py": "from datetime import timedelta\n\n\ndef f(days):\n    return timedelta(days=max(1, min(int(days or 7), 3650)))\n",
    "n3_clamp_helper.py": "from datetime import timedelta\n\n\ndef f(days):\n    return timedelta(days=clamp_days(days))\n",
    "n4_date_math.py": "from datetime import timedelta\n\n\ndef f(now):\n    return timedelta(days=now.weekday())\n",
    "n5_config.py": "from datetime import timedelta\n\n\ndef f(cfg):\n    return timedelta(days=cfg.retention_days)\n",
    "n6_marked_external.py": ("from datetime import timedelta\n\n\ndef f(days):\n"
                              "    return timedelta(days=days)  # day-ok: 上游入口已收敛\n"),
    "n7_module_level_no_func.py": ("from datetime import datetime, timedelta\n\n"
                                   "TODAY = datetime(2026, 1, 1)\n"
                                   "START = TODAY - timedelta(days=1)\n"),
    # 变量在上一行已被 max/min 收敛：站点自身没有 min 也算有界（否则逼人重复 clamp）
    "n8_bounded_var.py": ("from datetime import timedelta\n\n\ndef f(days):\n"
                          "    cd = max(1, min(int(days or 7), 365))\n"
                          "    return timedelta(days=cd)\n"),
}


def self_test():
    import tempfile
    ok = True
    with tempfile.TemporaryDirectory() as tmp:
        for name, body in POSITIVE.items():
            p = os.path.join(tmp, name)
            with open(p, "w", encoding="utf-8", newline="\n") as fh:
                fh.write(body)
            rows = scan_file(p)
            probs = problems_of(rows)
            caught = [x for x in probs if not x.startswith("CONFLICT:parse")]
            if not caught:
                print(f"SELFTEST_MISS {name} expected a finding, got {rows}")
                ok = False
            else:
                print(f"SELFTEST_HIT {name} -> {caught[0].split(' ')[0]}")
        for name, body in NEGATIVE.items():
            p = os.path.join(tmp, name)
            with open(p, "w", encoding="utf-8", newline="\n") as fh:
                fh.write(body)
            rows = scan_file(p)
            probs = problems_of(rows)
            if probs:
                print(f"SELFTEST_FALSE {name} -> {probs}")
                ok = False
            else:
                print(f"SELFTEST_CLEAN {name} label={rows[0]['label'] if rows else '-'}")
    return 0 if ok else 2


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("root", nargs="*", default=["src/memory_agent"])
    ap.add_argument("--self-test", action="store_true")
    args = ap.parse_args(argv)
    if args.self_test:
        return self_test()
    rows = []
    for root in args.root:
        rows.extend(scan_root(root))
    c = counts_of(rows)
    probs = problems_of(rows)
    print("ROOT=" + ",".join(args.root) + " " +
          " ".join(f"{k}={v}" for k, v in sorted(c.items())))
    for p in probs:
        print("PROBLEM " + p)
    if probs:
        print(f"SCAN_RC=1 共 {len(probs)} 处判红")
        return 1
    print("SCAN_RC=0 每个 timedelta(days=) 站点都有归属")
    return 0


if __name__ == "__main__":
    sys.exit(main())
