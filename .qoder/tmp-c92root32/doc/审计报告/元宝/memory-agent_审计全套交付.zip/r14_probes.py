# -*- coding: utf-8 -*-
"""R14 探针（第十四轮）：69 处静默降级正确性验证

静默降级 = 捕获异常后返回"看起来正常"的空结果，而非抛出/标记错误。
危害分级：
  D1 致命：吞掉了本应暴露的失败，且返回值会被当作有效数据继续处理
  D2 有害：降级值语义错误（如返回空列表却声称有数据）
  D3 可接受：明确的容错，有注释说明，且降级值语义正确
"""
import ast, os, json, collections, re

SRC = "/data/workspace/ma/src/memory_agent"
OUT = "/data/workspace/audit_out"

def iter_py():
    for dp, _, fs in os.walk(SRC):
        for f in fs:
            if f.endswith(".py"):
                yield os.path.join(dp, f)

# 降级值模式 → 语义
RET_PATS = [
    (r"return\s+\{\s*\}", "空dict"),
    (r"return\s+\[\s*\]", "空list"),
    (r"return\s+None", "None"),
    (r"return\s+set\(\s*\)", "空set"),
    (r"return\s+0\s*$", "0"),
    (r"return\s+(\"\"|'')\s*$", "空串"),
    (r"return\s+\{\s*[\"']ok[\"']\s*:\s*True", "ok:True空信封"),
    (r"return\s+\{\s*[\"']ok[\"']\s*:\s*False", "ok:False"),
    (r"return\s+\(\s*\)", "空tuple"),
]

def probe_silent_degrade():
    rows = []
    for pth in iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            src = open(pth, encoding="utf-8").read()
            lines = src.splitlines()
            t = ast.parse(src)
        except Exception:
            continue
        for n in ast.walk(t):
            if not isinstance(n, ast.ExceptHandler):
                continue
            # handler body
            body_src = "\n".join(ast.unparse(s) for s in n.body)
            if "pass" in body_src and len(n.body) <= 1:
                kind = "pass"
            else:
                kind = None
                for p, k in RET_PATS:
                    if re.search(p, body_src):
                        kind = k
                        break
            if kind is None:
                continue
            # 是否有日志
            has_log = bool(re.search(r"log(ger)?\.(warning|error|exception|info|debug)|print\s*\(",
                                     body_src))
            # 是否有注释说明（handler 上方 3 行）
            lo = n.lineno
            ctx_lines = lines[max(0, lo - 4):lo]
            has_comment = any(l.strip().startswith("#") for l in ctx_lines)
            # 异常是否绑定
            bound = n.name is not None
            rows.append({
                "file": rel, "line": lo, "kind": kind,
                "has_log": has_log, "has_comment": has_comment, "bound": bound,
                "body": body_src[:100],
            })
    return rows

def probe_degrade_decorator():
    """@_degrade 装饰器的降级工厂：检查降级值是否带 error 字段"""
    rows = []
    for pth in iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            src = open(pth, encoding="utf-8").read()
            t = ast.parse(src)
        except Exception:
            continue
        for n in ast.walk(t):
            if not isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for d in n.decorator_list:
                if "_degrade" not in ast.unparse(d):
                    continue
                rows.append({"file": rel, "line": n.lineno, "name": n.name,
                             "factory": ast.unparse(d)[:110]})
    return rows

def main():
    os.makedirs(OUT, exist_ok=True)
    r1 = probe_silent_degrade()
    r2 = probe_degrade_decorator()
    print(f"R14-1 静默降级点（except→空值/pass）: {len(r1)}")
    c = collections.Counter(x["kind"] for x in r1)
    print(f"    降级值类型: {dict(c.most_common())}")
    nolog = [x for x in r1 if not x["has_log"]]
    print(f"    其中**无日志**: {len(nolog)}  ← 最危险（失败完全不可见）")
    nolog_nc = [x for x in nolog if not x["has_comment"]]
    print(f"    无日志且无注释: {len(nolog_nc)}  ← 最高优先级")
    print()
    print("    无日志无注释 明细（前 20）:")
    for x in nolog_nc[:20]:
        print(f"        {x['file']}:{x['line']}  [{x['kind']}]  {x['body'][:60]}")
    print()
    print(f"R14-2 @_degrade 装饰器: {len(r2)} 处")
    noerr = [x for x in r2 if '"error"' not in x["factory"] and "'error'" not in x["factory"]]
    print(f"    工厂不含 error 字段: {len(noerr)}")
    json.dump({"silent": r1, "decorator": r2},
              open(os.path.join(OUT, "probes_r14.json"), "w"), ensure_ascii=False, indent=1)
    return r1, r2

if __name__ == "__main__":
    main()
