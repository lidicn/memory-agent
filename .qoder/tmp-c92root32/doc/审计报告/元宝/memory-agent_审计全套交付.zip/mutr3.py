# -*- coding: utf-8 -*-
"""R3-3 定向变异测试器：量化「现有测试能否抓到缺陷」

mutmut 3.8 在 54k 行仓库上生成阶段过慢，改用定向变异：
  对目标代码施加语义变异 → 跑全量测试 → 测试仍全绿 = 变异存活 = 测试抓不到该处缺陷

用法: python3 mutr3.py exp | ctrl | all
  exp  = 实验组：同时变异两个 0% 覆盖模块的缺陷点
  ctrl = 对照组：变异高覆盖模块（改名，必然报错，验证测试确实在跑）
"""
import json
import os
import re
import subprocess
import sys

REPO = "/data/workspace/ma"
SRC = os.path.join(REPO, "src", "memory_agent")
OUT = "/data/workspace/audit_out"

EXP = [
    (os.path.join(SRC, "behavior_predictor.py"),
     "P1-4 到家时间: 取每天首条 → 无条件覆盖(取最后一条)",
     "        if day not in daily_arrivals:\n            daily_arrivals[day] = hour",
     "        daily_arrivals[day] = hour"),
    (os.path.join(SRC, "identity_fusion.py"),
     "P1-5 归一化分母 ×1.5",
     "total_weight = sum(W.get(src, 0.1) for src in active_weights)",
     "total_weight = sum(W.get(src, 0.1) for src in active_weights) * 1.5"),
    (os.path.join(SRC, "daily_profile.py"),
     "P1-6 回家基线: 取每天首条 → 无条件覆盖(取最后一条)",
     "        if day not in daily_hours:\n            daily_hours[day] = hour",
     "        daily_hours[day] = hour"),
]

CTRL = [
    (os.path.join(SRC, "store.py"),
     "对照组: now_local 改名（必然报错，验证测试确实在执行）",
     "def now_local(",
     "def now_local_MUT("),
]


def apply(path, old, new):
    orig = open(path, encoding="utf-8").read()
    if old not in orig:
        return None
    open(path, "w", encoding="utf-8").write(orig.replace(old, new, 1))
    return orig


def run_tests():
    r = subprocess.run(
        "cd %s && JWT_SECRET=mutx python3 -m pytest tests -q --no-header "
        "-p no:cacheprovider 2>&1 | tail -4" % REPO,
        shell=True, capture_output=True, text=True, timeout=900)
    out = (r.stdout or "") + (r.stderr or "")
    lines = [l for l in out.strip().splitlines() if l.strip()]
    killed = bool(re.search(r"\d+ (failed|error)", out))
    return killed, (lines[-1] if lines else out[-200:])


def run_group(targets, tag):
    os.makedirs(OUT, exist_ok=True)
    applied = []
    missed = []
    for path, name, old, new in targets:
        if not os.path.exists(path):
            missed.append(name + "（文件不存在）")
            continue
        orig = apply(path, old, new)
        if orig is None:
            missed.append(name + "（片段未命中）")
        else:
            applied.append((path, orig, name))
    print("[%s] 已施加变异 %d 处，未命中 %d 处" % (tag, len(applied), len(missed)))
    for m in missed:
        print("       未命中:", m)
    if not applied:
        return {"tag": tag, "status": "无变异可跑"}
    try:
        killed, tail = run_tests()
    except Exception as e:
        killed, tail = None, "运行异常 %s" % type(e).__name__
    finally:
        for path, orig, _ in applied:
            open(path, "w", encoding="utf-8").write(orig)
    res = {"tag": tag, "mutations": [a[2] for a in applied],
           "missed": missed, "killed": killed, "tail": str(tail)[:300]}
    verdict = "被杀(测试抓到)" if killed else ("存活(测试漏掉)" if killed is False else "异常")
    print("[%s] 结果: %s" % (tag, verdict))
    print("       %s" % str(tail)[:150])
    json.dump(res, open(os.path.join(OUT, "mutation_%s.json" % tag), "w"),
              ensure_ascii=False, indent=1)
    return res


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "all"
    if which in ("exp", "all"):
        run_group(EXP, "exp")
    if which in ("ctrl", "all"):
        run_group(CTRL, "ctrl")
