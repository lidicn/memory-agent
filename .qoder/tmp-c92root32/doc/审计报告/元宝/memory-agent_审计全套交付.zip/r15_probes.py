# -*- coding: utf-8 -*-
"""R15 探针（第十五轮 · 终轮）：缓存/状态一致性

  R15-1 缓存失效对称性：有缓存写入(set/赋值) 是否有对应失效(clear/pop/invalidate/TTL)
  R15-2 缓存 key 完整性：key 是否包含所有影响结果的入参
  R15-3 状态机：状态字段赋值集合 vs 判定集合（是否存在未被判定的状态）
"""
import ast, os, json, collections, re

SRC = "/data/workspace/ma/src/memory_agent"
OUT = "/data/workspace/audit_out"

def iter_py():
    for dp, _, fs in os.walk(SRC):
        for f in fs:
            if f.endswith(".py"):
                yield os.path.join(dp, f)

CACHE_NAME = re.compile(r"^(_)?\w*(cache|CACHE|Cache|_memo|MEMO)\w*$")

def probe_cache_invalidation():
    """找：被写入的缓存容器/属性，但全文中无失效动作"""
    rows = []
    for pth in iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            src = open(pth, encoding="utf-8").read()
            t = ast.parse(src)
        except Exception:
            continue
        # 收集缓存名（模块级 + self._xxx_cache）
        names = set()
        for n in t.body:
            if isinstance(n, ast.Assign) and n.targets and isinstance(n.targets[0], ast.Name):
                if CACHE_NAME.match(n.targets[0].id):
                    names.add(n.targets[0].id)
            elif isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name):
                if CACHE_NAME.match(n.target.id):
                    names.add(n.target.id)
        for n in ast.walk(t):
            if isinstance(n, ast.Attribute) and CACHE_NAME.match(n.attr or ""):
                names.add(n.attr)
            if isinstance(n, ast.Name) and CACHE_NAME.match(n.id):
                names.add(n.id)
        for nm in sorted(names):
            if len(nm) < 4:
                continue
            writes = len(re.findall(rf"{re.escape(nm)}\s*\[[^\]]*\]\s*=|{re.escape(nm)}\.(append|add|update|setdefault)\s*\("
                                    rf"|{re.escape(nm)}\s*=\s*\{{", src))
            invalid = len(re.findall(rf"{re.escape(nm)}\.(clear|pop|popitem)\s*\(|{re.escape(nm)}\s*=\s*(\{{\}}|None)"
                                     rf"|del\s+{re.escape(nm)}\[", src))
            if writes and not invalid:
                rows.append({"file": rel, "cache": nm, "writes": writes,
                             "invalid": invalid})
    return rows

def probe_cache_key():
    """找：以 dict 元组/kwargs 构造的缓存 key，检查是否遗漏关键入参"""
    rows = []
    for pth in iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            src = open(pth, encoding="utf-8").read()
            t = ast.parse(src)
        except Exception:
            continue
        for n in ast.walk(t):
            if not isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            seg = ast.unparse(n)
            if "cache" not in seg.lower():
                continue
            # 找形如 key = (a, b, c)
            for m in re.finditer(r"key\s*=\s*\(([^)]{0,180})\)", seg):
                rows.append({"file": rel, "line": n.lineno, "name": n.name,
                             "key": m.group(1)[:170],
                             "params": [a.arg for a in n.args.args]})
    return rows

def probe_state_machine():
    """状态字段：赋值集合 vs 判定集合 的差集"""
    rows = []
    for pth in iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            src = open(pth, encoding="utf-8").read()
            t = ast.parse(src)
        except Exception:
            continue
        fields = collections.defaultdict(lambda: {"set": set(), "cmp": set()})
        for n in ast.walk(t):
            if isinstance(n, ast.Assign):
                for tg in n.targets:
                    if (isinstance(tg, ast.Attribute)
                            and isinstance(tg.value, ast.Name)
                            and tg.value.id in ("self", "s", "rec", "item", "st")):
                        v = ast.unparse(n.value)
                        if isinstance(n.value, ast.Constant) and isinstance(n.value.value, str):
                            fields[tg.attr]["set"].add(n.value.value)
            if isinstance(n, ast.Compare):
                left = ast.unparse(n.left)
                m = re.match(r"^(?:self|s|rec|item|st)\.(\w+)$", left)
                if m:
                    for c in n.comparators:
                        if isinstance(c, ast.Constant) and isinstance(c.value, str):
                            fields[m.group(1)]["cmp"].add(c.value)
        for f, d in fields.items():
            if d["set"] and d["cmp"]:
                orphan = d["set"] - d["cmp"]
                if orphan:
                    rows.append({"file": rel, "field": f,
                                 "set": sorted(d["set"]), "cmp": sorted(d["cmp"]),
                                 "orphan": sorted(orphan)})
    return rows

def main():
    os.makedirs(OUT, exist_ok=True)
    r1 = probe_cache_invalidation()
    r2 = probe_cache_key()
    r3 = probe_state_machine()
    print(f"R15-1 有写入但无失效的缓存: {len(r1)}")
    for x in r1[:14]:
        print(f"    {x['file']}  {x['cache']}  写入{x['writes']} 失效{x['invalid']}")
    print(f"\nR15-2 缓存 key 构造: {len(r2)}")
    for x in r2[:10]:
        print(f"    {x['file']}:{x['line']} {x['name']}()")
        print(f"        key = ({x['key'][:110]})")
        print(f"        入参 = {x['params'][:8]}")
    print(f"\nR15-3 状态字段『赋值但未判定』: {len(r3)}")
    for x in r3[:12]:
        print(f"    {x['file']}  .{x['field']}")
        print(f"        赋值 {x['set']}")
        print(f"        判定 {x['cmp']}")
        print(f"        ★未判定 {x['orphan']}")
    json.dump({"cache": r1, "key": r2, "state": r3},
              open(os.path.join(OUT, "probes_r15.json"), "w"), ensure_ascii=False, indent=1)
    return r1, r2, r3

if __name__ == "__main__":
    main()
