# -*- coding: utf-8 -*-
"""R10 生命周期 / 资源 / 历史修复回归探针（第十轮 · V4 迭代）
  R10-1 后台任务启停对称性：task_registry.create 是否有对应 cancel/shutdown
  R10-2 长跑资源增长点：无上限容器 / 定时器未取消 / 订阅者未退订
  R10-3 历史审计修复验证：抽取项目自带 7 轮审计的修复标记，验证是否落地
"""
import ast, os, json, re, collections
SRC = "/data/workspace/ma/src/memory_agent"
REPO = "/data/workspace/ma"
OUT = "/data/workspace/audit_out"

def iter_py():
    for dp, _, fs in os.walk(SRC):
        for f in fs:
            if f.endswith(".py"):
                yield os.path.join(dp, f)

# ── R10-1 任务启停对称性 ──────────────────────────────────────
def probe_task_lifecycle():
    rows = []
    for pth in iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            src = open(pth, encoding="utf-8").read()
            t = ast.parse(src)
        except Exception:
            continue
        creates = len(re.findall(r"task_registry\.create\s*\(", src))
        cancels = len(re.findall(r"\.cancel\s*\(\s*\)", src))
        shutdown = len(re.findall(r"task_registry\.(shutdown|drain|stop|close)\s*\(", src))
        if creates:
            rows.append({"file": rel, "create": creates, "cancel": cancels,
                         "shutdown": shutdown})
    return rows

# ── R10-2 长跑资源增长点 ──────────────────────────────────────
def probe_resource_growth():
    """查找：无上限的模块级容器、未取消的定时器、未退订的订阅者"""
    rows = []
    for pth in iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            src = open(pth, encoding="utf-8").read()
            t = ast.parse(src)
        except Exception:
            continue
        for n in t.body:
            name = None
            if isinstance(n, ast.Assign) and n.targets and isinstance(n.targets[0], ast.Name):
                name = n.targets[0].id
            elif isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name):
                name = n.target.id
            if not name:
                continue
            v = ast.unparse(n.value) if n.value else ""
            if not (v.startswith(("{", "dict(")) or v.startswith(("[", "list("))
                    or v.startswith("set(")):
                continue
            # 全文中该名字是否有 pop/clear/淘汰/上限逻辑
            body = src
            has_evict = (re.search(rf"{name}\.pop\b", body) or re.search(rf"{name}\.clear\b", body)
                         or re.search(rf"len\({name}\)\s*>\s*\w+", body)
                         or re.search(rf"while\s+len\({name}\)", body)
                         or re.search(rf"del\s+{name}\[", body))
            if not has_evict:
                rows.append({"file": rel, "global": name, "line": n.lineno,
                             "kind": "无淘汰逻辑的模块级容器"})
        # 定时器未取消
        for m in re.finditer(r"(call_later|call_at|sched\.\w+|setInterval)\s*\(", src):
            pass
        if re.search(r"loop\.call_later|loop\.call_at", src) and not re.search(r"\.cancel\(\)", src):
            rows.append({"file": rel, "global": "-", "line": 0,
                         "kind": "定时器创建但无 cancel"})
    return rows

# ── R10-3 历史审计修复验证 ────────────────────────────────────
AUDIT_MARK = re.compile(
    r"(第[一二三四五六七]轮审计|审计\s*(P0|P1|P2|P3)-\d+|CRITICAL-\d+"
    r"|稳定性审计缺陷\d+|WO-MA-\d+|NEW-P0-\d+|M\d+\s*[:：])")

def probe_history_fix():
    """抽取代码中的历史审计修复标记，检查是否真有对应实现。"""
    marks = collections.Counter()
    samples = collections.defaultdict(list)
    for pth in iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            lines = open(pth, encoding="utf-8").read().splitlines()
        except Exception:
            continue
        for i, ln in enumerate(lines, 1):
            m = AUDIT_MARK.search(ln)
            if m:
                k = m.group(0).strip()
                marks[k] += 1
                if len(samples[k]) < 2:
                    samples[k].append(f"{rel}:{i}")
    return {"counts": dict(marks.most_common(40)),
            "samples": {k: v for k, v in samples.items()}}

if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    r1 = probe_task_lifecycle()
    r2 = probe_resource_growth()
    r3 = probe_history_fix()
    print("R10-1 后台任务创建点（create / cancel / shutdown）:")
    tc = sum(x["create"] for x in r1); cc = sum(x["cancel"] for x in r1)
    sc = sum(x["shutdown"] for x in r1)
    print(f"    create {tc} | cancel {cc} | shutdown {sc}")
    for x in sorted(r1, key=lambda z: -z["create"])[:8]:
        print(f"    {x['file']}: create={x['create']} cancel={x['cancel']} shutdown={x['shutdown']}")
    print(f"\nR10-2 长跑资源增长点: {len(r2)}")
    for x in r2[:14]:
        print(f"    {x['file']}:{x['line']} {x['global']}  [{x['kind']}]")
    print(f"\nR10-3 历史审计修复标记: {sum(r3['counts'].values())} 处，类型 {len(r3['counts'])}")
    for k, v in list(r3["counts"].items())[:18]:
        print(f"    {k}: {v}   e.g. {r3['samples'][k][0]}")
    json.dump({"task": r1, "resource": r2, "history": r3},
              open(os.path.join(OUT, "life_r10.json"), "w"), ensure_ascii=False, indent=1)
