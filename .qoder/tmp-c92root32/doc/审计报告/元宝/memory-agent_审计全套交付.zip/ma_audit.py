#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""memory-agent 图谱导引审计工作流（可复现 / 可增量重跑）

用法:
    python3 ma_audit.py all                 # 跑全流水线
    python3 ma_audit.py graph               # 只建图谱
    python3 ma_audit.py probes              # 只跑图谱导引的定点探针
    python3 ma_audit.py verify <结论编号>    # 对某条结论做假阳性证伪

设计原则（来自 trailofbits/fp-check）：
    每条告警必须逐条读上下文证伪后才写入结论；未证伪的一律不报。
"""
from __future__ import annotations

import ast
import collections
import json
import os
import re
import subprocess
import sys

REPO = os.environ.get("MA_REPO", "/data/workspace/ma")
SRC = os.path.join(REPO, "src", "memory_agent")
OUT = os.environ.get("MA_OUT", "/data/workspace/audit_out")
os.makedirs(OUT, exist_ok=True)

# PyCG 0.0.8 安装目录名为大写 PyCG，需 PYTHONPATH 指向其父目录
PYCG_PATH = os.environ.get("MA_PYCG_PATH", "/data/workspace")


def sh(cmd, env=None, timeout=900):
    e = dict(os.environ)
    if env:
        e.update(env)
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout, env=e)
    return r.returncode, (r.stdout or "") + (r.stderr or "")


# ──────────────────────────────────────────────────────────────
# 阶段 1 · 建图：调用图 + 模块依赖图
# ──────────────────────────────────────────────────────────────
def stage_graph():
    print("[1/6] 建图 · PyCG 调用图")
    files = []
    for dp, _, fs in os.walk(SRC):
        for f in fs:
            if f.endswith(".py"):
                files.append(os.path.join(dp, f))
    cg = os.path.join(OUT, "callgraph.json")
    cmd = (f"cd {REPO} && PYTHONPATH={PYCG_PATH} python3 -m pycg "
           f"--package src/memory_agent {' '.join(files)} -o {cg}")
    rc, out = sh(cmd)
    print(f"   rc={rc} {'OK' if rc == 0 else out[:400]}")
    if os.path.exists(cg):
        d = json.load(open(cg))
        allnodes = set(d) | {x for v in d.values() for x in v}
        print(f"   节点 {len(allnodes)} / 边 {sum(len(set(v)) for v in d.values())}")
    return cg


def stage_module_graph(cg):
    print("[1b/6] 建图 · 模块级依赖图可视化")
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import networkx as nx
    except ImportError:
        print("   跳过（缺 matplotlib/networkx）")
        return
    d = json.load(open(cg))
    STD = {"os", "sys", "json", "time", "re", "logging", "datetime", "asyncio", "typing",
           "collections", "uuid", "math", "sqlite3", "threading", "hashlib", "contextlib",
           "inspect", "importlib", "traceback", "pathlib", "secrets", "enum", "random",
           "statistics", "calendar", "urllib", "tempfile", "types", "dataclasses", "shutil",
           "glob", "copy", "itertools", "functools", "abc", "ast", "base64", "subprocess"}
    top = collections.defaultdict(collections.Counter)
    for src, dsts in d.items():
        s0 = src.split(".")[0]
        if s0.startswith("<"):
            continue
        for t in set(dsts):
            t0 = t.split(".")[0]
            if t0 == s0 or t0.startswith("<") or t0 in STD:
                continue
            top[s0][t0] += 1
    G = nx.DiGraph()
    for s, c in top.items():
        for t, w in c.items():
            if w >= 3:
                G.add_edge(s, t, weight=w)
    deg = dict(G.degree())
    plt.figure(figsize=(24, 17))
    pos = nx.spring_layout(G, k=1.25, iterations=90, seed=11)
    nx.draw_networkx_edges(G, pos, alpha=0.22, arrows=True, arrowsize=7,
                           connectionstyle="arc3,rad=0.08")
    nx.draw_networkx_nodes(G, pos, node_size=[120 + deg[n] * 26 for n in G],
                           node_color="#4C78A8", alpha=0.9)
    nx.draw_networkx_labels(G, pos, font_size=6.5)
    nx.draw_networkx_edge_labels(
        G, pos, {(u, v): G[u][v]["weight"] for u, v in G.edges() if G[u][v]["weight"] >= 25},
        font_size=5.5)
    plt.title("memory-agent 调用图谱 · 模块级", fontsize=13)
    plt.axis("off")
    plt.tight_layout()
    png = os.path.join(OUT, "module_graph.png")
    plt.savefig(png, dpi=115)
    print(f"   -> {png}  枢纽: "
          + ", ".join(f"{n}({v})" for n, v in sorted(deg.items(), key=lambda kv: -kv[1])[:6]))


# ──────────────────────────────────────────────────────────────
# 阶段 2 · 测试基线
# ──────────────────────────────────────────────────────────────
def stage_test():
    print("[2/6] 测试基线 · pytest（需 JWT_SECRET，否则 Config 拒绝启动）")
    cmd = (f"cd {REPO} && JWT_SECRET=audit_only python3 -m pytest tests -q --no-header "
           f"-p no:cacheprovider")
    rc, out = sh(cmd, timeout=1200)
    tail = [l for l in out.strip().splitlines() if l.strip()][-1:]
    print(f"   rc={rc}  {tail}")
    open(os.path.join(OUT, "pytest.log"), "w").write(out)
    return rc


# ──────────────────────────────────────────────────────────────
# 阶段 3 · 静态扫描套件
# ──────────────────────────────────────────────────────────────
def stage_static():
    print("[3/6] 静态扫描 · ruff / bandit / pyflakes / vulture")
    res = {}
    rc, out = sh(f"cd {REPO} && ruff check src --select E,F,B,S,ASYNC,C4,RET,SIM,ARG,TRY,W,PERF "
                 f"--ignore RUF001,RUF002,RUF003,RUF100,E501,W293,E402 --output-format concise")
    res["ruff"] = len(out.strip().splitlines())
    rc, out = sh(f"cd {REPO} && python3 -m bandit -r src -ll -f json -o {OUT}/bandit.json")
    try:
        res["bandit"] = len(json.load(open(f"{OUT}/bandit.json"))["results"])
    except Exception:
        res["bandit"] = "n/a"
    rc, out = sh(f"cd {REPO} && python3 -m pyflakes src")
    res["pyflakes"] = len([l for l in out.splitlines() if l.strip()])
    rc, out = sh(f"cd {REPO} && python3 -m vulture src --min-confidence 80")
    res["vulture"] = len([l for l in out.splitlines() if l.strip()])
    print(f"   {res}")
    return res


# ──────────────────────────────────────────────────────────────
# 阶段 4 · 属性测试（Hypothesis）
# ──────────────────────────────────────────────────────────────
def stage_property():
    print("[4/6] 属性测试 · Hypothesis 全输入域反例搜索")
    sys.path.insert(0, os.path.join(REPO, "src"))
    try:
        from hypothesis import given, settings, strategies as st, HealthCheck
        import memory_agent.store as store
        from memory_agent.insights import utils as u
    except ImportError as e:
        print(f"   跳过（{e}）")
        return {}
    findings = collections.defaultdict(list)
    ALLOW = (TypeError, ValueError, KeyError, IndexError, ZeroDivisionError, AttributeError)

    def probe(name, fn, strat):
        def run(a):
            try:
                fn(a)
            except ALLOW:
                return
            except Exception as exc:
                findings[f"{name}:{type(exc).__name__}"].append(repr(a)[:60])
        settings(max_examples=300, deadline=None,
                 suppress_health_check=list(HealthCheck))(given(strat)(run))()

    anyv = st.one_of(st.text(), st.none(), st.integers(), st.floats(allow_nan=False),
                     st.booleans(), st.lists(st.text(), max_size=2))
    dic = st.dictionaries(st.text(), anyv, max_size=4)
    ld = st.lists(dic, max_size=4)
    for nm, fn in [("num_stale", u.num_stale), ("diagnose_empty_result", u.diagnose_empty_result),
                   ("compare_climate", u.compare_climate), ("synthesize_persona", u.synthesize_persona),
                   ("parse_attrs", u.parse_attrs), ("fmt_duration", u.fmt_duration),
                   ("match_pattern", u.match_pattern), ("clean_device_query", u.clean_device_query),
                   ("capability_of", u.capability_of), ("is_device_on", u.is_device_on),
                   ("state_is_off", u.state_is_off), ("state_is_on", u.state_is_on)]:
        probe(nm, fn, dic if nm in ("num_stale", "diagnose_empty_result", "compare_climate",
                                    "synthesize_persona") else anyv)
    for nm, fn in [("summarize_events", u.summarize_events),
                   ("aggregate_climate_sessions", u.aggregate_climate_sessions),
                   ("find_last_boot_time", u.find_last_boot_time),
                   ("identify_noise_entities", u.identify_noise_entities)]:
        probe(nm, fn, ld)
    probe("store.parse_ts", store.parse_ts,
          st.one_of(st.text(), st.datetimes(), st.integers(), st.floats(allow_nan=False)))
    probe("store._as_float", store._as_float, anyv)
    print(f"   崩溃类型数: {len(findings)}  {dict((k, len(v)) for k, v in findings.items()) or '无'}")
    return dict((k, len(v)) for k, v in findings.items())


# ──────────────────────────────────────────────────────────────
# 阶段 5 · 图谱导引的定点探针（本项目专属）
# ──────────────────────────────────────────────────────────────
def _iter_py():
    for dp, _, fs in os.walk(SRC):
        for f in fs:
            if f.endswith(".py"):
                yield os.path.join(dp, f)


def probe_timezone():
    """P1-3：绕过统一时钟 now_local() 的裸 datetime.now()/utcnow()。
    项目在 causal_scanner/mcp_server/backup 三处写明该模式会致窗口错位，
    故扫描全部绕过点并逐个分类（落盘=BUG / TTL比较=安全）。"""
    hits = []
    for p in _iter_py():
        rel = os.path.relpath(p, SRC)
        for i, line in enumerate(open(p, encoding="utf-8", errors="replace"), 1):
            if "datetime.now()" in line or "datetime.utcnow()" in line:
                hits.append((rel, i, line.strip()[:95]))
    return hits


def probe_silent_degrade():
    """P1-2：except 内返回空值且无日志的静默降级。"""
    silent = []
    for p in _iter_py():
        rel = os.path.relpath(p, SRC)
        try:
            t = ast.parse(open(p, encoding="utf-8").read())
        except Exception:
            continue
        for n in ast.walk(t):
            if not isinstance(n, ast.ExceptHandler):
                continue
            empties = []
            for s in ast.walk(n):
                if isinstance(s, ast.Return):
                    u = ast.unparse(s.value) if s.value is not None else "None"
                    if u in ("None", "[]", "{}", "0", '""', "()", "set()"):
                        empties.append(u)
            if not empties:
                continue
            body = " ".join(ast.unparse(s) for s in n.body).lower()
            if any(k in body for k in ("log", "print", "warn")):
                continue
            silent.append((rel, n.lineno, empties[0]))
    return silent


def probe_zip_risk():
    """P2-1：zip() 无 strict=。两序列独立生成时长度不等会静默错位。"""
    out = []
    for p in _iter_py():
        rel = os.path.relpath(p, SRC)
        for i, line in enumerate(open(p, encoding="utf-8", errors="replace"), 1):
            if "zip(" in line and "strict=" not in line:
                out.append((rel, i, line.strip()[:95]))
    return out


def probe_async_block():
    """P2-2：async 函数体内未卸载的阻塞 I/O。
    注意：包在嵌套同步函数且由 asyncio.to_thread 调用的，属于已正确卸载，排除。"""
    BLOCK = {"execute", "executemany", "fetchall", "fetchone", "commit",
             "urlopen", "Popen", "run", "check_output", "remove", "rmtree", "copy", "move"}
    out = []
    for p in _iter_py():
        rel = os.path.relpath(p, SRC)
        try:
            t = ast.parse(open(p, encoding="utf-8").read())
        except Exception:
            continue
        for n in ast.walk(t):
            if not isinstance(n, ast.AsyncFunctionDef):
                continue
            nested = {s.name: s for s in ast.walk(n) if isinstance(s, ast.FunctionDef)}
            for c in ast.walk(n):
                if not isinstance(c, ast.Call):
                    continue
                fn = c.func
                nm = fn.attr if isinstance(fn, ast.Attribute) else getattr(fn, "id", "")
                if nm not in BLOCK and nm != "open":
                    continue
                # 归属到最内层函数；若属于嵌套同步函数则由调用点决定是否卸载
                owner = None
                for cand in [n] + list(nested.values()):
                    if c in ast.walk(cand):
                        owner = cand
                if owner is not n:
                    continue
                txt = ast.unparse(c)[:90]
                if "asyncio.sleep" in txt:
                    continue
                out.append((rel, n.name, c.lineno, nm, txt))
    return out


def probe_cycles():
    """模块循环依赖（区分模块级导入 vs 函数内延迟导入）。"""
    mods = {}
    for p in _iter_py():
        rel = os.path.relpath(p, SRC)[:-3].replace(os.sep, ".")
        if rel.endswith(".__init__"):
            rel = rel[:-9]
        try:
            t = ast.parse(open(p, encoding="utf-8").read())
        except Exception:
            continue
        inner = set()
        for n in ast.walk(t):
            if isinstance(n, ast.ImportFrom) and n.level and n.level > 0:
                parts = rel.split(".")
                pkg = parts[:-1] if len(parts) > 1 else []
                up = n.level - 1
                base = pkg[:len(pkg) - up] if up <= len(pkg) else []
                tgt = ".".join(base + ([n.module] if n.module else []))
                if tgt:
                    inner.add(tgt)
        inner.discard(rel)
        mods[rel] = inner
    cycles = set()

    def dfs(node, path, depth=0):
        if depth > 12:
            return
        if node in path:
            i = path.index(node)
            if len(path[i:]) > 1:
                cycles.add(tuple(sorted(path[i:])))
            return
        for nx_ in sorted(mods.get(node, ())):
            if nx_ in mods:
                dfs(nx_, path + [node], depth + 1)
    for n in sorted(mods):
        dfs(n, [])
    return cycles, mods


# ──────────────────────────────────────────────────────────────
# 阶段 5b · 第二轮探针（覆盖率导引 + 精确化）
# ──────────────────────────────────────────────────────────────
REGISTER_DECORATORS = ("tool", "resource", "prompt", "route", "get", "post", "put",
                       "delete", "patch", "app.", "mcp.", "staticmethod", "property",
                       "abstractmethod", "override", "classmethod")


def probe_coverage_gap():
    """R2-0：覆盖率定位未测区域。测试全绿 ≠ 覆盖足够——0% 覆盖的核心模块是 bug 温床。"""
    cmd = (f"cd {REPO} && JWT_SECRET=audit_only python3 -m pytest tests -q --no-header "
           f"-p no:cacheprovider --cov=memory_agent --cov-report=json:{OUT}/cov.json")
    rc, out = sh(cmd, timeout=1500)
    try:
        d = json.load(open(f"{OUT}/cov.json"))
    except Exception:
        print("   覆盖率不可用（pytest-cov 未装或运行失败）")
        return {}
    tot = d["totals"]["percent_covered"]
    zero = []
    for f, v in d["files"].items():
        s = v["summary"]
        if s["percent_covered"] == 0:
            zero.append((s["num_statements"], f.replace("src/memory_agent/", "")))
    zero.sort(reverse=True)
    print(f"   总覆盖率 {tot:.1f}%  |  0% 覆盖模块 {len(zero)} 个")
    print(f"   最大的未测模块: " + ", ".join(f"{n}({s}行)" for s, n in zero[:6]))
    return {"total": tot, "zero_coverage": zero}


def probe_orphan_precise():
    """R2-1：孤儿函数精确检测。
    第一轮 PyCG 报 1346 个孤儿，但它看不见装饰器注册（@mcp.tool/路由），大量误判。
    本探针用 AST 排除注册型装饰器，并用「名字是否在其他位置出现」做二次过滤。"""
    defs = {}
    for p in _iter_py():
        rel = os.path.relpath(p, SRC)[:-3].replace(os.sep, ".")
        if rel.endswith(".__init__"):
            rel = rel[:-9]
        try:
            t = ast.parse(open(p, encoding="utf-8").read())
        except Exception:
            continue
        def walk(node, prefix, cls=None):
            for n in node.body:
                if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    qn = f"{prefix}.{cls}.{n.name}" if cls else f"{prefix}.{n.name}"
                    defs[qn] = (rel, n.lineno, [ast.unparse(x) for x in n.decorator_list])
                    walk(n, prefix, cls)
                elif isinstance(n, ast.ClassDef):
                    walk(n, prefix, n.name)
        walk(t, rel)
    names = collections.Counter()
    for base in (SRC, os.path.join(REPO, "tests"), os.path.join(REPO, "scripts")):
        if not os.path.isdir(base):
            continue
        for dp, _, fs in os.walk(base):
            for f in fs:
                if not f.endswith(".py"):
                    continue
                try:
                    t = ast.parse(open(os.path.join(dp, f), encoding="utf-8").read())
                except Exception:
                    continue
                for n in ast.walk(t):
                    if isinstance(n, ast.Name):
                        names[n.id] += 1
                    elif isinstance(n, ast.Attribute):
                        names[n.attr] += 1
    out = []
    for qn, (f, ln, decs) in defs.items():
        short = qn.split(".")[-1]
        if short.startswith("__") and short.endswith("__"):
            continue
        if any(any(k in d for k in REGISTER_DECORATORS) for d in decs):
            continue
        if names.get(short, 0) >= 1:
            continue
        out.append({"qualname": qn, "file": f, "line": ln})
    return out


def probe_timezone_classify():
    """R2-2：时区家族全量分类。
    判据不是「用了 datetime.now()」，而是「该时间是否与库内家庭墙钟数据做比较/过滤」。
    DANGER=参与查询窗口比较；SAFE=仅 TTL/差值；REVIEW=仅落盘需人工判。
    ⚠ 必须用 AST 语句行号排除注释与 docstring——项目内大量警告注释含同样的代码片段。"""
    rows = []
    for p in _iter_py():
        rel = os.path.relpath(p, SRC)
        src = open(p, encoding="utf-8", errors="replace").read()
        lines = src.splitlines()
        try:
            t = ast.parse(src)
        except Exception:
            continue
        code_lines = set()
        for n in ast.walk(t):
            if isinstance(n, ast.stmt):
                for i in range(n.lineno, (n.end_lineno or n.lineno) + 1):
                    code_lines.add(i)
        for i, line in enumerate(lines, 1):
            if "datetime.now()" not in line and "datetime.utcnow()" not in line:
                continue
            if i not in code_lines or line.strip().startswith("#"):
                continue
            owner = None
            for n in ast.walk(t):
                if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) \
                        and n.lineno <= i <= (n.end_lineno or n.lineno):
                    owner = n
            seg = ast.unparse(owner) if owner else line
            cmp_kw = ("select", "where", "day", "server_ts", "get_history", "timedelta(days",
                      "window", "since", "cutoff", "day_from")
            ttl_kw = ("ttl", "expire", "elapsed", "timeout", "interval")
            low = seg.lower()
            v = "DANGER" if any(k in low for k in cmp_kw) else (
                "SAFE" if any(k in low for k in ttl_kw) else "REVIEW")
            rows.append({"file": rel, "line": i, "verdict": v,
                         "func": owner.name if owner else "", "code": line.strip()[:95]})
    return rows


def probe_dual_track():
    """R2-3：双轨实现口径比对（insights 新包 vs insights_legacy 同名方法）。"""
    def methods_of(prefix):
        out = {}
        for p in _iter_py():
            rel = os.path.relpath(p, SRC)[:-3].replace(os.sep, ".")
            if not rel.startswith(prefix):
                continue
            try:
                t = ast.parse(open(p, encoding="utf-8").read())
            except Exception:
                continue
            for n in ast.walk(t):
                if isinstance(n, ast.ClassDef):
                    for s in n.body:
                        if isinstance(s, (ast.FunctionDef, ast.AsyncFunctionDef)):
                            out.setdefault(s.name, []).append(f"{rel}.{n.name}")
        return out
    new, legacy = methods_of("insights."), methods_of("insights_legacy")
    return {"shared": sorted(set(new) & set(legacy)),
            "shared_count": len(set(new) & set(legacy)),
            "new_only": sorted(set(new) - set(legacy))[:40],
            "legacy_only": sorted(set(legacy) - set(new))[:40]}


def probe_lock_discipline():
    """R2-4：connect() 后不持锁直接 execute（可能读到未提交事务的半截数据）。"""
    hits = []
    for p in _iter_py():
        rel = os.path.relpath(p, SRC)
        try:
            t = ast.parse(open(p, encoding="utf-8").read())
        except Exception:
            continue
        for n in ast.walk(t):
            if not isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            seg = ast.unparse(n)
            if ".connect()" in seg and ".execute(" in seg:
                if not any(k in seg for k in ("_db()", "_lock", "lock", "transaction()")):
                    hits.append({"file": rel, "func": n.name, "line": n.lineno})
    return hits


def probe_idempotency():
    """R2-5：reserve 后无 finalize/release 的路径 → 占位只增不减。"""
    hits = []
    for p in _iter_py():
        rel = os.path.relpath(p, SRC)
        try:
            t = ast.parse(open(p, encoding="utf-8").read())
        except Exception:
            continue
        for n in ast.walk(t):
            if not isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            seg = ast.unparse(n)
            if "reserve_idempotency" in seg and not any(
                    k in seg for k in ("finalize_idempotency", "release_idempotency")):
                hits.append({"file": rel, "func": n.name, "line": n.lineno})
    return hits


def stage_property_untested():
    """R2-6：对覆盖率探针识别出的 0% 覆盖模块，自动抽取单参函数做属性测试。
    这是「覆盖率导引」的闭环——未测区域自动成为 fuzz 目标。"""
    sys.path.insert(0, os.path.join(REPO, "src"))
    try:
        import inspect
        from hypothesis import given, settings, strategies as st, HealthCheck
    except ImportError:
        print("   R2-6 跳过（缺 hypothesis）")
        return {}
    try:
        d = json.load(open(f"{OUT}/cov.json"))
    except Exception:
        return {}
    targets = []
    for f, v in d["files"].items():
        if v["summary"]["percent_covered"] == 0:
            rel = f.replace("src/memory_agent/", "").replace("/", ".")[:-3]
            if rel.startswith(("scripts.",)):
                continue
            targets.append(rel)
    findings = collections.defaultdict(list)
    ALLOW = (TypeError, ValueError, KeyError, IndexError, ZeroDivisionError, AttributeError)
    anyv = st.one_of(st.text(), st.none(), st.integers(), st.floats(allow_nan=False),
                     st.booleans())
    dic = st.dictionaries(st.text(), anyv, max_size=4)
    ld = st.lists(dic, max_size=5)
    lf = st.lists(st.floats(allow_nan=False, allow_infinity=False), max_size=8)
    n_fn = 0
    for m in targets:
        try:
            mod = __import__(f"memory_agent.{m}", fromlist=["*"])
        except Exception:
            continue
        for n, fn in list(vars(mod).items()):
            if not callable(fn) or n.startswith("_"):
                continue
            if getattr(fn, "__module__", "") != f"memory_agent.{m}":
                continue
            try:
                sig = inspect.signature(fn)
                if len([p for p in sig.parameters.values()
                        if p.default is inspect._empty]) != 1:
                    continue
            except Exception:
                continue
            _fn, _n = fn, f"{m}.{n}"

            def run(a):
                try:
                    _fn(a)
                except ALLOW:
                    return
                except Exception as e:
                    findings[f"{_n}:{type(e).__name__}"].append(repr(a)[:70])
            settings(max_examples=200, deadline=None,
                     suppress_health_check=list(HealthCheck))(
                given(st.one_of(dic, ld, anyv, lf))(run))()
            n_fn += 1
    print(f"   R2-6 未测模块属性测试: {n_fn} 个函数 / 崩溃类型 {len(findings)}")
    for k, v in list(findings.items())[:10]:
        print(f"        {k} x{len(v)}  e.g. {v[0][:60]}")
    return dict((k, len(v)) for k, v in findings.items())


# ──────────────────────────────────────────────────────────────
# 阶段 5c · 第三轮：变体扩散 + 定向变异测试
# ──────────────────────────────────────────────────────────────
def probe_first_wins():
    """R3-1 变体扩散：扫描「if key not in dict: dict[key]=...」取遍历首个的模式。
    该模式在「上游 DESC 排序 + 语义为时间最早」的组合下即为 P1-4/P1-6 族缺陷。
    ⚠ 命中≠缺陷：必须 triage 是否 (a) 上游排序 (b) 时间语义 (c) 有无显式 sorted。"""
    hits = []
    for p in _iter_py():
        rel = os.path.relpath(p, SRC)
        try:
            t = ast.parse(open(p, encoding="utf-8").read())
        except Exception:
            continue
        for n in ast.walk(t):
            if not isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for c in ast.walk(n):
                if not isinstance(c, ast.If):
                    continue
                test = ast.unparse(c.test)
                if " not in " not in test:
                    continue
                for st in c.body:
                    if isinstance(st, ast.Assign) and isinstance(st.value, ast.Name):
                        if ast.unparse(st.targets[0]).startswith(test.split(" not in ")[1].strip()):
                            hits.append({"file": rel, "func": n.name, "line": c.lineno,
                                         "code": test[:70]})
    return hits


def probe_order_dependency():
    """R3-2 宽口径顺序依赖：函数内无 sorted 却用 [0] / [-1] / 取遍历首个。"""
    hits = []
    for p in _iter_py():
        rel = os.path.relpath(p, SRC)
        try:
            t = ast.parse(open(p, encoding="utf-8").read())
        except Exception:
            continue
        for n in ast.walk(t):
            if not isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            seg = ast.unparse(n)
            if "sorted(" in seg or "sort(" in seg:
                continue
            pat = []
            for c in ast.walk(n):
                if isinstance(c, ast.Subscript) and isinstance(c.slice, ast.Constant) \
                        and c.slice.value in (0, -1):
                    pat.append("idx%d" % c.slice.value)
            if pat:
                hits.append({"file": rel, "func": n.name, "line": n.lineno,
                             "patterns": sorted(set(pat))})
    return hits


# ──────────────────────────────────────────────────────────────
# 阶段 5d · 第四轮：类型系统 + 复杂度热点
# ──────────────────────────────────────────────────────────────
# ──────────────────────────────────────────────────────────────
# 阶段 5e · 第五轮：路由接漏 + 孤儿函数精确 triage
# ──────────────────────────────────────────────────────────────
# ──────────────────────────────────────────────────────────────
# 阶段 5f · 第六轮：双轨实现口径比对
# ──────────────────────────────────────────────────────────────
# ──────────────────────────────────────────────────────────────
# 阶段 5g · 第七轮：并发与竞态（V3）
# ──────────────────────────────────────────────────────────────
# ⚠ 关键判定规则（第七轮最重要的收获，写进代码注释以免遗忘）：
#   asyncio 是单线程。async 函数内若「读」与「写」之间没有 await，
#   事件循环不会切走 —— 即使无锁也不可能竞态。
#   真风险只有两种：① async 内 读→await→写  ② 同步函数在 to_thread 线程池
#   只按「有没有锁」判断会造出大量假 bug（第七轮 24 处命中 → 真风险仅 6 处）。
# ──────────────────────────────────────────────────────────────
# 阶段 5h · 第八轮：外部输入边界（V3 剩余部分）
# ──────────────────────────────────────────────────────────────
SINK_PAT = [
    (r"\.execute\s*\(\s*f['\"]", "SQL f-string 拼接"),
    (r"\.execute\s*\(\s*\w+\s*\+", "SQL 字符串拼接"),
    (r"\.executescript\s*\(", "executescript"),
    (r"\beval\s*\(", "eval"), (r"\bexec\s*\(", "exec"),
    (r"subprocess\.(run|call|Popen|check_output)", "subprocess"),
    (r"os\.system\s*\(", "os.system"),
]

def probe_path_traversal():
    """R8-3 外部字符串 → 文件路径拼接，缺少 realpath/startswith 约束。
    ⚠ 关键判据：路径必须以 SKILL.md 结尾才可读（get_skill 拼接了固定文件名），
    故可利用性受限；但『写路径有校验、读路径没有』的不对称本身就是缺陷信号。"""
    rows = []
    for pth in _iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            t = ast.parse(open(pth, encoding="utf-8").read())
        except Exception:
            continue
        for fn in ast.walk(t):
            if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            seg = ast.unparse(fn)
            if not re.search(r"open\s*\(|os\.path\.join\s*\(|os\.makedirs\s*\(", seg):
                continue
            if not re.search(r"\.get\(\s*['\"]|\bname\b", seg):
                continue
            if re.search(r"basename|realpath|WHITE|ALLOWED|startswith\(\s*['\"]"
                         r"|re\.match\s*\(\s*r?['\"]\^", seg):
                continue
            rows.append({"file": rel, "func": fn.name, "line": fn.lineno})
    return rows


def probe_numeric_bound():
    """R8-2 数值参数（limit/days/top_n...）从入口取值后无 clamp。"""
    params = ("limit", "days", "top_n", "offset", "max_rows", "hours", "minutes",
              "count", "page", "size", "window", "rounds", "temperature")
    rows = []
    for pth in _iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            t = ast.parse(open(pth, encoding="utf-8").read())
        except Exception:
            continue
        for fn in ast.walk(t):
            if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            seg = ast.unparse(fn)
            for np_ in params:
                m = re.search(rf"\b{np_}\s*=\s*[^=]*\.get\(\s*['\"]{np_}['\"]", seg)
                if not m:
                    continue
                if re.search(rf"\b{np_}\s*=\s*(int|float|max|min|clamp|safe_int)\s*\(", seg):
                    continue
                rows.append({"file": rel, "func": fn.name, "line": fn.lineno,
                             "param": np_, "snippet": m.group(0)[:80]})
    return rows


# ──────────────────────────────────────────────────────────────
# 阶段 5i · 第九轮：未测区域收口
# ──────────────────────────────────────────────────────────────
# ──────────────────────────────────────────────────────────────
# 阶段 5j · 第十轮：生命周期 / 资源 / 历史修复回归（V4）
# ──────────────────────────────────────────────────────────────
# ──────────────────────────────────────────────────────────────
# 阶段 5k · 第十一轮：孤儿功能族 triage + 工具契约接漏
# ──────────────────────────────────────────────────────────────
# ──────────────────────────────────────────────────────────────
# 阶段 5l · 第十二轮：高复杂度函数（自算 CC，radon 沙箱不可用）
# ──────────────────────────────────────────────────────────────
def probe_cc_ast(threshold=15):
    """R12-1 自算圈复杂度：CC = 1 + 分支节点(if/for/while/except/with/assert/三元/BoolOp/推导式if)。
    radon 在沙箱不可用（No module named radon），用 AST 等价实现。
    ⚠ 高复杂度本身不是缺陷。必须与覆盖率交叉：高CC + 高覆盖 = 已被测试兜住，
    高CC + 低覆盖 = 真风险区。只按 CC 排序会浪费大量精力在已被测过的代码上。"""
    BR = (ast.If, ast.For, ast.AsyncFor, ast.While, ast.ExceptHandler,
          ast.With, ast.AsyncWith, ast.Assert, ast.IfExp)
    rows = []
    for pth in _iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            t = ast.parse(open(pth, encoding="utf-8").read())
        except Exception:
            continue
        for n in ast.walk(t):
            if not isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            c = 1
            for x in ast.walk(n):
                if isinstance(x, BR):
                    c += 1
                elif isinstance(x, ast.BoolOp):
                    c += len(x.values) - 1
                elif isinstance(x, (ast.ListComp, ast.SetComp, ast.DictComp,
                                    ast.GeneratorExp)):
                    c += sum(1 for g in x.generators for _ in g.ifs)
            if c >= threshold:
                rows.append({"cc": c, "file": rel, "line": n.lineno, "name": n.name,
                             "grade": "F" if c >= 41 else ("E" if c >= 31
                                                            else ("D" if c >= 21 else "C"))})
    rows.sort(key=lambda r: -r["cc"])
    return rows


def probe_complexity_cross():
    """R12-2 复杂度 × 覆盖率交叉。返回 risk（低覆盖高复杂）与 ok（高覆盖高复杂）。"""
    try:
        cov = json.load(open(os.path.join(OUT, "cov.json")))["files"]
    except Exception:
        cov = {}
    fcov = {}
    for k, v in cov.items():
        s = v.get("summary", {})
        fcov[k.replace("src/memory_agent/", "")] = (
            s.get("percent_covered", 100.0) if s.get("num_statements", 0) else 100.0)
    rows = probe_cc_ast()
    for r in rows:
        r["file_cov"] = round(fcov.get(r["file"], 0.0), 1)
    fe = [r for r in rows if r["grade"] in ("E", "F")]
    risk = [r for r in fe if r["file_cov"] < 60]
    ok = [r for r in fe if r["file_cov"] >= 60]
    return {"risk": sorted(risk, key=lambda r: (-r["cc"], r["file_cov"])),
            "ok": sorted(ok, key=lambda r: -r["cc"])}


def stage_probes_r12():
    print("[5l/6] 第十二轮探针：高复杂度函数（CC 自算 + 覆盖率交叉）")
    r = probe_complexity_cross()
    print(f"   R12-1 E+F 级函数: {len(r['risk']) + len(r['ok'])}")
    print(f"   R12-2 高CC×低覆盖（真风险）: {len(r['risk'])}  | 高CC但覆盖良好: {len(r['ok'])}")
    for x in r["risk"][:10]:
        print(f"        CC={x['cc']:3d} 覆盖{x['file_cov']:5.1f}%  "
              f"{x['file']}:{x['line']} {x['name']}")
    json.dump(r, open(os.path.join(OUT, "probes_r12.json"), "w"),
              ensure_ascii=False, indent=1)
    return r


def probe_orphan_family():
    """R11-1 孤儿「同族接漏」：同类其他方法多被调用，唯独它零引用。
    ⚠ 该信号命中率高但需人工 triage——名字常见的（fuse/shift/enrich）
    会因同名方法被调用而误判。价值在于「按族聚类」，而非逐个计数。"""
    try:
        orph = json.load(open(os.path.join(OUT, "probes_r2.json")))["orphan_precise"]
    except Exception:
        return []
    called = collections.Counter()
    for base in (SRC, os.path.join(REPO, "tests"), os.path.join(REPO, "scripts")):
        if not os.path.isdir(base):
            continue
        for dp, _, fs in os.walk(base):
            for f in fs:
                if not f.endswith(".py"):
                    continue
                try:
                    t = ast.parse(open(os.path.join(dp, f), encoding="utf-8").read())
                except Exception:
                    continue
                for n in ast.walk(t):
                    if isinstance(n, ast.Attribute):
                        called[n.attr] += 1
                    elif isinstance(n, ast.Name):
                        called[n.id] += 1
    rows = []
    for x in orph:
        parts = x["qualname"].split(".")
        short, cls = parts[-1], (parts[-2] if len(parts) >= 2 else None)
        fp = os.path.join(SRC, x["file"].replace(".", "/") + ".py")
        if not os.path.exists(fp) or called.get(short, 0):
            continue
        try:
            t = ast.parse(open(fp, encoding="utf-8").read())
        except Exception:
            continue
        sibs = []
        for c in ast.walk(t):
            if isinstance(c, ast.ClassDef) and c.name == cls:
                sibs = [s.name for s in c.body
                        if isinstance(s, (ast.FunctionDef, ast.AsyncFunctionDef))
                        and s.name != short]
        if not sibs:
            sibs = [s.name for s in t.body
                    if isinstance(s, (ast.FunctionDef, ast.AsyncFunctionDef))
                    and s.name != short]
        if not sibs:
            continue
        nc = sum(1 for s in sibs if called.get(s, 0))
        rows.append({"file": x["file"], "line": x["line"], "qualname": x["qualname"],
                     "cls": cls, "sib_total": len(sibs), "sib_called": nc,
                     "ratio": round(nc / len(sibs), 2)})
    return [r for r in rows if r["ratio"] >= 0.7 and r["sib_total"] >= 3]


def probe_tool_contract():
    """R11-2 工具契约接漏：tool_schema 声明 (service, method)，但服务类无该 method。
    ⚠ 必须先按 expose 过滤！tool_schema.dispatch 只处理 expose 含 builtin/arena 的，
    expose=['mcp'] 的手写工具在第 1822 行就被拦下，不会走到 getattr。
    不过滤会造出 3 个假阳性（save_skill/list_skills/get_skill）。"""
    tp = os.path.join(SRC, "tool_schema.py")
    if not os.path.exists(tp):
        return {"disp": 0, "missing": []}
    t = ast.parse(open(tp, encoding="utf-8").read())
    specs = []
    for n in ast.walk(t):
        if isinstance(n, ast.Call):
            fn = n.func
            nm = fn.attr if isinstance(fn, ast.Attribute) else getattr(fn, "id", "")
            if nm != "ToolSpec":
                continue
            d = {}
            for k in n.keywords:
                if isinstance(k.value, ast.Constant):
                    d[k.arg] = k.value.value
                elif isinstance(k.value, (ast.Tuple, ast.List)):
                    d[k.arg] = [e.value for e in k.value.elts
                                if isinstance(e, ast.Constant)]
            specs.append(d)
    disp = [s for s in specs if s.get("service") and s.get("method")
            and ({"builtin", "arena"} & set(s.get("expose") or []))]
    rt = ast.parse(open(os.path.join(SRC, "runtime.py"), encoding="utf-8").read())
    svc_cls = {}
    for fn in ast.walk(rt):
        if isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)) and fn.name == "__init__":
            for n in ast.walk(fn):
                if isinstance(n, ast.Assign) and isinstance(n.value, ast.Call):
                    for tg in n.targets:
                        if isinstance(tg, ast.Attribute) and isinstance(tg.value, ast.Name) \
                           and tg.value.id == "self":
                            cn = n.value.func
                            svc_cls[tg.attr] = cn.attr if isinstance(cn, ast.Attribute) \
                                else getattr(cn, "id", "")
    methods = {}
    for pth in _iter_py():
        try:
            t2 = ast.parse(open(pth, encoding="utf-8").read())
        except Exception:
            continue
        for c in ast.walk(t2):
            if isinstance(c, ast.ClassDef):
                methods.setdefault(c.name, set()).update(
                    s.name for s in c.body
                    if isinstance(s, (ast.FunctionDef, ast.AsyncFunctionDef)))
    miss = []
    for s in disp:
        cls = svc_cls.get(s["service"])
        if not cls:
            continue
        ms = methods.get(cls)
        if ms is not None and s["method"] not in ms:
            miss.append({**s, "reason": f"{cls} 无方法 {s['method']}"})
    return {"disp": len(disp), "missing": miss}


def stage_probes_r11():
    print("[5k/6] 第十一轮探针：孤儿功能族 triage + 工具契约接漏")
    r1 = probe_orphan_family()
    r2 = probe_tool_contract()
    print(f"   R11-1 同族接漏候选: {len(r1)}  ← 需按功能族聚类人工 triage，非零散计数")
    print(f"   R11-2 走 dispatch 的工具 {r2['disp']} 个，契约接漏 {len(r2['missing'])}"
          f"  ← 已按 expose 过滤，未过滤会误报 3 个")
    json.dump({"family": r1, "contract": r2},
              open(os.path.join(OUT, "probes_r11.json"), "w"), ensure_ascii=False, indent=1)
    return {"family": r1, "contract": r2}


def probe_task_lifecycle():
    """R10-1 后台任务启停对称性。
    ⚠ 计数会骗人：create 25 / cancel 3 看着失衡，但若全部经 TaskRegistry 收口、
    且 shutdown 里调 cancel_all()，就是干净的。必须追到调用链，不能只看数字比。"""
    rows = []
    for pth in _iter_py():
        try:
            src = open(pth, encoding="utf-8").read()
        except Exception:
            continue
        c = len(re.findall(r"task_registry\.create\s*\(", src))
        if c:
            rows.append({"file": os.path.relpath(pth, SRC), "create": c,
                         "cancel": len(re.findall(r"\.cancel\s*\(\s*\)", src)),
                         "cancel_all": len(re.findall(r"cancel_all\s*\(", src))})
    return rows


def probe_resource_growth():
    """R10-2 长跑资源增长：『运行态』模块级容器（被函数写入）且无淘汰逻辑。
    ⚠ 初版 124 处绝大多数是永不写入的常量字典（_ON_STATES / DEFAULT_*），
    必须先过滤『是否被函数写入』，再看淘汰——顺序反了就全是噪音。"""
    g = collections.defaultdict(list)
    for pth in _iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            src = open(pth, encoding="utf-8").read()
            t = ast.parse(src)
        except Exception:
            continue
        gmut = {}
        for n in t.body:
            nm = None
            if isinstance(n, ast.Assign) and n.targets and isinstance(n.targets[0], ast.Name):
                nm = n.targets[0].id
                v = ast.unparse(n.value)
            elif isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name):
                nm = n.target.id
                v = (ast.unparse(n.value) if n.value else "") + ast.unparse(n.annotation)
            if not nm:
                continue
            if v.startswith(("{", "dict(", "[", "list(", "set(")) or \
               any(k in v for k in ("Dict", "List", "Set", "dict", "list", "set")):
                gmut[nm] = n.lineno
        writers = collections.defaultdict(list)
        for fn in ast.walk(t):
            if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            seg = ast.unparse(fn)
            for k in gmut:
                if re.search(rf"{re.escape(k)}\s*\[[^\]]*\]\s*="
                             rf"|{re.escape(k)}\.(append|add|update|setdefault)\s*\(", seg):
                    writers[k].append(fn.name)
        for k, ln in gmut.items():
            if k not in writers:
                continue
            evict = bool(re.search(rf"{re.escape(k)}\.pop\b", src)
                         or re.search(rf"{re.escape(k)}\.clear\b", src)
                         or re.search(rf"len\({re.escape(k)}\)\s*>", src)
                         or re.search(rf"del\s+{re.escape(k)}\[", src)
                         or re.search(rf"{re.escape(k)}\.popitem", src))
            if not evict:
                g[rel].append({"global": k, "line": ln, "writers": writers[k][:4]})
    return dict(g)


def probe_history_fix():
    """R10-3 历史审计修复标记抽取。标记多≠修得好，必须抽查『注释声称已修』
    与『代码真有实现』是否对应。"""
    pat = re.compile(r"(第[一二三四五六七]轮审计|审计\s*(P0|P1|P2|P3)-\d+|CRITICAL-\d+"
                     r"|稳定性审计缺陷\d+|WO-MA-\d+|NEW-P0-\d+)")
    cnt = collections.Counter()
    samp = collections.defaultdict(list)
    for pth in _iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            lines = open(pth, encoding="utf-8").read().splitlines()
        except Exception:
            continue
        for i, ln in enumerate(lines, 1):
            m = pat.search(ln)
            if m:
                k = m.group(0).strip()
                cnt[k] += 1
                if len(samp[k]) < 2:
                    samp[k].append(f"{rel}:{i}")
    return {"counts": dict(cnt.most_common(40)),
            "samples": {k: v for k, v in samp.items()}}


def stage_probes_r10():
    print("[5j/6] 第十轮探针：生命周期 / 资源 / 历史修复回归（V4）")
    r1 = probe_task_lifecycle()
    r2 = probe_resource_growth()
    r3 = probe_history_fix()
    tc = sum(x["create"] for x in r1)
    cc = sum(x["cancel_all"] for x in r1)
    print(f"   R10-1 后台任务 create {tc} 处 | 含 cancel_all {cc} 处"
          f"  ← 数字失衡不等于有缺陷，须追 shutdown 调用链")
    n2 = sum(len(v) for v in r2.values())
    print(f"   R10-2 运行态无淘汰容器: {n2}  ← 已从常量字典噪音中过滤")
    for f, v in r2.items():
        for x in v:
            print(f"        {f}:{x['line']} {x['global']}")
    print(f"   R10-3 历史审计修复标记: {sum(r3['counts'].values())} 处"
          f" / {len(r3['counts'])} 种编号  ← 须抽查是否真落地")
    json.dump({"task": r1, "resource": r2, "history": r3},
              open(os.path.join(OUT, "probes_r10.json"), "w"), ensure_ascii=False, indent=1)
    return {"task": r1, "resource": r2, "history": r3}


def probe_absolute_import():
    """R9-1 包内模块用『绝对导入』引用同包兄弟模块（level==0）。
    ⚠ 必须区分两种写法：
      · `try: from .X import / except ImportError: from X import` = 防御式，安全
      · 直接 `from X import`（无相对导入尝试、无 try）= 以包方式导入时必 ModuleNotFoundError
    llm_client.py 是前者（安全范例）；learning_* 家族是后者。"""
    sibs = {}
    for pth in _iter_py():
        sibs[os.path.basename(pth)[:-3]] = os.path.relpath(pth, SRC)
    bad, guarded = [], []
    for pth in _iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            t = ast.parse(open(pth, encoding="utf-8").read())
        except Exception:
            continue
        # 收集被 try/except ImportError 包裹的行号
        safe_lines = set()
        for n in ast.walk(t):
            if isinstance(n, ast.Try):
                for h in n.handlers:
                    if (isinstance(h.type, ast.Name) and h.type.id == "ImportError") or \
                       (isinstance(h.type, ast.Tuple) and
                        any(getattr(e, "id", "") == "ImportError" for e in h.type.elts)):
                        for sub in ast.walk(n):
                            if hasattr(sub, "lineno"):
                                safe_lines.add(sub.lineno)
        for n in ast.walk(t):
            if isinstance(n, ast.ImportFrom) and n.level == 0 and n.module:
                top = n.module.split(".")[0]
                if top in sibs and os.sep not in sibs[top] and top != os.path.basename(pth)[:-3]:
                    item = {"file": rel, "line": n.lineno, "module": n.module}
                    (guarded if n.lineno in safe_lines else bad).append(item)
    return {"broken": bad, "guarded": guarded}


def probe_dead_subsystem():
    """R9-2 死子系统：一组模块互相引用，但整个组无任何包外调用方。
    比单函数孤儿更严重——成片代码不可达，且可能连导入都跑不通。"""
    import collections as _c
    graph = _c.defaultdict(set)
    rev = _c.defaultdict(set)
    for pth in _iter_py():
        rel = os.path.relpath(pth, SRC)[:-3].replace(os.sep, ".")
        try:
            t = ast.parse(open(pth, encoding="utf-8").read())
        except Exception:
            continue
        for n in ast.walk(t):
            if isinstance(n, ast.ImportFrom) and n.module:
                tgt = n.module if n.level else n.module
                base = tgt.split(".")[0]
                graph[rel].add(base)
                rev[base].add(rel)
            elif isinstance(n, ast.Import):
                for a in n.names:
                    graph[rel].add(a.name.split(".")[0])
                    rev[a.name.split(".")[0]].add(rel)
    # 按前缀找模块组
    groups = _c.defaultdict(list)
    for m in list(graph) + list(rev):
        parts = m.split(".")
        if len(parts) > 1 and not parts[0].startswith("insights"):
            groups[parts[0]].append(m)
    out = []
    for g, members in groups.items():
        ms = set(members)
        external = set()
        for m in ms:
            for caller in rev.get(m.split(".")[-1], set()):
                if caller not in ms:
                    external.add(caller)
        if not external:
            out.append({"prefix": g, "members": sorted(ms), "external_callers": []})
    return out


def stage_probes_r9():
    print("[5i/6] 第九轮探针：未测区域收口")
    r1 = probe_absolute_import()
    r2 = probe_dead_subsystem()
    _c = collections.Counter(x["file"] for x in r1["broken"])
    print(f"   R9-1 包内绝对引用同包兄弟模块: 裸写 {len(r1['broken'])} 处"
          f"（另有 {len(r1['guarded'])} 处有 try/except ImportError 兜底，安全）")
    for f, n in _c.most_common(8):
        print(f"        {f}: {n}")
    print(f"   R9-2 无包外调用方的模块组: {len(r2)}")
    for x in r2:
        print(f"        {x['prefix']}.* → {len(x['members'])} 个模块，外部调用方 0")
    json.dump({"abs_import": r1, "dead_group": r2},
              open(os.path.join(OUT, "probes_r9.json"), "w"), ensure_ascii=False, indent=1)
    return {"abs_import": r1, "dead_group": r2}


def probe_entry_to_sink():
    """R8-1 外部入口 → 危险汇点（SQL 拼接/eval/subprocess）。
    注：本项目该路径已由参数化查询覆盖，历轮均为 0 命中；保留探针作回归哨兵。"""
    entry = [r"\.get\(\s*['\"]", r"json_body", r"query_params", r"headers\.get"]
    rows = []
    for pth in _iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            t = ast.parse(open(pth, encoding="utf-8").read())
        except Exception:
            continue
        for fn in ast.walk(t):
            if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            seg = ast.unparse(fn)
            if not any(re.search(e, seg) for e in entry):
                continue
            for sp, sname in SINK_PAT:
                if re.search(sp, seg):
                    rows.append({"file": rel, "func": fn.name, "line": fn.lineno,
                                 "sink": sname})
    return rows


def stage_probes_r8():
    print("[5h/6] 第八轮探针：外部输入边界（V3 剩余）")
    r1 = probe_entry_to_sink()
    r2 = probe_numeric_bound()
    r3 = probe_path_traversal()
    print(f"   R8-1 入口→SQL/eval/subprocess 汇点: {len(r1)}  （回归哨兵，历轮 0 命中）")
    for x in r1[:6]:
        print(f"        {x['file']}:{x['line']} {x['func']}() [{x['sink']}]")
    print(f"   R8-2 数值参数无 clamp: {len(r2)}")
    c = collections.Counter(x["param"] for x in r2)
    print(f"        按参数: {dict(c.most_common(6))}")
    print(f"   R8-3 外部字符串→文件路径（无 realpath 约束）: {len(r3)}")
    for x in r3:
        print(f"        {x['file']}:{x['line']} {x['func']}()")
    json.dump({"entry_sink": r1, "numeric": r2, "path": r3},
              open(os.path.join(OUT, "probes_r8.json"), "w"), ensure_ascii=False, indent=1)
    return {"entry_sink": r1, "numeric": r2, "path": r3}


def probe_lock_asymmetry():
    """R7-1 锁覆盖不对称。
    ⚠ 已知误报源：`with self._db()` 这类间接持锁（_db 内部 with self._lock）
    会被判为「未持锁」。第七轮 8 处命中全部因此误判。"""
    rows = []
    for pth in _iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            t = ast.parse(open(pth, encoding="utf-8").read())
        except Exception:
            continue
        for cls in ast.walk(t):
            if not isinstance(cls, ast.ClassDef):
                continue
            if not any(isinstance(n, ast.Attribute)
                       and n.attr in ("_lock", "lock", "_mutex") for n in ast.walk(cls)):
                continue
            un, lo = [], []
            for s in cls.body:
                if not isinstance(s, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    continue
                if s.name.startswith("_") and s.name != "__init__":
                    continue
                seg = ast.unparse(s)
                if not (".append(" in seg or ".pop(" in seg or ".update(" in seg
                        or ".add(" in seg or "self._" in seg):
                    continue
                (lo if "self._lock" in seg or "self._mutex" in seg else un).append(s.name)
            if un and lo:
                rows.append({"file": rel, "cls": cls.name, "line": cls.lineno,
                             "unlocked_writers": un, "locked_count": len(lo)})
    return rows


def probe_shared_mutable():
    """R7-2 模块级共享可变容器被无锁修改。
    返回两档：raw（原始命中）与 real（按 async/await 规则过滤后的真风险）。"""
    raw, real = [], []
    for pth in _iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            src = open(pth, encoding="utf-8").read()
            t = ast.parse(src)
        except Exception:
            continue
        gmut = {}
        for n in t.body:
            tgt = None
            if isinstance(n, ast.Assign) and n.targets and isinstance(n.targets[0], ast.Name):
                tgt = n.targets[0].id
                v = ast.unparse(n.value)
            elif isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name):
                tgt = n.target.id
                v = (ast.unparse(n.value) if n.value else "") + ast.unparse(n.annotation)
            else:
                continue
            if tgt and (v.startswith(("{", "dict(", "[", "list(", "set("))
                        or any(k in v for k in ("Dict", "List", "Set", "dict", "list", "set"))):
                gmut[tgt] = n.lineno
        if not gmut:
            continue
        for fn in ast.walk(t):
            if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            seg = ast.unparse(fn)
            if re.search(r"with\s+[A-Za-z_]*LOCK", seg) or self_lock(seg):
                continue
            for g, gln in gmut.items():
                if not (f"{g}[" in seg or f"{g}.append" in seg or f"{g}.pop" in seg
                        or f"{g}.add" in seg or f"{g}.update" in seg
                        or f"{g}.setdefault" in seg or f"{g}.clear" in seg):
                    continue
                item = {"file": rel, "global": g, "gline": gln,
                        "func": fn.name, "line": fn.lineno}
                raw.append(item)
                # 真风险判定
                if isinstance(fn, ast.FunctionDef):
                    real.append({**item, "reason": "同步函数（可能在线程池并发）"})
                else:
                    awaits = [n.lineno for n in ast.walk(fn) if isinstance(n, ast.Await)]
                    reads = [n.lineno for n in ast.walk(fn)
                             if isinstance(n, ast.Name) and n.id == g]
                    writes = []
                    for n in ast.walk(fn):
                        if isinstance(n, ast.Assign):
                            for tg in n.targets:
                                if isinstance(tg, ast.Subscript) and ast.unparse(tg.value) == g:
                                    writes.append(n.lineno)
                    if any(r < a < w for r in reads for a in awaits for w in writes if w > r):
                        real.append({**item, "reason": "async 内 读→await→写"})
    return {"raw": raw, "real": real}


def self_lock(seg):
    return "self._lock" in seg or "self._mutex" in seg


def probe_toctou():
    """R7-3 TOCTOU：读 → await → 写。
    ⚠ 主要噪音源：未区分「共享状态」与「请求局部/函数局部变量」
    （第七轮 10 处中 9 处因此误报，如 ASGI 的 scope、函数局部 blob/answer）。"""
    rows = []
    for pth in _iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            t = ast.parse(open(pth, encoding="utf-8").read())
        except Exception:
            continue
        for fn in ast.walk(t):
            if not isinstance(fn, ast.AsyncFunctionDef):
                continue
            await_lines = sorted({n.lineno for n in ast.walk(fn)
                                  if isinstance(n, ast.Await)})
            if not await_lines:
                continue
            reads = []
            for n in ast.walk(fn):
                if isinstance(n, ast.If):
                    for nm in [x.id for x in ast.walk(n.test) if isinstance(x, ast.Name)]:
                        reads.append((nm, n.lineno))
            writes = []
            for n in ast.walk(fn):
                if isinstance(n, (ast.Assign, ast.AugAssign)):
                    tg = n.targets[0] if isinstance(n, ast.Assign) else n.target
                    if isinstance(tg, ast.Name):
                        writes.append((tg.id, n.lineno))
                    elif isinstance(tg, ast.Subscript):
                        v = ast.unparse(tg.value)
                        if v.isidentifier():
                            writes.append((v, n.lineno))
            for rn, rl in reads:
                for wn, wl in writes:
                    if rn == wn and wl > rl and any(rl < a < wl for a in await_lines):
                        rows.append({"file": rel, "func": fn.name, "line": rl,
                                     "name": rn, "write_line": wl})
                        break
    return rows


def stage_probes_r7():
    print("[5g/6] 第七轮探针：并发与竞态（V3）")
    r1 = probe_lock_asymmetry()
    r2 = probe_shared_mutable()
    r3 = probe_toctou()
    print(f"   R7-1 锁覆盖不对称: {len(r1)}  ← 已知误报源：间接持锁(with self._db())")
    print(f"   R7-2 共享可变状态: 原始 {len(r2['raw'])} → 真风险 {len(r2['real'])}"
          f"  （过滤规则：async 且读-写间无 await 则安全）")
    for x in r2["real"]:
        print(f"        [{x['reason'][:12]}] {x['file']}:{x['line']} {x['func']}() {x['global']}")
    print(f"   R7-3 TOCTOU: {len(r3)}  ← 主要噪音：局部变量（scope/blob/answer）")
    json.dump({"lock_asym": r1, "shared_mutable": r2, "toctou": r3},
              open(os.path.join(OUT, "probes_r7.json"), "w"), ensure_ascii=False, indent=1)
    return {"lock_asym": r1, "shared_mutable": r2, "toctou": r3}


def probe_dual_track_v2():
    """R6-1 双轨口径比对：insights 新包 vs insights_legacy 同名方法。
    差异维度：签名参数 / 同步性 / 返回 dict 键集合。
    ⚠ 命中≠缺陷：先确认是「双向并行」还是「单向门面-委托」——后者由门面统一口径，
    风险等级完全不同。第一轮曾误判为双向并行，第六轮修正。"""
    def collect(prefix):
        m = {}
        for pth in _iter_py():
            rel = os.path.relpath(pth, SRC)[:-3].replace(os.sep, ".")
            if not rel.startswith(prefix):
                continue
            try:
                t = ast.parse(open(pth, encoding="utf-8").read())
            except Exception:
                continue
            for n in ast.walk(t):
                if not isinstance(n, ast.ClassDef):
                    continue
                for s in n.body:
                    if not isinstance(s, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        continue
                    args = [a.arg for a in s.args.args if a.arg != "self"]
                    keys = set()
                    for r in ast.walk(s):
                        if isinstance(r, ast.Return) and isinstance(r.value, ast.Dict):
                            for k in r.value.keys:
                                if isinstance(k, ast.Constant):
                                    keys.add(str(k.value))
                    m.setdefault(s.name, []).append({
                        "qual": f"{rel}.{n.name}.{s.name}", "args": args,
                        "keys": keys, "is_async": isinstance(s, ast.AsyncFunctionDef)})
        return m
    new, leg = collect("insights."), collect("insights_legacy")
    shared = sorted(set(new) & set(leg))
    rows = []
    for name in shared:
        a, b = new[name], leg[name]
        ka = set().union(*[x["keys"] for x in a]) if a else set()
        kb = set().union(*[x["keys"] for x in b]) if b else set()
        diffs = []
        if {tuple(x["args"]) for x in a} != {tuple(x["args"]) for x in b}:
            diffs.append("签名参数不同")
        if any(x["is_async"] for x in a) != any(x["is_async"] for x in b):
            diffs.append("同步性不同")
        if ka and kb and ka != kb:
            diffs.append("返回键不同(仅new:%s 仅legacy:%s)"
                         % (sorted(ka - kb)[:6], sorted(kb - ka)[:6]))
        rows.append({"name": name, "diffs": diffs})
    bad = [r for r in rows if r["diffs"]]
    # 关键定性：是否单向门面-委托
    facade = 0
    for pth in _iter_py():
        try:
            seg = open(pth, encoding="utf-8").read()
        except Exception:
            continue
        facade += seg.count("self.legacy.")
    print(f"   R6-1 共享方法 {len(shared)}  | 有差异 {len(bad)}")
    print(f"        新包 self.legacy.* 委托调用 {facade} 处"
          f"  → 单向门面-委托（非双向并行）" if facade else "")
    for r in bad:
        if any("返回键不同" in d for d in r["diffs"]):
            print(f"        ★返回键差异: {r['name']} — {r['diffs']}")
    return {"shared": shared, "diffs": bad, "legacy_delegations": facade}


def stage_probes_r6():
    print("[5f/6] 第六轮探针：双轨实现口径比对")
    r = probe_dual_track_v2()
    json.dump(r, open(os.path.join(OUT, "probes_r6.json"), "w"),
              ensure_ascii=False, indent=1)
    return r


def probe_route_leak():
    """R5-1 路由接漏：定义了 request 处理函数但未挂载到 Route 表。
    ⚠ 排除 `_` 开头的内部 helper（正常）。命中 = 接口定义了但不存在。"""
    rdir = os.path.join(SRC, "api")
    if not os.path.isdir(rdir):
        return []
    out = []
    for f in sorted(os.listdir(rdir)):
        if not f.endswith("_routes.py"):
            continue
        try:
            t = ast.parse(open(os.path.join(rdir, f), encoding="utf-8").read())
        except Exception:
            continue
        defined, mounted = set(), set()
        for n in ast.walk(t):
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                args = [a.arg for a in n.args.args]
                if args and "request" in args[0].lower():
                    defined.add(n.name)
                for d in n.decorator_list:
                    if re.match(r"@\w+\.(get|post|put|delete|patch|route|websocket)",
                                ast.unparse(d)):
                        mounted.add(n.name)
            if isinstance(n, ast.Call):
                fn = n.func
                nm = fn.attr if isinstance(fn, ast.Attribute) else getattr(fn, "id", "")
                if nm in ("Route", "Mount", "WebSocketRoute") and len(n.args) >= 2:
                    a = n.args[1]
                    if isinstance(a, ast.Name):
                        mounted.add(a.id)
        leak = sorted(x for x in (defined - mounted) if not x.startswith("_"))
        if leak:
            out.append({"file": "api/" + f, "unmounted": leak})
    return out


def probe_orphan_v2():
    """R5-2 孤儿函数 triage（V2 修正版）。
    第二轮 R2-1 的缺陷：只统计 ast.Name / ast.Attribute，漏掉了 ast.alias
    （from X import Y 的 Y 不是 Name 节点），导致跨模块导入的调用全部被误判为孤儿。
    本版补上 alias + 字符串引用（动态分发）+ 装饰器注册三类证据。"""
    names = collections.Counter()
    strrefs = collections.Counter()
    for base in (SRC, os.path.join(REPO, "tests"),
                 os.path.join(REPO, "scripts"), os.path.join(REPO, "nodered")):
        if not os.path.isdir(base):
            continue
        for dp, _, fs in os.walk(base):
            for f in fs:
                if not f.endswith(".py"):
                    continue
                try:
                    t = ast.parse(open(os.path.join(dp, f), encoding="utf-8").read())
                except Exception:
                    continue
                for n in ast.walk(t):
                    if isinstance(n, ast.alias):
                        names[n.name.split(".")[0]] += 1
                        if n.asname:
                            names[n.asname] += 1
                    elif isinstance(n, ast.Name):
                        names[n.id] += 1
                    elif isinstance(n, ast.Attribute):
                        names[n.attr] += 1
                    elif isinstance(n, ast.Constant) and isinstance(n.value, str):
                        v = n.value.strip()
                        if v.isidentifier():
                            strrefs[v] += 1
    registered = set()
    for pth in _iter_py():
        try:
            t = ast.parse(open(pth, encoding="utf-8").read())
        except Exception:
            continue
        for n in ast.walk(t):
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                for d in n.decorator_list:
                    du = ast.unparse(d)
                    if any(k in du for k in ("mcp.tool", "tool(", "@app.",
                                             "router.", "route", "@mcp")):
                        registered.add(n.name)
    try:
        orph = json.load(open(os.path.join(OUT, "probes_r2.json")))["orphan_precise"]
    except Exception:
        orph = []
    res = []
    for o in orph:
        short = o["qualname"].split(".")[-1]
        ev = []
        if short in registered:
            ev.append("装饰器注册")
        if names.get(short, 0):
            ev.append("导入/引用x%d" % names[short])
        if strrefs.get(short, 0):
            ev.append("字符串引用x%d" % strrefs[short])
        res.append({**o, "evidence": ev})
    return res


def stage_probes_r5():
    print("[5e/6] 第五轮探针：路由接漏 + 孤儿函数精确 triage")
    leak = probe_route_leak()
    ov2 = probe_orphan_v2()
    real = [o for o in ov2 if not o["evidence"]]
    print(f"   R5-1 未挂载的路由处理函数: {sum(len(x['unmounted']) for x in leak)}"
          f"  ← 已排除 `_` 开头的内部 helper")
    for x in leak:
        print(f"        {x['file']}: {', '.join(x['unmounted'])}")
    print(f"   R5-2 孤儿函数修正后真·零引用: {len(real)} / {len(ov2)}"
          f"  （V2 修正：补 ast.alias 可达性证据）")
    json.dump({"route_leak": leak, "orphan_v2": ov2},
              open(os.path.join(OUT, "probes_r5.json"), "w"), ensure_ascii=False, indent=1)
    return {"route_leak": leak, "orphan_v2": ov2}


def probe_mypy_redef():
    """R4-1 mypy 类型核查，聚焦 no-redef（重复定义 = 静默覆盖）。
    ⚠ 教训：188 个类型错误中 union-attr/assignment/arg-type 多为动态风格摩擦，
    真缺陷藏在 no-redef 这一小类里——分类比计数重要。"""
    rc, out = sh(f"cd {REPO} && python3 -m mypy src/memory_agent "
                 f"--ignore-missing-imports --no-error-summary 2>&1")
    cats = collections.Counter()
    redef = []
    for line in out.splitlines():
        m = re.search(r"\[([a-z-]+)\]$", line)
        if m:
            cats[m.group(1)] += 1
            if m.group(1) == "no-redef":
                redef.append(line.strip()[:160])
    print(f"   R4-1 mypy 错误总数 {sum(cats.values())}，分类 {dict(cats.most_common(6))}")
    print(f"       no-redef（高危·静默覆盖）: {len(redef)} 处 ← 需逐项 triage")
    for r in redef[:12]:
        print("          " + r[:140])
    return {"categories": dict(cats), "no_redef": redef}


def probe_complexity():
    """R4-2 radon 圈复杂度热点：复杂度 ≥31 (F/E 级)。
    高复杂度 = 改动回归风险，不等于有 bug。"""
    rc, out = sh(f"cd {REPO} && python3 -m radon cc src/memory_agent -a -s --min C 2>&1")
    hot = []
    for line in out.splitlines():
        m = re.search(r"\(([0-9]+)\)$", line.strip())
        if m and int(m.group(1)) >= 31:
            hot.append(line.strip()[:110])
    print(f"   R4-2 F/E 级高复杂度函数: {len(hot)}")
    return hot


def stage_probes_r4():
    print("[5d/6] 第四轮探针：类型系统 + 复杂度热点")
    r = probe_mypy_redef()
    c = probe_complexity()
    json.dump({"mypy": r, "complexity": c},
              open(os.path.join(OUT, "probes_r4.json"), "w"), ensure_ascii=False, indent=1)
    return {"mypy": r, "complexity": c}


def stage_probes_r3():
    print("[5c/6] 第三轮探针：变体扩散（variant-analysis 四步法）")
    fw = probe_first_wins()
    od = probe_order_dependency()
    print(f"   R3-1 first-wins 精确命中: {len(fw)}  ← 需 triage 上游排序/时间语义")
    print(f"   R3-2 顺序依赖宽口径候选: {len(od)}")
    json.dump({"first_wins": fw, "order_dep": od},
              open(os.path.join(OUT, "probes_r3.json"), "w"), ensure_ascii=False, indent=1)
    return {"first_wins": fw, "order_dep": od}


def stage_probes_r2():
    print("[5b/6] 第二轮探针（覆盖率导引 + 精确化）")
    cov = probe_coverage_gap()
    orp = probe_orphan_precise()
    tz = probe_timezone_classify()
    dt = probe_dual_track()
    lk = probe_lock_discipline()
    idem = probe_idempotency()
    real_tz = [x for x in tz if not x["code"].strip().startswith("#")]
    vc = collections.Counter(x["verdict"] for x in real_tz)
    print(f"   R2-1 孤儿函数(装饰器感知): {len(orp)}  ← 第一轮 PyCG 误报 1346")
    print(f"   R2-2 时区分类: {dict(vc)}  (仅代码行 {len(real_tz)})")
    print(f"   R2-3 双轨共享方法: {dt['shared_count']}")
    print(f"   R2-4 锁纪律可疑: {len(lk)}")
    print(f"   R2-5 幂等占位未释放: {len(idem)}")
    rep = {"coverage": cov, "orphan_precise": orp, "timezone": real_tz,
           "dual_track": dt, "lock": lk, "idempotency": idem}
    json.dump(rep, open(os.path.join(OUT, "probes_r2.json"), "w"),
              ensure_ascii=False, indent=1)
    return rep


def stage_probes():
    print("[5/6] 图谱导引定点探针")
    tz = probe_timezone()
    sd = probe_silent_degrade()
    zp = probe_zip_risk()
    ab = probe_async_block()
    cy, mods = probe_cycles()
    print(f"   绕过统一时钟的裸 datetime.now(): {len(tz)} 处")
    print(f"   静默降级（except 返回空值且无日志）: {len(sd)} 处")
    print(f"   zip() 无 strict: {len(zp)} 处")
    print(f"   async 内未卸载阻塞 I/O: {len(ab)} 处")
    print(f"   模块循环依赖: {len(cy)} 组（需逐个确认是否函数内延迟导入）")
    rep = {"timezone_bypass": tz, "silent_degrade": sd, "zip_no_strict": zp,
           "async_blocking": ab, "cycles": [list(c) for c in sorted(cy, key=len)]}
    json.dump(rep, open(os.path.join(OUT, "probes.json"), "w"), ensure_ascii=False, indent=1)
    return rep


# ──────────────────────────────────────────────────────────────
# 阶段 6 · 假阳性证伪（fp-check 口径）
# ──────────────────────────────────────────────────────────────
FALSE_POSITIVES = {
    "B608-SQL注入": "34 条全为占位符 SQL；f-string 插值点为列名白名单(update_member 7 项,带 assert) "
                    "与 ORDER BY 三元常量(_ue{i} 内部索引)，无外部输入拼接",
    "async阻塞误报": "mcp_server.py:1468 / behavior_routes.py:709 的同步 DB 调用均包在嵌套同步函数 "
                     "_query()/_fetch_rows()，并分别由 asyncio.to_thread 卸载，非缺陷",
    "除零": "algo_kernel:764 / arena:39 / identity_fusion:213,317 / entity_resolution:269 / "
            "store:4865 等均有 if not x 或 max(1,...) 守卫",
    "配置字段未定义": "35 处多为 FusionConfig/LearningConfig 等局部配置对象字段，非全局 Config 属性",
    "弱哈希 B324": "9 处用于事件 ID 与内容寻址，非口令/签名场景",
    "属性测试崩溃": "105 条 AttributeError 系将 str 喂给契约要求 dict 的参数，属契约外输入",
    "模块循环依赖": "17 组均为 runtime 中心 + 函数内延迟导入(config.py:534 / house_time.py:146)，"
                    "无启动期循环风险",
}


def stage_verify():
    print("[6/6] 假阳性登记（必须逐条证伪后才可写入结论）")
    for k, v in FALSE_POSITIVES.items():
        print(f"   ✗ {k}: {v[:76]}...")
    return FALSE_POSITIVES


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "all"
    if cmd in ("all", "graph"):
        cg = os.path.join(OUT, "callgraph.json")
        cg = stage_graph() or cg
        stage_module_graph(cg)
    if cmd in ("all", "test"):
        stage_test()
    if cmd in ("all", "static"):
        stage_static()
    if cmd in ("all", "property"):
        stage_property()
    if cmd in ("all", "probes"):
        stage_probes()
    if cmd in ("all", "probes2", "r2"):
        stage_probes_r2()
        stage_property_untested()
    if cmd in ("all", "probes12", "r12"):
        stage_probes_r12()
    if cmd in ("all", "probes11", "r11"):
        stage_probes_r11()
    if cmd in ("all", "probes10", "r10"):
        stage_probes_r10()
    if cmd in ("all", "probes9", "r9"):
        stage_probes_r9()
    if cmd in ("all", "probes8", "r8"):
        stage_probes_r8()
    if cmd in ("all", "probes7", "r7"):
        stage_probes_r7()
    if cmd in ("all", "probes6", "r6"):
        stage_probes_r6()
    if cmd in ("all", "probes5", "r5"):
        stage_probes_r5()
    if cmd in ("all", "probes4", "r4"):
        stage_probes_r4()
    if cmd in ("all", "probes3", "r3"):
        stage_probes_r3()
        print("   变异测试: python3 mutr3.py exp|ctrl  （mutmut 全库过慢，改用定向变异器）")
    if cmd in ("all", "verify"):
        stage_verify()
    print(f"\n产物目录: {OUT}")


if __name__ == "__main__":
    main()
