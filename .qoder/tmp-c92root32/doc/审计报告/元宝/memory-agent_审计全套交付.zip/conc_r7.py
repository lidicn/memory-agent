# -*- coding: utf-8 -*-
"""R7 并发与竞态探针（第七轮 · V3 迭代核心）
三个检测维度，按置信度从高到低：
  R7-1 锁覆盖不对称：同类方法有的持锁有的不持锁
  R7-2 共享可变状态：跨请求共享的 dict/list 被无锁修改
  R7-3 TOCTOU：check-then-act 跨 await/无锁边界
"""
import ast, os, json, collections
SRC = "/data/workspace/ma/src/memory_agent"
OUT = "/data/workspace/audit_out"

def iter_py():
    for dp, _, fs in os.walk(SRC):
        for f in fs:
            if f.endswith(".py"):
                yield os.path.join(dp, f)

# ── R7-1 锁覆盖不对称 ─────────────────────────────────────────
def probe_lock_asymmetry():
    """同一个类里，写操作方法有的 with self._lock 有的没有 → 竞态"""
    rows = []
    for p in iter_py():
        rel = os.path.relpath(p, SRC)
        try:
            t = ast.parse(open(p, encoding="utf-8").read())
        except Exception:
            continue
        for cls in ast.walk(t):
            if not isinstance(cls, ast.ClassDef):
                continue
            has_lock = False
            for n in ast.walk(cls):
                if isinstance(n, ast.Attribute) and n.attr in ("_lock", "lock", "_mutex"):
                    has_lock = True
            if not has_lock:
                continue
            writers = []
            for s in cls.body:
                if not isinstance(s, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    continue
                if s.name.startswith("_") and s.name != "__init__":
                    continue
                seg = ast.unparse(s)
                # 写操作：赋值给 self.X / dict 修改 / append / pop
                writes = any(k in seg for k in
                             ("self.", "append(", "pop(", "[", "= ")) and (
                    ".append(" in seg or ".pop(" in seg or ".update(" in seg
                    or ".add(" in seg or "self._" in seg)
                if not writes:
                    continue
                locked = ("with self._lock" in seg or "with self._mutex" in seg
                          or "with self.lock" in seg or "self._lock" in seg)
                writers.append((s.name, s.lineno, locked))
            if writers:
                un = [w for w in writers if not w[2]]
                lo = [w for w in writers if w[2]]
                if un and lo:   # 混用 = 不对称
                    rows.append({"file": rel, "cls": cls.name, "line": cls.lineno,
                                 "unlocked_writers": [(w[0], w[1]) for w in un],
                                 "locked_count": len(lo)})
    return rows

# ── R7-2 共享可变状态 ─────────────────────────────────────────
def probe_shared_mutable():
    """模块级 dict/list/set 被函数无锁修改 → 跨请求共享状态竞态"""
    rows = []
    for p in iter_py():
        rel = os.path.relpath(p, SRC)
        src = open(p, encoding="utf-8").read()
        try:
            t = ast.parse(src)
        except Exception:
            continue
        # 模块级可变容器
        globals_mut = {}
        for n in t.body:
            if isinstance(n, ast.Assign):
                for tg in n.targets:
                    if isinstance(tg, ast.Name):
                        v = ast.unparse(n.value)
                        if v.startswith(("{", "dict(")) or v.startswith(("[", "list(")) \
                           or v.startswith("set(") or v.startswith("collections"):
                            globals_mut[tg.id] = n.lineno
            elif isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name):
                v = ast.unparse(n.value) if n.value else ""
                ann = ast.unparse(n.annotation)
                if v.startswith(("{", "dict(", "[", "list(", "set(")) or \
                   any(k in ann for k in ("Dict", "List", "Set", "dict", "list", "set")):
                    globals_mut[n.target.id] = n.lineno
        if not globals_mut:
            continue
        for fn in ast.walk(t):
            if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            seg = ast.unparse(fn)
            locked = "_lock" in seg or "with lock" in seg
            for gname, gln in globals_mut.items():
                # 直接修改：gname[...] = / gname.append / .pop / .add / .update
                mods = (f"{gname}[" in seg or f"{gname}.append" in seg
                        or f"{gname}.pop" in seg or f"{gname}.add" in seg
                        or f"{gname}.update" in seg or f"{gname}.setdefault" in seg
                        or f"{gname}.clear" in seg)
                if mods and not locked:
                    rows.append({"file": rel, "global": gname, "gline": gln,
                                 "func": fn.name, "line": fn.lineno})
    return rows

# ── R7-3 TOCTOU ───────────────────────────────────────────────
def probe_toctou():
    """check-then-act 跨越 await 或无锁边界：
    形如  if X in D: ... await ... ; D[X] = ...
    检测：同一函数内先读判空/判存在，之后有 await，再写同一容器"""
    rows = []
    for p in iter_py():
        rel = os.path.relpath(p, SRC)
        try:
            t = ast.parse(open(p, encoding="utf-8").read())
        except Exception:
            continue
        for fn in ast.walk(t):
            if not isinstance(fn, ast.AsyncFunctionDef):
                continue
            # 收集 await 位置与语句顺序
            body = fn.body
            awaits = [n for n in ast.walk(fn) if isinstance(n, ast.Await)]
            if not awaits:
                continue
            await_lines = sorted({a.lineno for a in awaits})
            # 找「读-await-写」序列：同一名字先出现在 If 测试，后在 await 之后被赋值
            reads = []   # (name, lineno)
            for n in ast.walk(fn):
                if isinstance(n, ast.If):
                    seg = ast.unparse(n.test)
                    for tok in ("in ", "is None", "not None", "==", "!="):
                        if tok in seg:
                            for nm in [x.id for x in ast.walk(n.test)
                                       if isinstance(x, ast.Name)]:
                                reads.append((nm, n.lineno))
            writes = []
            for n in ast.walk(fn):
                if isinstance(n, (ast.Assign, ast.AugAssign)):
                    tg = n.targets[0] if isinstance(n, ast.Assign) else n.target
                    if isinstance(tg, ast.Name):
                        writes.append((tg.id, n.lineno))
                    elif isinstance(tg, ast.Subscript):
                        v = ast.unparse(tg.value)
                        if v.isidentifier():
                            writes.append((v, n.lineno))
            for rname, rln in reads:
                for wname, wln in writes:
                    if rname != wname or wln <= rln:
                        continue
                    # 中间至少有一个 await
                    if any(rln < al < wln for al in await_lines):
                        rows.append({"file": rel, "func": fn.name, "line": rln,
                                     "name": rname, "write_line": wln,
                                     "await_between": sum(1 for al in await_lines
                                                          if rln < al < wln)})
                        break
    return rows

if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    r1 = probe_lock_asymmetry()
    r2 = probe_shared_mutable()
    r3 = probe_toctou()
    print("R7-1 锁覆盖不对称（同类方法有的持锁有的不持锁）:", len(r1))
    for x in r1[:12]:
        print(f"    {x['file']}:{x['line']} {x['cls']}  未持锁写方法: "
              f"{[w[0] for w in x['unlocked_writers']][:5]}")
    print("\nR7-2 模块级共享可变状态被无锁修改:", len(r2))
    c = collections.Counter((x['file'], x['global']) for x in r2)
    for (f, g), n in c.most_common(12):
        print(f"    {f}  {g}  修改点 {n}")
    print("\nR7-3 TOCTOU（读-await-写，跨越挂起点）:", len(r3))
    for x in r3[:12]:
        print(f"    {x['file']}:{x['line']} {x['func']}() 变量 {x['name']} "
              f"读@L{x['line']} → 写@L{x['write_line']} 中间 await {x['await_between']}")
    json.dump({"lock_asym": r1, "shared_mutable": r2, "toctou": r3},
              open(os.path.join(OUT, "conc_r7.json"), "w"), ensure_ascii=False, indent=1)
