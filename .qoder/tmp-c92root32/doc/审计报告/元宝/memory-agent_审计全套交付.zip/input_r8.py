# -*- coding: utf-8 -*-
"""R8 外部输入边界探针（第八轮 · V3 剩余部分）
思路：从「外部入口」出发，追踪未校验即进入危险汇点(sink)的路径。
  入口 entry: HTTP 请求体字段、MQTT payload、HA 事件属性、设备上报、query 参数、header
  汇点 sink : SQL 执行/拼接、文件路径、eval/exec、subprocess、模板渲染、LLM prompt 拼接
判定：入口 → ... → sink，中间无校验函数（int()/float()/正则/白名单/try-except 类型转换）
"""
import ast, os, json, collections
SRC = "/data/workspace/ma/src/memory_agent"
OUT = "/data/workspace/audit_out"

def iter_py():
    for dp, _, fs in os.walk(SRC):
        for f in fs:
            if f.endswith(".py"):
                yield os.path.join(dp, f)

# 入口识别：从 request/body/payload/event 取值的模式
ENTRY_PAT = [
    r"\.get\(\s*['\"]",            # body.get("x")
    r"await\s+json_body",          # await json_body(request)
    r"request\.query_params",
    r"request\.headers\.get",
    r"request\.path_params",
    r"payload\.get", r"msg\.payload",
    r"attrs\.get", r"attributes\.get",
    r"data\.get\(", r"ev\.get\(", r"event\.get\(",
]
# 校验信号：出现即认为该值被净化
GUARD_PAT = [
    r"\bint\s*\(", r"\bfloat\s*\(", r"\bstr\s*\(", r"\bbool\s*\(",
    r"\bisinstance\s*\(", r"\bre\.(match|search|fullmatch|sub)\s*\(",
    r"\.strip\(\)", r"\bmax\s*\(\s*\d", r"\bmin\s*\(\s*\d",
    r"\bclamp\s*\(", r"\bin\s+\w*(WHITE|ALLOW|VALID|_SET|_LIST)",
    r"\braise\b", r"\breturn\s+(error|err)\b",
]
# 危险汇点
SINK_PAT = [
    (r"\.execute\s*\(\s*f['\"]", "SQL f-string 拼接"),
    (r"\.execute\s*\(\s*\w+\s*\+", "SQL 字符串拼接"),
    (r"\.executescript\s*\(", "executescript"),
    (r"\beval\s*\(", "eval"),
    (r"\bexec\s*\(", "exec"),
    (r"subprocess\.(run|call|Popen|check_output)", "subprocess"),
    (r"os\.system\s*\(", "os.system"),
    (r"open\s*\(\s*f['\"]", "文件路径 f-string"),
    (r"os\.path\.join\s*\([^)]*\+", "路径拼接"),
    (r"shutil\.(rmtree|move|copy)", "文件操作"),
    (r"\.format\s*\([^)]*\)\s*\)?\s*$", "字符串格式化(弱信号)"),
]

import re as _re

def probe_entry_to_sink():
    """按函数粒度：函数内同时有『入口取值』与『危险汇点』，且缺少校验 → 候选"""
    rows = []
    for pth in iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            t = ast.parse(open(pth, encoding="utf-8").read())
        except Exception:
            continue
        for fn in ast.walk(t):
            if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            seg = ast.unparse(fn)
            entries = [p for p in ENTRY_PAT if _re.search(p, seg)]
            if not entries:
                continue
            guards = [p for p in GUARD_PAT if _re.search(p, seg)]
            for sp, sname in SINK_PAT:
                if sname.startswith("字符串格式化"):
                    continue  # 弱信号，噪音太大，跳过
                if _re.search(sp, seg):
                    rows.append({
                        "file": rel, "func": fn.name, "line": fn.lineno,
                        "sink": sname,
                        "entry_count": len(entries),
                        "guard_count": len(guards),
                        "guards": guards[:4],
                        "no_guard": len(guards) == 0,
                    })
    return rows

# R8-2: 数值型参数越界（limit/days/top_n/offset 未经 clamp 直接进 SQL LIMIT）
NUM_PARAM = ("limit", "days", "top_n", "topn", "offset", "max_rows", "hours",
             "minutes", "count", "page", "size", "window", "rounds", "temperature")

def probe_numeric_bound():
    """找：数值参数从入口取值后，直接传入 SQL/切片，中间无 int()/clamp/max-min"""
    rows = []
    for pth in iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            t = ast.parse(open(pth, encoding="utf-8").read())
        except Exception:
            continue
        for fn in ast.walk(t):
            if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            seg = ast.unparse(fn)
            for np_ in NUM_PARAM:
                # 形如: np = xxx.get("np") 或 np = body.get(...)
                m = _re.search(rf"\b{np_}\s*=\s*[^=]*\.get\(\s*['\"]{np_}['\"]", seg)
                if not m:
                    continue
                # 是否有校验
                guarded = _re.search(
                    rf"\b{np_}\s*=\s*(int|float|max|min|clamp|_clamp|clamp_limit|"
                    rf"safe_int|_safe)\s*\(", seg) or _re.search(
                    rf"\b{np_}\s*=\s*max\s*\(.*\b{np_}", seg)
                if guarded:
                    continue
                rows.append({"file": rel, "func": fn.name, "line": fn.lineno,
                             "param": np_, "snippet": m.group(0)[:80]})
    return rows

# R8-3: 外部字符串直接进入文件路径
def probe_path_traversal():
    rows = []
    for pth in iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            t = ast.parse(open(pth, encoding="utf-8").read())
        except Exception:
            continue
        for fn in ast.walk(t):
            if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            seg = ast.unparse(fn)
            if not _re.search(r"open\s*\(|os\.path\.join\s*\(|Path\s*\(", seg):
                continue
            if not _re.search(r"\.get\(\s*['\"]", seg):
                continue
            # 是否有 basename / 白名单 / startswith 校验
            safe = _re.search(r"basename|safe_name|WHITE|ALLOWED|startswith\(\s*['\"]", seg)
            if safe:
                continue
            rows.append({"file": rel, "func": fn.name, "line": fn.lineno,
                         "snippet": seg[:150]})
    return rows

if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    r1 = probe_entry_to_sink()
    r2 = probe_numeric_bound()
    r3 = probe_path_traversal()
    print("R8-1 入口→危险汇点:", len(r1), " 其中无校验:", sum(1 for x in r1 if x['no_guard']))
    for x in r1[:14]:
        print(f"    {x['file']}:{x['line']} {x['func']}()  [{x['sink']}] "
              f"守卫{x['guard_count']}")
    print("\nR8-2 数值参数无边界校验:", len(r2))
    c = collections.Counter(x['param'] for x in r2)
    print("   按参数:", dict(c.most_common(8)))
    for x in r2[:12]:
        print(f"    {x['file']}:{x['line']} {x['func']}()  {x['snippet']}")
    print("\nR8-3 外部字符串→文件路径:", len(r3))
    for x in r3[:8]:
        print(f"    {x['file']}:{x['line']} {x['func']}()")
    json.dump({"entry_sink": r1, "numeric": r2, "path": r3},
              open(os.path.join(OUT, "input_r8.json"), "w"), ensure_ascii=False, indent=1)
