# -*- coding: utf-8 -*-
"""R12-1 圈复杂度自算（radon 在沙箱不可用，用 AST 等价实现）
CC = 1 + 分支节点数（if/for/while/except/with?/布尔运算/三元/assert/comprehension 的 if）
"""
import ast, os, json
SRC="/data/workspace/ma/src/memory_agent"
OUT="/data/workspace/audit_out"

BRANCH=(ast.If, ast.For, ast.AsyncFor, ast.While, ast.ExceptHandler,
        ast.With, ast.AsyncWith, ast.Assert, ast.IfExp)

def cc_of(fn):
    c=1
    for n in ast.walk(fn):
        if isinstance(n,BRANCH): c+=1
        elif isinstance(n,ast.BoolOp): c+=len(n.values)-1
        elif isinstance(n,(ast.ListComp,ast.SetComp,ast.DictComp,ast.GeneratorExp)):
            c+=sum(1 for g in n.generators for _ in g.ifs)
    return c

def main():
    rows=[]
    for dp,_,fs in os.walk(SRC):
        for f in fs:
            if not f.endswith('.py'): continue
            p=os.path.join(dp,f); rel=os.path.relpath(p,SRC)
            try: t=ast.parse(open(p,encoding='utf-8').read())
            except Exception: continue
            for n in ast.walk(t):
                if not isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)): continue
                c=cc_of(n)
                if c>=15:
                    rows.append({'cc':c,'file':rel,'line':n.lineno,'name':n.name,
                                 'end':getattr(n,'end_lineno',n.lineno),
                                 'stmts':sum(1 for x in ast.walk(n) if isinstance(x,ast.stmt))})
    rows.sort(key=lambda r:-r['cc'])
    print(f"复杂度 >=15 的函数: {len(rows)}")
    for r in rows:
        print(f"  CC={r['cc']:3d}  {r['file']}:{r['line']}  {r['name']}  ({r['stmts']} 语句)")
    json.dump(rows,open(os.path.join(OUT,'complexity_r12.json'),'w'),ensure_ascii=False,indent=1)
    return rows

if __name__=='__main__':
    main()
