# -*- coding: utf-8 -*-
"""R6-1 双轨实现口径比对器（第六轮）
insights 新包 vs insights_legacy：37 个共享方法名，逐个比对签名与返回形状。
差异即风险：同一查询走两轨返回不同结构 = 调用方拿到不一致数据。
"""
import ast, os, json, collections
SRC = "/data/workspace/ma/src/memory_agent"
OUT = "/data/workspace/audit_out"

def collect(prefix):
    """收集 prefix 下所有类中方法的签名与返回结构证据"""
    m = {}
    for dp, _, fs in os.walk(SRC):
        for f in fs:
            if not f.endswith(".py"):
                continue
            p = os.path.join(dp, f)
            rel = os.path.relpath(p, SRC)[:-3].replace(os.sep, ".")
            if not rel.startswith(prefix):
                continue
            try:
                t = ast.parse(open(p, encoding="utf-8").read())
            except Exception:
                continue
            for n in ast.walk(t):
                if not isinstance(n, ast.ClassDef):
                    continue
                for s in n.body:
                    if not isinstance(s, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        continue
                    args = [a.arg for a in s.args.args if a.arg != "self"]
                    rets = []
                    for r in ast.walk(s):
                        if isinstance(r, ast.Return) and r.value is not None:
                            v = ast.unparse(r.value)
                            if len(v) < 200:
                                rets.append(v)
                    # 返回 dict 字面量的键
                    keys = set()
                    for r in ast.walk(s):
                        if isinstance(r, ast.Return) and isinstance(r.value, ast.Dict):
                            for k in r.value.keys:
                                if isinstance(k, ast.Constant):
                                    keys.add(str(k.value))
                    m.setdefault(s.name, []).append({
                        "qual": f"{rel}.{n.name}.{s.name}", "args": args,
                        "rets": sorted(set(rets))[:6], "keys": sorted(keys),
                        "is_async": isinstance(s, ast.AsyncFunctionDef)})
    return m

def main():
    new = collect("insights.")
    leg = collect("insights_legacy")
    shared = sorted(set(new) & set(leg))
    rows = []
    for name in shared:
        a, b = new[name], leg[name]
        args_a = {tuple(x["args"]) for x in a}
        args_b = {tuple(x["args"]) for x in b}
        keys_a = set().union(*[set(x["keys"]) for x in a]) if a else set()
        keys_b = set().union(*[set(x["keys"]) for x in b]) if b else set()
        async_a = any(x["is_async"] for x in a)
        async_b = any(x["is_async"] for x in b)
        diffs = []
        if args_a != args_b:
            diffs.append("签名参数不同")
        if async_a != async_b:
            diffs.append(f"同步性不同(new_async={async_a},legacy_async={async_b})")
        if keys_a and keys_b and keys_a != keys_b:
            only_a = sorted(keys_a - keys_b)[:8]
            only_b = sorted(keys_b - keys_a)[:8]
            if only_a or only_b:
                diffs.append(f"返回键不同(仅new:{only_a} 仅legacy:{only_b})")
        rows.append({"name": name, "diffs": diffs,
                     "new": [x["qual"] for x in a][:2],
                     "legacy": [x["qual"] for x in b][:2]})
    bad = [r for r in rows if r["diffs"]]
    print(f"共享方法: {len(shared)}  |  有差异: {len(bad)}")
    print("\n=== 口径差异（需人工判是否为缺陷）===")
    for r in bad:
        print(f"\n  {r['name']}")
        for d in r["diffs"]:
            print(f"      {d}")
        print(f"      new: {r['new']}")
        print(f"      leg: {r['legacy']}")
    json.dump({"shared": shared, "rows": rows},
              open(os.path.join(OUT, "dual_track_r6.json"), "w"),
              ensure_ascii=False, indent=1)
    return rows

if __name__ == "__main__":
    main()
