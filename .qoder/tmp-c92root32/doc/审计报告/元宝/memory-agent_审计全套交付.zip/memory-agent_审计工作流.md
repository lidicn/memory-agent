# memory-agent 审计工作流（图谱导引版）

> 整合：GitHub 开源测试/分析套件 + 审计 skill + 自研图谱探针
> 目标：**先拿到全图，再用图定位 bug**，把"逐行通读 54524 行"变成"按枢纽与异常点定点打击"

---

## 一、为什么需要图谱先行

memory-agent 有 127 个模块、54524 行代码、1096 项测试。在这种体量下：

- **逐行通读**不现实，且读了也抓不住跨模块 bug——真实缺陷常活在"接缝"上（谁调谁、谁的时钟口径不一致）。
- **纯工具扫描**会产出大量假阳性（本轮 34 条 SQL 注入告警全部是误报）。
- **测试全绿**不等于没 bug——本轮发现的问题全部落在 1096 项测试之外。

图谱的价值：先用调用关系识别出**枢纽**（改一处影响全盘的节点）与**绕过点**（不走统一基础设施的野路子），再把审查火力压到这些位置。

---

## 二、工作流六阶段

```
阶段 1  建图        PyCG 调用图 + 模块依赖图可视化        → 拿到全图与枢纽
阶段 2  测试基线    pytest 全量 + 覆盖率                  → 确认"哪里没被测"
阶段 3  静态扫描    ruff / bandit / pyflakes / vulture    → 批量候选告警
阶段 4  属性测试    Hypothesis 全输入域反例搜索            → 纯函数的边界崩溃
阶段 5  定点探针    5 个自研 AST 探针（图谱导引）          → 本项目专属缺陷家族
阶段 6  假阳性证伪  fp-check 口径逐条读上下文              → 未证伪不写入结论
```

一键执行：`python3 ma_audit.py all`（各阶段可单独跑，如 `ma_audit.py probes`）

---

## 三、各阶段的工具与产出

### 阶段 1 · 建图

| 工具 | 来源 | 用途 | 本轮状态 |
|---|---|---|---|
| **PyCG** | github.com/vitsalis/PyCG（ICSE'21） | 调用图，输出 JSON 邻接表 | ✅ 主力，2901 节点 / 7257 边 |
| **pyan3** | PyCQA 系 | 静态 AST 调用图，dot/graphml | ✅ 已装，备用交叉验证 |
| **code2flow** | github.com/scottrogowski/code2flow | 跨语言调用图（需 Graphviz） | ✅ 已装 |
| **pydeps** | github.com/thebjorn/pydeps | 模块依赖图 | ✅ 已装（沙箱环境易重置，用自写 AST 兜底） |
| **import-linter** | seddonym/import-linter | 分层架构违规检测 | ✅ 已装 |
| **networkx + matplotlib** | — | 图谱折叠与可视化 | ✅ 生成模块依赖图 PNG |

> ⚠️ PyCG 0.0.8 的安装目录名为大写 `PyCG`，直接 `python3 -m pycg` 会失败。
> 解决：把 `PyCG/` 复制到某目录，用 `PYTHONPATH=<该目录> python3 -m pycg --package src/memory_agent` 运行。

**产出**：`audit_out/callgraph.json`、`audit_out/module_graph.png`

**图谱读法**（三个信号）：

1. **枢纽节点**——入度最高 = 改一处影响全盘：`api.deps.ok(177)`、`api.deps.runtime(174)`、`require_user(148)`、`store.now_local(121)`、`runtime.get_runtime(101)`。审查火力优先给这些。
2. **强耦合对**——可能缺抽象边界：`api→runtime(138)`、`mcp_server→runtime(110)`、`insights_legacy↔insights(51+18，双向)`。
3. **绕过点**——不走枢纽的野路子（见阶段 5 探针）。**这是本轮找到真 bug 的地方。**

### 阶段 2 · 测试基线

`pytest` + `pytest-asyncio` + `pytest-cov`（+ xdist/randomly/timeout 可选）。

> ⚠️ 必须设 `JWT_SECRET`，否则 `Config` 按 WO-MA-004 ③ 抛 `RuntimeError` 拒绝启动，测试整片假红。

本轮结果：**1096 passed / 23 skipped / 0 failed**。

### 阶段 3 · 静态扫描

| 套件 | 产出 | 说明 |
|---|---|---|
| Ruff（16 组规则） | 377 条（剔除中文字符/行宽噪音后） | 主力 |
| Bandit | 49 条（B608×34 / B324×9 / B104×4） | 安全反模式 |
| Pyflakes | **0** | 无未定义名、无未使用导入 |
| Vulture | 6 条（置信度≥80%） | 死代码 |

Semgrep 因包体 67MB 超沙箱文件上限未装上，用上表三件套覆盖。

### 阶段 4 · 属性测试

Hypothesis 对 27 个纯函数各跑 300 例（文本/None/整数/浮点/嵌套结构/边界值）。

**结果：契约内输入零崩溃。**

### 阶段 5 · 定点探针（本工作流的差异化部分）

这是"图谱导引"真正落地的地方——先由阶段 1 识别出**统一基础设施枢纽**，再扫描谁绕过了它。

| 探针 | 检测什么 | 本轮 |
|---|---|---|
| `probe_timezone` | 绕过 `now_local()` 的裸 `datetime.now()/utcnow()` | 29 处 → 筛出 **1 条真 bug** |
| `probe_silent_degrade` | except 内返回空值且无日志 | 62 处 |
| `probe_zip_risk` | `zip()` 无 `strict=` | 19 处 |
| `probe_async_block` | async 内未卸载的阻塞 I/O（排除 to_thread 包裹） | 10 处 |
| `probe_cycles` | 模块循环依赖 + 区分是否延迟导入 | 17 组 |

**`probe_timezone` 是怎么找到 bug 的**（完整链路，可作为模板复用）：

1. 图谱显示 `store.now_local` 入度 121、`house_time` 相关节点密集 → **时钟是全局基础设施枢纽**。
2. 扫描 65 处 `datetime.now()`/`time.time()` 直接调用。
3. 分类：`time.time()` 多用于 TTL 差值比较（与时区无关，安全）；`datetime.now()` 用于**落盘/落库/时间窗口**则危险。
4. 项目已在 `causal_scanner.py:44`、`mcp_server.py:611`、`backup.py:34` 三处写下**同款警告注释**（"容器跑在 UTC 时裸 datetime.now() 会让…"）→ 这是**已知的历史 bug 家族，已系统性修复**。
5. 逐个比对 → 发现 `api/nr_routes.py:125` 是漏网之鱼：**同款模式、同款风险、没改**。

> 这个方法论的要点：**已知缺陷的注释是最好的探针种子**。项目自己写下的"这里曾经出错"，比任何通用规则集都精准。

### 阶段 6 · 假阳性证伪

按 `fp-check` 口径：每条告警读上下文证伪后才写入结论。本轮证伪清单见审计报告第四节。

---

## 三·补 第二轮新增：覆盖率导引

第二轮把切入角从"图谱"换成"覆盖率"，理由是——**1096 项测试全绿但总覆盖率只有 47%**。一个 180 行的核心算法模块若零覆盖，"测试通过"对它毫无意义。

```
先跑覆盖率 → 找 0% 覆盖模块 → 这些是 bug 温床 → 人工审 + 属性测试轰炸
```

新增探针（已固化进 `ma_audit.py`，`python3 ma_audit.py probes2`）：

| 探针 | 作用 |
|---|---|
| R2-0 `probe_coverage_gap` | 跑覆盖率，列 0% 覆盖模块 |
| R2-1 `probe_orphan_precise` | 孤儿函数**精确化**（第一轮 PyCG 误报 1346 → 装饰器感知后 68） |
| R2-2 `probe_timezone_classify` | 时区家族自动分类（AST 语句行排除注释/docstring） |
| R2-3 `probe_dual_track` | 双轨实现同名方法比对 |
| R2-4 `probe_lock_discipline` | connect() 后不持锁直接 execute |
| R2-5 `probe_idempotency` | reserve 后无 finalize/release |
| R2-6 `stage_property_untested` | **自动对 0% 覆盖模块做属性测试**，闭环 |

**关键教训**：R2-6 对 0% 覆盖模块跑了 9 个函数 × 200 例，**崩溃 0**——但第二轮最严重的两个 P1（P1-4 预测时间偏 4 小时、P1-5 熟人判成陌生人）**都不崩溃，只是算错**。

→ **属性测试只能兜住崩溃类缺陷；语义正确性必须靠人工审 + 针对性单测。** 这条写进方法论。

## 三·补2 第三轮新增：变体扩散 + 变异测试

第三轮的方向：**不再找新类别，而是把已确认缺陷当种子做扩散，并量化测试能否抓到它们。**

### 变体扩散（variant-analysis 四步法）

```
理解根因 → 精确匹配（全库扫该模式）→ 逐元素泛化 → triage（命中≠缺陷）
```

例：P1-4 根因抽象为「函数内不排序，却用 `if key not in d: d[key]=v` 取首个」。
全库扫出 8 处，triage 后仅 2 处为真缺陷——**命中率 25%，但性价比仍高于全库扫描**。

triage 三问：① 上游排序是什么？② 语义是不是"时间最早/最新"？③ 有没有显式 `sorted`？
（`change_attribution.py:95` 显式 `sorted` 后取首个，是正确范例，用来反证另两处是遗漏。）

### 变异测试：mutmut 不可用，改用定向变异器

mutmut 3.8 在 54524 行仓库上**变异体生成阶段过慢**（日志停在 `Generating mutants`），放弃。
改用自研 `mutr3.py`：只变异指定缺陷点 → 跑全量 1096 项测试 → **存活 = 测试盲区**。

| 变异点 | 结果 | 判定 |
|---|---|---|
| P1-4 behavior_predictor | 存活 | 测试盲区 |
| P1-5 identity_fusion | 存活 | 测试盲区 |
| P1-6 daily_profile | 被杀 | 测试能抓到 |
| 对照组 store.now_local 改名 | 被杀 | 验证测试确实在跑 |

### ⚠ 最关键的方法论收获：**"被杀"不等于安全**

杀掉 P1-6 变异的测试 `test_daily_first_occurrence` 写得**很对**——明确断言"每天只取第一次出现"。
但它喂 **ASC** 数据，生产喂 **DESC**。

> 函数在 ASC 下正确、DESC 下错误；测试用 ASC 通过；生产用 DESC 出错。

**比"完全没测"更危险**：0% 覆盖至少知道有风险；有测试、通过、还断言了正确语义，却因测试数据顺序与生产相反，给出虚假安全感。

→ **变异测试的"被杀"必须追查：是哪些测试杀的？测试的输入假设与生产一致吗？**

## 四、审计 skill 的分工

来自 `trailofbits/skills`（已安装到技能目录）：

| Skill | 在本工作流中的位置 |
|---|---|
| `audit-context-building` | 阶段 1——建系统图、标记"无保证的假设"，**不做结论** |
| `property-based-testing` | 阶段 4——判断哪些函数值得写属性测试 |
| `sharp-edges` | 阶段 3——危险 API / 失败开放模式 |
| `fp-check` | 阶段 6——强制证伪，未证伪不报 |
| `second-opinion` | 交叉复核——本轮的"async 阻塞误报"就是靠它翻转的 |
| `semgrep` / `sarif-parsing` | 阶段 3（本轮 semgrep 未装上，规则未参与） |

已排除的候选：`py-flow-mapper`（需 Python 3.12+）、`Code2KG`（需 Neo4j）、`RepoMap`（面向 TS）。

---

## 五、本轮产出清单

```
/data/workspace/
├── ma_audit.py                      # 六阶段工作流驱动脚本（可增量重跑）
├── audit_out/
│   ├── callgraph.json               # PyCG 调用图 2901 节点 / 7257 边
│   ├── module_graph.png             # 模块依赖图可视化
│   ├── probes.json                  # 5 个定点探针结果
│   ├── bandit.json / pytest.log
└── memory-agent_第一轮审计报告.md
```

---

## 六、复用建议

1. **新接手一个仓库时**，先跑 `ma_audit.py graph` 拿全图，认枢纽，不要急着读代码。
2. **找"已知缺陷家族"**，先 `grep` 项目内自己写的警告注释（"审计 P0-xx"、"容器跑在 UTC"、"CRITICAL-n"），把它们变成探针种子。
3. **扫描结果必须证伪**——本轮最贵的一条教训是：初版 AST 检测把 `asyncio.to_thread` 已正确卸载的调用误判为 P0，"async 卡死服务"，复核后才降级为 P2。
4. **PyCG 对装饰器注册的函数**（`@mcp.tool()`、路由装饰器）看不到调用者，静态图里会显示为孤儿——这类节点不能当死代码处理。
