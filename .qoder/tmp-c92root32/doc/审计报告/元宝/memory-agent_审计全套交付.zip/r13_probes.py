# -*- coding: utf-8 -*-
"""R13 探针（第十三轮）：委托方法规范化 + 时区点精确分类

独立成文件的原因：ma_audit.py 内联注入时遇到引号转义问题，且这两个探针
需要更精细的 AST 处理，单独文件更易维护与重跑。

用法: python3 r13_probes.py
"""
import ast, os, json, collections

SRC = "/data/workspace/ma/src/memory_agent"
OUT = "/data/workspace/audit_out"


def iter_py():
    for dp, _, fs in os.walk(SRC):
        for f in fs:
            if f.endswith(".py"):
                yield os.path.join(dp, f)


# ── R13-1 委托方法返回值规范化 ─────────────────────────────────
def probe_delegate_norm():
    """self.legacy.* 委托的返回值规范化。

    判定要点（两次踩坑总结）：
    · 必须先区分「公共接口」与「_ 开头内部 helper」。后者是
      LEGACY_CONTRACT_MEMBERS 契约转发，注释明确写了"不套 _degrade，
      调用失败必须抛真异常"——不做规范化是**预期行为**。
      只看"无规范化"会把 7 个内部 helper 全误判成缺陷。
    · 公共接口里，resolve_range / name_map / decorate 三个也是契约转发
      （返回类型非 Page 信封），需人工判断是否算缺陷。
    """
    ap = os.path.join(SRC, "insights", "api.py")
    if not os.path.exists(ap):
        return []
    t = ast.parse(open(ap, encoding="utf-8").read())
    rows = []
    for fn in ast.walk(t):
        if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        seg = ast.unparse(fn)
        if "self.legacy." not in seg:
            continue
        norm = []
        if "Page" in seg:
            norm.append("Page封装")
        if ".to_dict(" in seg:
            norm.append("to_dict")
        if '"has_more"' in seg or "'has_more'" in seg:
            norm.append("补分页键")
        rows.append({
            "name": fn.name, "line": fn.lineno, "norm": norm,
            "priv": fn.name.startswith("_"),
            "form": "直接return" if "return self.legacy" in seg else "赋值out",
        })
    return rows


# ── R13-2 时区点精确分类 ──────────────────────────────────────
def probe_tz_v3():
    """裸 datetime.now/utcnow，精确到语句行（排除注释与 docstring）。

    三轮迭代的教训：
    · 第一轮用文本匹配 → 把注释/docstring 里的警告文字也算成命中（29 处虚高）
    · 第十三轮第一轮用 AST 但未排除注释 → 仍有虚高
    · 本版排除注释与 docstring 行后剩 38 处，其中 11 处是
      datetime.now(timezone.utc) —— **显式带 tz 的 UTC 时间戳是正确做法**，
      可与库内时间戳安全比较，不是缺陷。
    真风险是 27 处 naive（无 tzinfo），且需再按「是否参与计算」分轻重：
      · 参与时间窗口/差值计算 → 功能性错误（如 P1-3）
      · 仅落库作元数据 → 显示偏差，危害低
    """
    rows = []
    for pth in iter_py():
        rel = os.path.relpath(pth, SRC)
        try:
            src = open(pth, encoding="utf-8").read()
            lines = src.splitlines()
            t = ast.parse(src)
        except Exception:
            continue
        skip = set()
        for i, l in enumerate(lines, 1):
            st = l.strip()
            if st.startswith("#") or st.startswith('"""') or st.startswith("'''"):
                skip.add(i)
        for n in ast.walk(t):
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef,
                              ast.ClassDef, ast.Module)):
                if ast.get_docstring(n) and n.body:
                    st = n.body[0]
                    lo = getattr(st, "lineno", 0)
                    hi = getattr(st, "end_lineno", 0)
                    for i in range(lo, hi + 1):
                        skip.add(i)
        for n in ast.walk(t):
            if not isinstance(n, ast.Call):
                continue
            fn = n.func
            nm = fn.attr if isinstance(fn, ast.Attribute) else getattr(fn, "id", "")
            if nm not in ("now", "utcnow", "today"):
                continue
            owner = ast.unparse(fn.value) if isinstance(fn, ast.Attribute) else ""
            if owner not in ("datetime", "dt"):
                continue
            if n.lineno in skip:
                continue
            ctx = lines[n.lineno - 1].strip() if n.lineno <= len(lines) else ""
            rows.append({
                "file": rel, "line": n.lineno, "ctx": ctx[:90],
                "aware": ("timezone.utc" in ctx) or ("timezone(" in ctx),
            })
    return rows


def main():
    os.makedirs(OUT, exist_ok=True)
    r1 = probe_delegate_norm()
    r2 = probe_tz_v3()
    pub = [x for x in r1 if not x["priv"]]
    priv = [x for x in r1 if x["priv"]]
    un = [x for x in pub if not x["norm"]]
    print("R13-1 insights/api.py 委托方法规范化")
    print(f"    合计 {len(r1)}：公共 {len(pub)} / 内部 helper {len(priv)}")
    print(f"    公共接口中无 Page 规范化: {len(un)}")
    for x in un:
        print(f"        {x['name']} @L{x['line']}  ({x['form']})")
    print(f"    内部 helper 无规范化: {len([x for x in priv if not x['norm']])}"
          f"  ← 预期行为（LEGACY_CONTRACT_MEMBERS 契约转发）")
    print()
    naive = [x for x in r2 if not x["aware"]]
    print(f"R13-2 裸 datetime.now/utcnow（语句级，已排除注释与 docstring）")
    print(f"    合计 {len(r2)}：显式 UTC {len(r2) - len(naive)}（正确做法）"
          f" / naive {len(naive)}（真风险候选）")
    c = collections.Counter(x["file"] for x in naive)
    print("    naive 分布:")
    for f, n in c.most_common():
        print(f"        {f}: {n}")
    json.dump({"delegate": r1, "tz": r2},
              open(os.path.join(OUT, "probes_r13.json"), "w"),
              ensure_ascii=False, indent=1)
    return {"delegate": r1, "tz": r2}


if __name__ == "__main__":
    main()
