"""MA 事件族：AF↔MA 深度联动的事件主题与公共信封的唯一机制层真源。

随 homesdk 0.3.5 加入（DCD 2026-11-17 裁定 `20261117-链主-AF-MA深度联动预案与契约v1四问-裁定.md` H1；
落字改单 `20261118-链主-homesdk0.3.5契约补清单-改单.md` A′）。

**为什么需要它**：AF↔MA 深度联动的事件族（`ma/behavior-state`／`ma/prediction`）此前只活在
MA 契约草稿 §三里，homesdk 契约表无出处 ⇒ AF 按草稿实现而非契约实现，两处真源必漂移。

**口径**：
- 主题命名＝**连字符**（Q1 已裁；现网 `ma/presence`／`ma/device-health`／`ma/insights` 全连字符）；
- 公共信封＝**七键**（MA 草稿 §三，逐字收录不改字段）：`type`／`source`／`payload_version`／
  `event_id`／`trace_id`／`ts`／`emitted_at`；
- `payload_version`＝`"1.0"`。

**边界**：只管"常量真源"，⛔ 背运行时——⛔ 解析、⛔ 发送、⛔ 订阅。各仓读这些常量去拼主题/组信封。
加字段＝minor（消费方忽略未知键）；删字段/改语义＝major（新旧主题双发期后下线）。
"""

from __future__ import annotations

from typing import Final

__all__ = [
    "EVENT_TOPICS",
    "PAYLOAD_VERSION",
    "ENVELOPE_KEYS",
    "TOPIC_BEHAVIOR_STATE",
    "TOPIC_PREDICTION",
]

#: 事件族主题（连字符；Q1 裁定）。`ma/anomaly` 为可选二期，不入首版。
TOPIC_BEHAVIOR_STATE: Final = "ma/behavior-state"
TOPIC_PREDICTION: Final = "ma/prediction"

#: 首版事件族主题集合（不含 `ma/anomaly`）。
EVENT_TOPICS: Final[frozenset[str]] = frozenset({TOPIC_BEHAVIOR_STATE, TOPIC_PREDICTION})

#: 公共信封版本号（MA 草稿 §三定稿）。
PAYLOAD_VERSION: Final = "1.0"

#: 公共信封七键（逐字收录，⛔ 增删改字段）。
#: `ts`＝家庭墙钟带偏移；`emitted_at`＝UTC 采集时刻。
ENVELOPE_KEYS: Final[tuple[str, ...]] = (
    "type",
    "source",
    "payload_version",
    "event_id",
    "trace_id",
    "ts",
    "emitted_at",
)
