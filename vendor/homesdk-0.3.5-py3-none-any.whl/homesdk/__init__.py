"""homesdk：ADM 生态共享安全地基。

它**不是服务**：不监听端口、不起进程、不联网、不进容器。被 import 时才存在，
和 `requests` 一样是库——所以发新版不需要任何一仓「重装才生效」的仪式。

六个模块 + 联动基础：

| 模块 | 管什么 | 失败时 |
|---|---|---|
| `consent` | 「主人答没答应」的唯一判定表 | 判 UNKNOWN ⇒ 不执行 |
| `config` | env 读取口径（`HOMESDK_` 前缀优先、空串算未配置） | `require_env` 抛 `MissingEnv` |
| `http` | 按 `HOMESDK_PEER_<名字>_URL` 寻址，**仓内零内置地址** | 抛 `PeerUnknown`，不回落 |
| `auth` | 按服务取凭据，**没有全局主密钥** | 空 headers / `AuthCheck.NO_CREDENTIALS` |
| `mqtt` | 只配置 client（QoS=1、重连退避），绝不连接 | 抛 `MqttCredentialsMissing` |
| `presence` | 联动基础：ADM 在线探测 + DB 公共收件箱投递 | 抛 `UnknownMember`/`MissingTraceId` |
| `time` | 家庭墙钟唯一入口（IANA 名口径，DST 安全） | 解析失败退固定偏移，不抛 |
| `areas` | 房间/区域唯一机制入口（HA `area_id` 为准） | 解析不到返回 `None`（契约：拒绝投递） |

顶层只 re-export 子模块，不做聚合门面：`homesdk.http.get(...)` 读得懂是谁在干活，
`homesdk.get(...)` 只会把「这条调用带没带鉴权」藏起来。
"""

from homesdk import adm, areas, auth, config, events, http, mqtt, time
from homesdk.consent import NO, UNKNOWN, YES, allows_execution, classify_answer
from homesdk import presence

__all__ = [
    "NO",
    "UNKNOWN",
    "YES",
    "adm",
    "allows_execution",
    "areas",
    "auth",
    "classify_answer",
    "config",
    "events",
    "http",
    "mqtt",
    "presence",
    "time",
]
__version__ = "0.3.5"
