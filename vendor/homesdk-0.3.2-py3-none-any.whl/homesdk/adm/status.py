"""adm/*/status 载荷序列化（契约 v2.0 §7.1）。

status 从 0.3.1 的字面量 ``online``/``offline`` 升级为 JSON：

    {"state": "online|offline|degraded", "ts": 1760000000,
     "degraded": false, "reasons": ["ADM_ERR_..."], "version": "2.6"}

``decode_status`` 兼容旧字面量：非 JSON 的 ``online``/``offline`` 按
``{"state": ...}`` 解析，**不得丢弃、不得抛错**——过渡期三仓不能因为"对方还没升级"
就丢件。
"""

from __future__ import annotations

import json as _json
import time as _time
from typing import Any, Final

STATE_ONLINE: Final = "online"
STATE_OFFLINE: Final = "offline"
STATE_DEGRADED: Final = "degraded"

_STATES: Final[frozenset[str]] = frozenset({STATE_ONLINE, STATE_OFFLINE, STATE_DEGRADED})


def encode_status(
    state: str,
    *,
    version: str,
    ts: int | None = None,
    degraded: bool | None = None,
    reasons: list[str] | tuple[str, ...] | None = None,
) -> str:
    """序列化 adm status 为 JSON 字符串（紧凑分隔符）。

    - ``state`` 必须在 {online, offline, degraded}，否则抛 ``ValueError``；
    - ``reasons`` 非空 ⇒ 强制 ``degraded=True``（不许"给了原因却标着 healthy"）；
    - ``degraded`` 缺省 = ``bool(reasons)``；``ts`` 缺省 = ``int(time.time())``。
    """
    if state not in _STATES:
        raise ValueError(f"未知 adm status state：{state!r}（允许 {sorted(_STATES)}）")
    reason_list = list(reasons or ())
    if degraded is None:
        degraded = bool(reason_list)
    if reason_list and not degraded:
        degraded = True
    payload: dict[str, Any] = {
        "state": state,
        "ts": int(_time.time()) if ts is None else int(ts),
        "degraded": bool(degraded),
        "reasons": reason_list,
        "version": version,
    }
    return _json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def decode_status(payload: str | bytes) -> dict[str, Any]:
    """解析 adm status 载荷，兼容旧字面量。

    - JSON 对象 → 原样返回（不强制补全字段，调用方按需 ``.get``）；
    - JSON 字符串 / 裸字面量 ``online``/``offline`` → ``{"state": <值>}``；
    - 其它（空、非 JSON 非字面量、JSON 非对象非字符串）→ 抛 ``ValueError``，
      交给调用方 fail-closed（配 ``ADM_ERR_PAYLOAD_INVALID``）。
    """
    text = payload.decode("utf-8", "replace") if isinstance(payload, bytes) else str(payload)
    stripped = text.strip()
    if not stripped:
        raise ValueError("adm status 载荷为空")
    # legacy 裸字面量（0.3.1 形）：未加引号的 online/offline
    if stripped in (STATE_ONLINE, STATE_OFFLINE):
        return {"state": stripped}
    try:
        obj = _json.loads(stripped)
    except _json.JSONDecodeError as exc:
        raise ValueError(f"adm status 载荷非 JSON 非字面量：{stripped[:40]!r}") from exc
    if isinstance(obj, str):
        if obj in (STATE_ONLINE, STATE_OFFLINE):
            return {"state": obj}
        raise ValueError(f"adm status 字符串非 online/offline：{obj!r}")
    if not isinstance(obj, dict):
        raise ValueError(f"adm status 载荷应为对象，实得 {type(obj).__name__}")
    return obj


__all__ = [
    "STATE_ONLINE",
    "STATE_OFFLINE",
    "STATE_DEGRADED",
    "encode_status",
    "decode_status",
]
