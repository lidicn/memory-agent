"""ADM 端到端探针底座（契约 v2.0 §7.4）。

不连 broker、不连服务——连接由各仓调用方发起（与 ``mqtt``/``presence`` 同纪律）。
这里只给两样：

- ``check_peer_online(client, peer)``：读 ``adm/<peer>/status`` 的 retained 值并解码，
  返回 ``(在线, status dict)``；
- ``run_all(probes)``：跑一组 ``(label, callable)`` 探针，任一组失败即 ``rc=1``。

三组端到端（DB↔MA / AF↔MA / DB↔AF）的**动作**留各仓实现（要连各自服务），
见 ``scripts/verify_adm_linkage.py``。
"""

from __future__ import annotations

import json as _json
from typing import Any, Callable

from homesdk import presence
from homesdk.adm.errors import ADM_ERR_PAYLOAD_INVALID, ADM_ERR_PEER_OFFLINE
from homesdk.adm.status import STATE_ONLINE, decode_status


def check_peer_online(
    client: Any,
    peer: str,
    *,
    timeout: float = 3.0,
) -> tuple[bool, dict[str, Any]]:
    """读 ``adm/<peer>/status`` 的 retained 值并解码为 (在线, status dict)。

    fail-closed 但不抛：读不到 → ``(False, {"state":"unknown", "code":ADM_ERR_PEER_OFFLINE})``；
    读到了却解不开 → ``(False, {"state":"unknown", "code":ADM_ERR_PAYLOAD_INVALID})``。
    探针要的是读数，不是崩。
    """
    raw = presence.read_status(client, peer, timeout=timeout)
    if raw is None:
        return False, {"state": "unknown", "code": ADM_ERR_PEER_OFFLINE}
    try:
        st = decode_status(raw)
    except ValueError:
        return False, {"state": "unknown", "code": ADM_ERR_PAYLOAD_INVALID}
    online = st.get("state") == STATE_ONLINE
    return online, st


def run_all(probes: dict[str, Callable[[], tuple[bool, dict[str, Any]]]]) -> int:
    """跑一组探针，任一组失败即返回 1；全绿返回 0。

    ``probes``：{label: callable}。callable 返回 (ok, detail)；detail 建议带 code。
    探针自身抛异常按失败记（code=ADM_ERR_INTERNAL），不冒泡。
    """
    all_ok = True
    for label, fn in probes.items():
        try:
            ok, detail = fn()
        except Exception as exc:  # noqa: BLE001 - 探针异常当失败，不中断其余
            ok, detail = False, {"code": "ADM_ERR_INTERNAL", "reason": repr(exc)}
        mark = "OK " if ok else "RED"
        print(f"[{mark}] {label}  detail={_json.dumps(detail, ensure_ascii=False)}")
        all_ok = all_ok and ok
    print("=== ALL GREEN ===" if all_ok else "=== NOT READY ===")
    return 0 if all_ok else 1


__all__ = ["check_peer_online", "run_all"]
