"""ADM 联动契约承载（契约 v2.0，homesdk 0.3.2）。

三个无依赖的纯常量/序列化模块，把「统一错误码 / status JSON / 端到端探针底座」
从"三仓看文档各写"变成"三仓 import 同一份"。**不背业务语义、不做判定**——

- `errors`：`ADM_ERR_*` 常量 + 成员判断；
- `status`：`adm/*/status` JSON 序列化 + legacy 字面量兼容；
- `probe`：端到端探针底座（`run_all` + `check_peer_online`）。
"""

from homesdk.adm import errors, status  # noqa: F401
from homesdk.adm import probe  # noqa: F401 - probe 依赖 status/presence，放最后

__all__ = ["errors", "probe", "status"]
