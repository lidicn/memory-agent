"""ADM 联动统一错误码（契约 v2.0 §7.2）。

无依赖，纯字符串常量 + 一个成员判断。三仓 import 它，替代各自手写的
`INBOX_DROP` / `AF_CHANNEL_ERROR` / `BridgeUnavailable` 等 ad-hoc 前缀。

设计纪律（与 homesdk 一致）：**只有码，没有文案、没有判定**。码是给机器分支的，
文案是给运维看的，两者不许混在同一个字符串里。
"""

from __future__ import annotations

from typing import Final

ADM_ERR_BROKER_UNREACHABLE: Final = "ADM_ERR_BROKER_UNREACHABLE"
ADM_ERR_PEER_OFFLINE: Final = "ADM_ERR_PEER_OFFLINE"
ADM_ERR_PAYLOAD_INVALID: Final = "ADM_ERR_PAYLOAD_INVALID"
ADM_ERR_AUTH_REQUIRED: Final = "ADM_ERR_AUTH_REQUIRED"
ADM_ERR_UPSTREAM_TIMEOUT: Final = "ADM_ERR_UPSTREAM_TIMEOUT"
ADM_ERR_INTERNAL: Final = "ADM_ERR_INTERNAL"

#: 全部合法码。消费方用它做"这码我认不认得"的边界判断。
ADM_ERRORS: Final[frozenset[str]] = frozenset(
    {
        ADM_ERR_BROKER_UNREACHABLE,
        ADM_ERR_PEER_OFFLINE,
        ADM_ERR_PAYLOAD_INVALID,
        ADM_ERR_AUTH_REQUIRED,
        ADM_ERR_UPSTREAM_TIMEOUT,
        ADM_ERR_INTERNAL,
    }
)


def is_adm_err(code: object) -> bool:
    """是否合法 ADM 错误码（防把拼错的字符串当码用）。"""
    return isinstance(code, str) and code in ADM_ERRORS


__all__ = [
    "ADM_ERR_BROKER_UNREACHABLE",
    "ADM_ERR_PEER_OFFLINE",
    "ADM_ERR_PAYLOAD_INVALID",
    "ADM_ERR_AUTH_REQUIRED",
    "ADM_ERR_UPSTREAM_TIMEOUT",
    "ADM_ERR_INTERNAL",
    "ADM_ERRORS",
    "is_adm_err",
]
