"""家庭时区：全生态"家庭墙钟"的唯一机制层入口。

随 homesdk 0.3.1 加入（DCD 2026-10-01 裁定：`20261001-AF-homesdk接入四问-裁定.md` 问题 2）。

**为什么需要它**：此前"家庭墙钟"分散在各仓各文件——MA 有 `store.now_local(tz_offset_hours)`（小时偏移）、
MA insights 硬编码 +8、AF 有 `AF_TZ`（IANA 名），三套口径互不相通。MA 实测过后果：
容器跑 UTC 而生产数据是 +8 墙钟时，"今天/昨天/最近 N 天"的日界与小时直方图整体偏 8 小时，
`sleeping` 类判定直接归零。

**口径（裁定：IANA 名为准）**：小时偏移表达不了 DST——`Asia/Shanghai` 无夏令时所以今天两种等价，
但家庭时区一旦落在有 DST 的带，固定偏移会在换日那一刻早/晚一小时。所以对外口径是 IANA 名，
小时偏移只作"无 tzdata 环境"的 fallback。

**键名**：`HOMESDK_TZ`（`HOMESDK_` 前缀优先），另收裸 `TZ` 与各仓旧键作过渡别名。
解析优先级：`HOMESDK_TZ` → `TZ` → 各仓旧键（`AF_TZ` / `TZ_OFFSET_HOURS`）→ 默认 `Asia/Shanghai`。

**边界**：只管"家庭墙钟是什么"，不管"事件时间戳怎么存"（那是各仓的数据事实）。
不提供"改容器时区"这类动作——代码应环境无关，而非靠改环境迁就代码。
"""

from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone, tzinfo
from typing import Any, Final

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover - Python < 3.9 无 zoneinfo
    ZoneInfo = None  # type: ignore[assignment,misc]

__all__ = [
    "DEFAULT_TZ_NAME",
    "FALLBACK_OFFSET_HOURS",
    "TZ_ENV_KEYS",
    "house_now",
    "house_tz",
    "house_tz_name",
    "house_tz_status",
    "to_house_iso",
]

#: 家庭时区未配置时的默认（IANA 名）。
DEFAULT_TZ_NAME: Final = "Asia/Shanghai"

#: 无 tzdata / 解析失败时的固定偏移兜底（小时）。**仅此一处允许小时偏移。**
FALLBACK_OFFSET_HOURS: Final = 8

#: 键名解析顺序（每级都先试 `HOMESDK_` 前缀，与 homesdk.config 同一约定）。
#: 前两个是规范键，其余是过渡别名（各仓旧键，保留至迁移完成）。
TZ_ENV_KEYS: Final[tuple[str, ...]] = (
    "TZ",
    "AF_TZ",
    "TZ_OFFSET_HOURS",
)

#: 小时偏移键（值形态与 IANA 名不同，单独处理）。
_OFFSET_KEYS: Final[tuple[str, ...]] = ("TZ_OFFSET_HOURS",)

_FIXED_OFFSET_TZ: Final[tzinfo] = timezone(timedelta(hours=FALLBACK_OFFSET_HOURS))


def _read_env(key: str) -> str | None:
    """读一个键：`HOMESDK_` 前缀优先，空串算未配置（与 config 同口径）。"""
    for candidate in (f"HOMESDK_{key}", key):
        raw = os.environ.get(candidate)
        if raw is None:
            continue
        value = raw.strip()
        if value:  # 空串等同未设置
            return value
    return None


def _parse_offset_hours(value: str) -> float | None:
    """解析小时偏移。"80" 这类越界值拒收（MA 侧既有纪律：笔误不留 fallback 幻觉）。"""
    try:
        hours = float(value)
    except (TypeError, ValueError):
        return None
    if not -24 < hours < 24:
        return None
    return hours


def house_tz_name() -> str:
    """当前生效的家庭时区标识（IANA 名，或兜底的 `UTC+HH:MM` 形态）。"""
    for key in TZ_ENV_KEYS:
        value = _read_env(key)
        if value is None:
            continue
        if key in _OFFSET_KEYS:
            hours = _parse_offset_hours(value)
            if hours is not None:
                return _offset_to_label(hours)
            continue
        return value
    return DEFAULT_TZ_NAME


def _offset_to_label(hours: float) -> str:
    sign = "+" if hours >= 0 else "-"
    whole = int(abs(hours))
    minutes = int(round((abs(hours) - whole) * 60))
    return f"UTC{sign}{whole:02d}:{minutes:02d}"


def house_tz() -> tzinfo:
    """家庭时区的 tzinfo。

    优先按 IANA 名解析（能表达 DST）；无 tzdata 或名字不认时退固定偏移。
    Never raises——时区解析失败不该让调用方崩，退兜底并留痕（由 house_tz_status 可见）。
    """
    name = house_tz_name()
    if ZoneInfo is not None:
        try:
            return ZoneInfo(name)
        except (KeyError, ValueError, OSError):
            # KeyError: ZoneInfoNotFoundError（名字不认 / 无 tzdata）
            # ValueError/OSError: tzdata 损坏或路径问题
            # 只收这三类可预期的解析失败；其余异常必须冒上来（G1 纪律）。
            pass
    # 小时偏移形态（`UTC+08:00`）或解析失败：退固定偏移
    if name.startswith("UTC") and len(name) > 3:
        try:
            sign = 1 if name[3] == "+" else -1
            hh, mm = name[4:].split(":")
            return timezone(sign * timedelta(hours=int(hh), minutes=int(mm)))
        except (ValueError, IndexError):
            pass
    return _FIXED_OFFSET_TZ


def house_tz_status() -> dict[str, Any]:
    """当前时区解析状态（供 `/api/health` 类出口暴露，便于排障）。"""
    name = house_tz_name()
    resolved_by_name = False
    if ZoneInfo is not None:
        try:
            ZoneInfo(name)
            resolved_by_name = True
        except Exception:  # noqa: BLE001 - 探测用
            resolved_by_name = False
    source = "default"
    for key in TZ_ENV_KEYS:
        if _read_env(key) is not None:
            source = f"env:{key}"
            break
    tz = house_tz()
    now = datetime.now(tz)
    return {
        "tz_name": name,
        "source": source,
        "resolved_by_name": resolved_by_name,
        "utc_offset": now.utcoffset(),
        "tzdata_available": ZoneInfo is not None,
    }


def house_now() -> datetime:
    """当前家庭墙钟时刻（aware datetime，带家庭时区）。"""
    return datetime.now(house_tz())


def to_house_iso(moment: datetime | float | int | None = None) -> str:
    """转家庭时区 ISO8601 字符串。

    - 传 aware datetime：按其时刻换算到家庭时区；
    - 传 naive datetime：**按家庭墙钟解释**（不交给机器时区——这正是原缺陷的根源）；
    - 传 epoch（float/int）：按 epoch 换算；
    - 不传：当前家庭墙钟。
    """
    tz = house_tz()
    if moment is None:
        target = datetime.now(tz)
    elif isinstance(moment, (int, float)):
        target = datetime.fromtimestamp(float(moment), tz=tz)
    elif isinstance(moment, datetime):
        target = moment.replace(tzinfo=tz) if moment.tzinfo is None else moment.astimezone(tz)
    else:
        raise TypeError(f"to_house_iso 不支持的入参类型：{type(moment).__name__}")
    return target.isoformat()
