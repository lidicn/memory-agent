"""联动基础：ADM 三仓在线探测（presence）+ DB 公共收件箱投递（inbox）。

随 homesdk 0.3.0 加入（DCD 2026-09-29 裁定）。管的是"怎么安全地说话"里的
**送达语义**，不碰业务 schema（那是各仓契约测试的事）。

两个子能力：

1. **presence**：在线 / 能力摘要，走 MQTT retained + LWT。
   - `adm/<name>/status`  retained：`online` / `offline`（offline 由 broker LWT 自动发，
     进程崩溃也覆盖）；读对端零往返。
   - `adm/<name>/caps`     retained：能力摘要 JSON，变更时重发。
   - 域名铁律：各仓只发布 `adm/<自己>/*`。别去推他仓主题。

2. **inbox**：DB 公共收件箱投递。DB 开设 `butler/inbox/{speak,notify,tv}`，
   任何仓投递、DB 订阅并过 Sentinel 闸门（夜间/冷却/角色/每日预算）后播出。
   - 与"越权直推"的区别：inbox 是 DB 显式开放的公共入口（所有权与校验权在 DB），
     不是把消息写进 DB 的内部语义主题。
   - 护栏：Broker ACL（仅注册主体）、载荷 schema fail-closed、每来源限流、
     trace_id 必填。

三条设计纪律（与既有模块一致）：

- **只配置/投递，不连接**：连接由调用方发起，测试不需要 broker。
- **零内置地址**：broker 地址来自 `MQTT_HOST`（mqtt.broker_settings），库内不写 IP。
- **fail-closed**：缺 trace_id / 载荷超长 → 丢弃并抛错，绝不静默放行。
"""

from __future__ import annotations

import json as _json
import time as _time
from typing import Any, Final

from homesdk import mqtt
from homesdk.adm.status import STATE_OFFLINE, STATE_ONLINE, decode_status, encode_status

#: 全生态 ADM 成员的域名标识。presence 只接受这些名字，防拼错主题。
ADM_MEMBERS: Final[frozenset[str]] = frozenset(
    {"doubao-butler", "autoforge", "memory-agent"}
)

#: 公共收件箱主题（DB 拥有）。投递侧只写这些，不碰 DB 内部语义主题。
INBOX_TOPICS: Final[frozenset[str]] = frozenset(
    {"butler/inbox/speak", "butler/inbox/notify", "butler/inbox/tv"}
)

#: inbox 载荷体上限（超长丢弃，防把家庭音箱变噪音源）。
INBOX_MAX_TEXT: Final[int] = 500
INBOX_MAX_TITLE: Final[int] = 80
INBOX_MAX_BODY: Final[int] = 500


class PresenceError(RuntimeError):
    """presence/inbox 的配置或载荷错误。"""


class UnknownMember(PresenceError):
    """不是 ADM 三仓成员名，拒绝发布到对应主题。"""


class UnknownInbox(PresenceError):
    """不在收件箱白名单，拒绝投递。"""


class MissingTraceId(PresenceError):
    """载荷缺 trace_id——跨仓排障的锚点，缺了就拒绝（fail-closed）。"""


def _validate_member(name: str) -> str:
    if name not in ADM_MEMBERS:
        raise UnknownMember(f"未知 ADM 成员：{name!r}（允许 {sorted(ADM_MEMBERS)}）")
    return name


def _topic(parts: tuple[str, ...]) -> str:
    return "/".join(parts)


# ---------------------------------------------------------------------------
# presence：在线 / 能力摘要
# ---------------------------------------------------------------------------

def advertise(
    client: Any,
    name: str,
    *,
    caps: dict[str, Any] | None = None,
    offline: bool = False,
    version: str = "",
) -> None:
    """广播本仓在线状态（契约 v2.0 §7.1：status 为 JSON，不再是字面量）。

    - 正常：设 LWT + 发 retained JSON status + caps。
    - `offline=True`：显式下线，发 retained JSON status（state=offline）。
    - `version`：计划号（status.version）；缺省回退 caps 里的 ``"version"``。

    连接须已由调用方发起（mqtt.get_client + connect）。LWT 用 paho 的
    `will_set`，payload 是 JSON offline（不是旧字面量）。
    """
    _validate_member(name)
    status_topic = _topic(("adm", name, "status"))
    caps_topic = _topic(("adm", name, "caps"))

    ver = version or (caps or {}).get("version", "")
    payload_offline = encode_status(STATE_OFFLINE, version=ver)
    payload_online = encode_status(STATE_ONLINE, version=ver)
    # LWT：设在这个 client 上，broker 在异常断连时替我们发 JSON offline
    if not offline and hasattr(client, "will_set"):
        client.will_set(status_topic, payload_offline, qos=1, retain=True)

    mqtt.publish(client, status_topic, payload_offline if offline else payload_online,
                 qos=1, retain=True)
    if caps is not None:
        mqtt.publish(client, caps_topic, _json.dumps(caps, ensure_ascii=False),
                     qos=1, retain=True)


def _read_retained(client: Any, topic: str, timeout: float) -> str | None:
    """订阅并读一条 retained 消息。超时返回 None（对端未在线 / 无 retained）。

    读前存原 on_message、读后还原：调用方若用同一 client 常驻订阅业务主题，
    一次探测不应悄悄换掉它的回调（QD 复议发现，DCD 修正）。
    """
    result: dict[str, Any] = {"payload": None, "done": False}

    def on_message(_c, _u, msg):  # noqa: ANN001
        if not result["done"]:
            result["payload"] = msg.payload
            result["done"] = True

    prev_on_message = getattr(client, "on_message", None)
    client.on_message = on_message
    try:
        client.subscribe(topic, qos=1)
        deadline = _time.monotonic() + timeout
        while not result["done"] and _time.monotonic() < deadline:
            client.loop(timeout=0.1)
    finally:
        # 无条件还原调用方回调（含原本是 None 的支）：无论读到/超时/异常都不留尾巴。
        # QD 复议 R3：D-1 若写成 if-prev-not-None 会漏"调用方本没挂回调"这一支，
        # 按判据「读侧不能静默改动调用方状态」必须无条件还原。
        client.on_message = prev_on_message
        try:
            client.unsubscribe(topic)
        except (AttributeError, OSError, TimeoutError):
            # 收尾清理：unsubscribe 失败不掩盖已读到的结果。
            pass
    if result["payload"] is None:
        return None
    return result["payload"].decode("utf-8", "replace") if isinstance(result["payload"], bytes) else str(result["payload"])


def read_status(client: Any, name: str, *, timeout: float = 3.0) -> str | None:
    """读 `adm/<name>/status` 的 retained 原始载荷（未解码，可能 JSON 或旧字面量）。无则 None。"""
    _validate_member(name)
    topic = _topic(("adm", name, "status"))
    return _read_retained(client, topic, timeout)


def is_online(client: Any, name: str, *, timeout: float = 3.0) -> bool:
    """读 `adm/<name>/status` 的 retained 值：state==online 才为真。

    兼容旧字面量（`decode_status` 内部处理）。读不到/解不开视为不在线
    （fail-closed：不知道就不当在线）。
    """
    val = read_status(client, name, timeout=timeout)
    if val is None:
        return False
    try:
        st = decode_status(val)
    except ValueError:
        return False
    return st.get("state") == STATE_ONLINE


def caps(client: Any, name: str, *, timeout: float = 3.0) -> dict[str, Any] | None:
    """读 `adm/<name>/caps` 的 retained 能力摘要。无则 None。"""
    _validate_member(name)
    topic = _topic(("adm", name, "caps"))
    raw = _read_retained(client, topic, timeout)
    if raw is None:
        return None
    try:
        parsed = _json.loads(raw)
    except _json.JSONDecodeError:
        return None
    return parsed if isinstance(parsed, dict) else None


def wait_online(client: Any, name: str, *, timeout: float = 5.0) -> bool:
    """启动期等对端在线。轮询 retained status，超时返回 False。"""
    _validate_member(name)
    deadline = _time.monotonic() + timeout
    while _time.monotonic() < deadline:
        if is_online(client, name, timeout=min(0.5, max(0.1, deadline - _time.monotonic()))):
            return True
    return False


# ---------------------------------------------------------------------------
# inbox：DB 公共收件箱投递
# ---------------------------------------------------------------------------

def _check_trace_id(payload: dict[str, Any]) -> None:
    if not payload.get("trace_id"):
        raise MissingTraceId("inbox 载荷缺 trace_id——跨仓排障锚点，拒绝投递")


def _len_bounded(value: Any, limit: int, field: str) -> str:
    if not isinstance(value, str):
        raise TypeError(f"{field} 必须是字符串")
    if len(value) > limit:
        raise ValueError(f"{field} 超长（>{limit} 字符），拒绝投递")
    return value


def _publish_inbox(client: Any, topic: str, payload: dict[str, Any], *, qos: int = 1) -> None:
    if topic not in INBOX_TOPICS:
        raise UnknownInbox(f"未知收件箱主题：{topic!r}（允许 {sorted(INBOX_TOPICS)}）")
    _check_trace_id(payload)
    body = _json.dumps(payload, ensure_ascii=False)
    mqtt.publish(client, topic, body, qos=qos, retain=False)


def speak(client: Any, text: str, *, trace_id: str, role: str = "", priority: int = 0,
          expires_at: float | None = None, qos: int = 1) -> None:
    """请 DB 播报一段文本（`butler/inbox/speak`）。不 retained。"""
    _len_bounded(text, INBOX_MAX_TEXT, "text")
    payload: dict[str, Any] = {
        "trace_id": trace_id,
        "ts": int(_time.time()),
        "text": text,
    }
    if role:
        payload["role"] = role
    if priority:
        payload["priority"] = priority
    if expires_at is not None:
        payload["expires_at"] = expires_at
    _publish_inbox(client, "butler/inbox/speak", payload, qos=qos)


def notify(client: Any, title: str, body: str, *, trace_id: str, channel: str = "",
           priority: int = 0, qos: int = 1) -> None:
    """请 DB 推送通知（`butler/inbox/notify`）。不 retained。"""
    _len_bounded(title, INBOX_MAX_TITLE, "title")
    _len_bounded(body, INBOX_MAX_BODY, "body")
    payload: dict[str, Any] = {
        "trace_id": trace_id,
        "ts": int(_time.time()),
        "title": title,
        "body": body,
    }
    if channel:
        payload["channel"] = channel
    if priority:
        payload["priority"] = priority
    _publish_inbox(client, "butler/inbox/notify", payload, qos=qos)


def tv(client: Any, content: str, *, trace_id: str, duration_s: int | None = None,
       qos: int = 1) -> None:
    """请 DB 上屏 TV（`butler/inbox/tv`）。不 retained。"""
    _len_bounded(content, INBOX_MAX_TEXT, "content")
    payload: dict[str, Any] = {
        "trace_id": trace_id,
        "ts": int(_time.time()),
        "content": content,
    }
    if duration_s is not None:
        payload["duration_s"] = duration_s
    _publish_inbox(client, "butler/inbox/tv", payload, qos=qos)