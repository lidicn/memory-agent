"""统一的 env 读取：一份键名解析规则，五家用同一份。

设计不变式：

    解析不出来就退回默认值，永不抛、永不猜。

这条规矩存在的理由是现网量到的三种并存写法：`_env_bool` 认 `1/true/yes/on`、
`app.py` 内联 `.lower() in ("1","true","yes")`、`deps.py` 的 `!= "false"` 反向逻辑。
最后那种是 fail-open——`ALLOW_PASSWORD_AS_BEARER="0"` 按字面判成 True，
因为 `"0" != "false"`。所以这里的假值集合是**显式列出**的，
不可解析的值落到 `default` 而不是落到「非假即为真」。

键名解析顺序（`_lookup`，全模块共用）：`HOMESDK_<KEY>` 优先，其次裸 `<KEY>`。
下游仓不需要改名就能接上，改名之后 homesdk 侧的覆盖仍然赢。
"""

from __future__ import annotations

import os
from typing import Final

#: homesdk 自己的 env 前缀。带前缀的键永远优先于裸键。
PREFIX: Final = "HOMESDK_"

_TRUE: Final = frozenset({"1", "y", "yes", "true", "t", "on"})
_FALSE: Final = frozenset({"0", "n", "no", "false", "f", "off"})


class MissingEnv(RuntimeError):
    """必需的环境变量缺失或为空串。`require_env` 的唯一出口。"""


def _lookup(key: str) -> str | None:
    """按 `HOMESDK_<KEY>` → `<KEY>` 取第一个非空值，一律 strip。

    空串与未设置同视：现网 `os.getenv(K, "默认")` 在 compose 写了 `K=` 时
    会拿到空串而非默认值，这里不复制那个行为。
    """
    for candidate in (f"{PREFIX}{key}", key):
        raw = os.environ.get(candidate)
        if raw is not None and raw.strip():
            return raw.strip()
    return None


def get_env(key: str, default: str | None = None) -> str | None:
    """读字符串；未配置或空串返回 `default`。"""
    value = _lookup(key)
    return default if value is None else value


def require_env(key: str) -> str:
    """读必需项；缺失即抛 `MissingEnv`。

    给 `homesdk.auth` / `homesdk.http` 用：地址与凭据缺失时**必须**在这里停住，
    不能带着空值往下走——往下走的那条分支就是现网那七个 fail-open 洞的形状。
    """
    value = _lookup(key)
    if value is None:
        raise MissingEnv(f"环境变量 {PREFIX}{key}（或 {key}）未设置或为空")
    return value


def get_env_bool(key: str, default: bool = False) -> bool:
    """读布尔；认 `1/y/yes/true/t/on` 与它们的否定式，大小写与空格无关。

    不可解析的值落到 `default`。**不给「非假即真」留路子**。
    """
    value = _lookup(key)
    if value is None:
        return default
    low = value.lower()
    if low in _TRUE:
        return True
    if low in _FALSE:
        return False
    return default


def get_env_int(key: str, default: int = 0) -> int:
    """读整数；不可解析（含浮点串、空串）落到 `default`。"""
    value = _lookup(key)
    if value is None:
        return default
    try:
        return int(value, 10)
    except ValueError:
        return default


def first_env(keys: tuple[str, ...], default: str | None = None) -> str | None:
    """按顺序取第一个命中的键，用于收编旧仓已有的键名（别名表见 `homesdk.auth`）。

    返回 None 表示一个都没配；调用方据此决定是宽松返回还是 `MissingEnv`。
    """
    for key in keys:
        value = _lookup(key)
        if value is not None:
            return value
    return default
